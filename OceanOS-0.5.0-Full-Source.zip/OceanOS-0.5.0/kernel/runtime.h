#ifndef OCEAN_RUNTIME_H
#define OCEAN_RUNTIME_H
typedef unsigned char uint8_t;typedef unsigned short uint16_t;typedef unsigned int uint32_t;typedef unsigned long long uint64_t;typedef __UINTPTR_TYPE__ uintptr_t;
uint32_t rect(uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t round_rect(uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t text(uint32_t,uint32_t,uintptr_t,uint32_t);uint32_t label2(uint32_t,uint32_t,uintptr_t,uint32_t);
uint32_t state(uint32_t);uint32_t set_state(uint32_t,uint32_t);
uint32_t inside(uint32_t,uint32_t,uint32_t,uint32_t,uint32_t,uint32_t);
uint32_t background(void);uint32_t cursor(void);uint32_t cursor_update(void);uint32_t present(void);
uint32_t hardware_init(void);uint32_t poll_input(void);uint32_t idle(void);uint32_t accent(void);uint32_t theme_toggle(void);
/* Notepad */
uint32_t note_key(uint32_t);uint32_t note_draw(uint32_t,uint32_t);uint32_t note_new(void);uint32_t note_save(void);
uint32_t note_name_draw(uint32_t,uint32_t);uint32_t note_status(void);
/* Files / OceanFS (0.2) */
uint32_t files_draw(uint32_t,uint32_t);uint32_t file_open(uint32_t);uint32_t files_click_row(uint32_t);
uint32_t files_up(void);uint32_t files_open(void);uint32_t files_mkdir(void);uint32_t files_rename(void);
uint32_t files_delete(void);uint32_t files_format(void);uint32_t files_key(uint32_t);uint32_t files_reset(void);
uint32_t storage_state(void);uint32_t fs_label(void);uint32_t fs_status(void);
/* Terminal and Settings */
uint32_t terminal_key(uint32_t);uint32_t terminal_draw(uint32_t,uint32_t);uint32_t display_draw(uint32_t,uint32_t);
typedef struct {uint32_t id,offset,active;} ocean_file;
uint32_t ocean_open(ocean_file*,uint32_t,const char*);
uint32_t ocean_seek(ocean_file*,uint32_t);
uint32_t ocean_read_next(ocean_file*,void*,uint32_t);
uint32_t ocean_write_next(ocean_file*,const void*,uint32_t);
uint32_t ocean_close(ocean_file*);
uint32_t ocean_read(uint32_t,uint32_t,void*,uint32_t);
uint32_t ocean_write(uint32_t,uint32_t,const void*,uint32_t);
uint32_t ocean_truncate(uint32_t,uint32_t);
uint32_t files_home(void);uint32_t files_notes(void);uint32_t storage_meter(uint32_t,uint32_t,uint32_t);
uint32_t bc(uint32_t,uint32_t);uint32_t bs(uint32_t,uint32_t,uint32_t);
uint32_t bp(uint32_t,uintptr_t);uint32_t bcopy(uint32_t,uint32_t);uint32_t beq(uint32_t,uintptr_t);
uint32_t bn(uint32_t);uint32_t bv(uint32_t,uint32_t);uint32_t bt(uint32_t,uint32_t,uint32_t,uint32_t);uint32_t bload(void);
#endif
