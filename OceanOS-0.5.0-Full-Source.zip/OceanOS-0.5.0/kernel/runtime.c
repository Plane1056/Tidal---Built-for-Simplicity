#include "runtime.h"
#include "../assets/font.h"
#define MAX_W 1600
#define MAX_H 1024
#define CW 24
#define CH 32
static uint32_t width=1280,height=800,pitch=5120;
static uint32_t pixels[MAX_W*MAX_H],wallpaper[MAX_W*MAX_H],displayed[MAX_W*MAX_H],s[64];
static uint32_t wallpaper_ready,display_ready,theme;
#ifdef OCEANOS_HOST_TEST
static uint32_t test_front[MAX_W*MAX_H];
#define FRONT_BUFFER test_front
#else
#define FRONT_BUFFER ((volatile uint32_t*)(uintptr_t)(*(volatile uint32_t*)0x9300))
#endif
static uint32_t saved[CW*CH],oldx,oldy,cursor_valid;
static uint32_t mx=400,my=300,mb,phase,packet[3],shift,ctrl,extended;
static inline uint8_t in8(uint16_t p){uint8_t x;__asm__ volatile("inb %1,%0":"=a"(x):"Nd"(p));return x;}
static inline void out8(uint16_t p,uint8_t x){__asm__ volatile("outb %0,%1"::"a"(x),"Nd"(p));}
void *memcpy(void*d,const void*v,uint32_t n){uint8_t*a=d;const uint8_t*b=v;while(n--)*a++=*b++;return d;}
void *memset(void*d,int v,uint32_t n){uint8_t*a=d;while(n--)*a++=(uint8_t)v;return d;}
static void strcopy(char*d,const char*s0,uint32_t cap){uint32_t i=0;while(s0[i]&&i+1<cap){d[i]=s0[i];i++;}d[i]=0;}
static uint32_t length(const char*p){uint32_t n=0;while(p[n])n++;return n;}
static int equal(const char*a,const char*b){while(*a&&*a==*b){a++;b++;}return *a==*b;}
#include "storage.inc"
uint32_t state(uint32_t i){return i<64?s[i]:0;}
uint32_t set_state(uint32_t i,uint32_t v){if(i<64)s[i]=v;return 0;}
uint32_t inside(uint32_t x,uint32_t y,uint32_t a,uint32_t b,uint32_t w,uint32_t h){return x>=a&&y>=b&&x-a<w&&y-b<h;}
static uint32_t sx(uint32_t x){return x*width/1280;}
static uint32_t sy(uint32_t y){return y*height/800;}
static uint32_t blend(uint32_t a,uint32_t b,uint32_t alpha){uint32_t r=(((a>>16)&255)*(255-alpha)+((b>>16)&255)*alpha+127)/255;uint32_t g=(((a>>8)&255)*(255-alpha)+((b>>8)&255)*alpha+127)/255;uint32_t bl=((a&255)*(255-alpha)+(b&255)*alpha+127)/255;return (r<<16)|(g<<8)|bl;}
static void alpha_pixel(uint32_t x,uint32_t y,uint32_t c,uint32_t a){if(x<width&&y<height&&a)pixels[y*width+x]=a>=255?c:blend(pixels[y*width+x],c,a);}
static void fill(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint32_t c){if(x>=width||y>=height)return;if(w>width-x)w=width-x;if(h>height-y)h=height-y;for(uint32_t j=0;j<h;j++)for(uint32_t i=0;i<w;i++)pixels[(y+j)*width+x+i]=c;}
uint32_t rect(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint32_t c){if(x>=1280||y>=800)return 0;if(w>1280-x)w=1280-x;if(h>800-y)h=800-y;fill(sx(x),sy(y),sx(x+w)-sx(x),sy(y+h)-sy(y),c);return 0;}
uint32_t round_rect(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint32_t radius,uint32_t color){if(x>=1280||y>=800)return 0;if(w>1280-x)w=1280-x;if(h>800-y)h=800-y;uint32_t X=sx(x),Y=sy(y),W=sx(x+w)-X,H=sy(y+h)-Y,R=sx(radius);if(R>W/2)R=W/2;if(R>H/2)R=H/2;if(!R){fill(X,Y,W,H,color);return 0;}fill(X+R,Y,W-2*R,H,color);fill(X,Y+R,R,H-2*R,color);fill(X+W-R,Y+R,R,H-2*R,color);
for(uint32_t j=0;j<R;j++){for(uint32_t i=0;i<R;i++){uint32_t coverage=0;for(uint32_t a=1;a<4;a+=2)for(uint32_t b=1;b<4;b+=2){uint32_t dx=(R-i)*4-a,dy=(R-j)*4-b;if(dx*dx+dy*dy<=R*R*16)coverage++;}uint32_t alpha=coverage*255/4;alpha_pixel(X+i,Y+j,color,alpha);alpha_pixel(X+W-1-i,Y+j,color,alpha);alpha_pixel(X+i,Y+H-1-j,color,alpha);alpha_pixel(X+W-1-i,Y+H-1-j,color,alpha);}}
return 0;}
static void glyph(uint32_t x,uint32_t y,uint8_t ch,uint32_t color,uint32_t large){if(ch<32||ch>=128)return;uint32_t w,h;const uint8_t*atlas;if(width>=1440){w=large?20:10;h=large?48:24;atlas=large?font_large_1600:font_small_1600;}else if(width>=1200){w=large?18:9;h=large?42:21;atlas=large?font_large_1280:font_small_1280;}else if(width>=1000){w=large?15:8;h=large?36:18;atlas=large?font_large_1024:font_small_1024;}else{w=large?13:6;h=large?30:15;atlas=large?font_large_800:font_small_800;}atlas+=(ch-32)*w*h;for(uint32_t j=0;j<h;j++)for(uint32_t i=0;i<w;i++)alpha_pixel(x+i,y+j,color,atlas[j*w+i]);}
uint32_t text(uint32_t x,uint32_t y,uintptr_t ptr,uint32_t color){const char*t=(const char*)ptr;uint32_t origin=x;for(uint32_t i=0;t[i]&&i<4096;i++){if(t[i]=='\n'){x=origin;y+=23;}else{glyph(sx(x),sy(y),t[i],color,0);x+=9;}}return 0;}
uint32_t label2(uint32_t x,uint32_t y,uintptr_t ptr,uint32_t color){const char*t=(const char*)ptr;for(uint32_t i=0;t[i]&&i<64;i++)glyph(sx(x+i*20),sy(y),t[i],color,1);return 0;}
uint32_t accent(void){return theme?0x7CDFCE:0x73C9FF;}
uint32_t theme_toggle(void){theme=!theme;wallpaper_ready=0;s[7]=1;return 0;}
uint32_t background(void){uint32_t count=width*height;if(wallpaper_ready){for(uint32_t i=0;i<count;i++)pixels[i]=wallpaper[i];return 0;}for(uint32_t y=0;y<height;y++)for(uint32_t x=0;x<width;x++){uint32_t lx=x*1280/width,ly=y*800/height;uint32_t r=7+ly*3/800,g=18+lx*18/1280+ly*12/800,b=36+lx*30/1280+ly*15/800;if(theme){g+=8;b-=8;}uint32_t color=(r<<16)|(g<<8)|b;int dx=(int)lx-1010,dy=(int)ly-210;int d=dx*dx+dy*dy;int distance=d-210000;if(distance<0)distance=-distance;if(distance<17000){uint32_t a=(17000-distance)*66/17000;color=blend(color,accent(),a);}dx=(int)lx-1280;dy=(int)ly-590;d=dx*dx+dy*dy;distance=d-125000;if(distance<0)distance=-distance;if(distance<13000)color=blend(color,0x659DEE,(13000-distance)*52/13000);wallpaper[y*width+x]=pixels[y*width+x]=color;}wallpaper_ready=1;return 0;}
uint32_t cursor(void){for(uint32_t y=0;y<CH;y++)for(uint32_t x=0;x<CW;x++)if(mx+x<width&&my+y<height)saved[y*CW+x]=pixels[(my+y)*width+mx+x];oldx=mx;oldy=my;cursor_valid=1;uint32_t H=width>=1024?26:21;for(uint32_t y=0;y<H;y++)for(uint32_t x=0;x<=H/2;x++){uint32_t coverage=0;for(uint32_t yy=1;yy<4;yy+=2)for(uint32_t xx=1;xx<4;xx+=2)if((x*4+xx)*2<=y*4+yy)coverage++;if(coverage){uint32_t color=(x<1||y>=H-1||x*2+3>=y)?0x071625:0xF3FAFF;alpha_pixel(mx+x,my+y,color,coverage*255/4);}}return 0;}
static void region(uint32_t x,uint32_t y,uint32_t w,uint32_t h){volatile uint32_t*fb=FRONT_BUFFER;for(uint32_t j=0;j<h&&y+j<height;j++){volatile uint32_t*row=(volatile uint32_t*)((volatile uint8_t*)fb+(y+j)*pitch);for(uint32_t i=0;i<w&&x+i<width;i++){uint32_t at=(y+j)*width+x+i;if(!display_ready||pixels[at]!=displayed[at]){row[x+i]=pixels[at];displayed[at]=pixels[at];}}}}
uint32_t present(void){region(0,0,width,height);display_ready=1;return 0;}
uint32_t cursor_update(void){uint32_t x=oldx,y=oldy;if(cursor_valid)for(uint32_t j=0;j<CH;j++)for(uint32_t i=0;i<CW;i++)if(x+i<width&&y+j<height)pixels[(y+j)*width+x+i]=saved[j*CW+i];cursor();region(x,y,CW,CH);region(mx,my,CW,CH);return 0;}
static int wait_write(void){for(uint32_t i=0;i<100000;i++)if(!(in8(0x64)&2))return 1;return 0;}
static void ctl(uint8_t c){if(wait_write())out8(0x64,c);}
static void data(uint8_t c){if(wait_write())out8(0x60,c);}
static int mcmd(uint8_t c){ctl(0xd4);data(c);for(uint32_t i=0;i<100000;i++){uint8_t st=in8(0x64);if(st&1){uint8_t v=in8(0x60);if(st&0x20)return v==0xfa;}}return 0;}
#include "apps.inc"
#include "browser.inc"
uint32_t hardware_init(void){
#ifndef OCEANOS_HOST_TEST
width=*(volatile uint32_t*)0x9308;height=*(volatile uint32_t*)0x930c;pitch=*(volatile uint32_t*)0x9304;
#endif
if(width<800||width>MAX_W||height<600||height>MAX_H||pitch<width*4){width=800;height=600;pitch=3200;}mx=width/2;my=height/2;s[0]=mx*1280/width;s[1]=my*800/height;storage_init();note_new();files_init();out8(0x21,0xff);out8(0xa1,0xff);for(uint32_t i=0;i<128&&(in8(0x64)&1);i++)in8(0x60);ctl(0xa8);ctl(0xae);ctl(0x20);uint8_t cfg=0x40;for(uint32_t i=0;i<100000;i++)if(in8(0x64)&1){cfg=in8(0x60);break;}ctl(0x60);data((cfg|0x40)&~0x33);mcmd(0xf6);s[10]=mcmd(0xf4);s[7]=1;return 0;}
static void mouse(uint8_t v){if(phase==0){if(!(v&8))return;packet[0]=v;phase=1;return;}packet[phase++]=v;if(phase!=3)return;phase=0;uint32_t h=packet[0];if(!(h&0xc0)){int dx=(int)packet[1]-((h&0x10)?256:0),dy=(int)packet[2]-((h&0x20)?256:0);int nx=(int)mx+dx,ny=(int)my-dy;if(nx<0)nx=0;if(nx>=(int)width)nx=width-1;if(ny<0)ny=0;if(ny>=(int)height)ny=height-1;if(mx!=(uint32_t)nx||my!=(uint32_t)ny)s[7]|=2;mx=nx;my=ny;s[0]=mx*1280/width;s[1]=my*800/height;}uint32_t b=h&7;if((b&1)&&!(mb&1)){s[2]=1;s[7]|=1;}mb=b;s[3]=b;}
static const char normal[]="\0\0001234567890-=\0\0qwertyuiop[]\n\0asdfghjkl;'`\0\\zxcvbnm,./\0*\0 ";
static const char shifted[]="\0\0!@#$%^&*()_+\0\0QWERTYUIOP{}\n\0ASDFGHJKL:\"~\0|ZXCVBNM<>?\0*\0 ";
static void key(uint8_t v){if(v==0xe0){extended=1;return;}if(extended){extended=0;if(v==0x48){s[6]=258;s[7]=1;}else if(v==0x50){s[6]=259;s[7]=1;}else if(v==0x53){s[6]=260;s[7]=1;}return;}if(v==42||v==54){shift=1;return;}if(v==170||v==182){shift=0;return;}if(v==29){ctrl=1;return;}if(v==157){ctrl=0;return;}if(v&128)return;if(v==1){if(rename_on){rename_on=0;s[7]=1;return;}format_armed=0;s[4]=0;s[5]=0;s[7]=1;return;}if(v>=59&&v<=64){rename_on=0;format_armed=0;s[4]=v-58;s[5]=0;s[7]=1;return;}uint32_t ch=0;if(v==14)ch=8;else if(v==15)ch=9;else if(v<sizeof(normal)-1)ch=(uint8_t)(shift?shifted[v]:normal[v]);if(ctrl&&v==38)ch=261;if(ctrl&&v==31)ch=256;if(ctrl&&v==49)ch=257;if(ch){s[6]=ch;s[7]=1;}}
uint32_t poll_input(void){s[2]=0;s[6]=0;for(uint32_t i=0;i<96;i++){uint8_t st=in8(0x64);if(!(st&1))break;uint8_t v=in8(0x60);if(st&0xc0){phase=0;continue;}if(st&0x20)mouse(v);else{key(v);if(s[6])break;}}return 0;}
uint32_t idle(void){__asm__ volatile("pause");return 0;}
