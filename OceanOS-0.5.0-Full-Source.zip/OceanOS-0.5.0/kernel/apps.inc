/* OceanOS 0.2 app primitives: Notepad, file explorer, terminal, storage info.
 * Included by runtime.c after the drawing primitives and storage.inc.
 * s[24] note status: 0 unsaved, 1 saved to RAM, 2 file table full, 3 saved to disk, 4 disk write error. */
static char note[NOTE_CAP+1];static uint32_t nlen;
static char command[1024],answer[1024];static uint32_t clen;
static uint32_t view[FS_ENTRIES],view_n,sel=NONE,scroll,rename_on,format_armed,rlen;
static char rbuf[FS_NAME],fmsg[72];
#define COL_TEXT 0xEEF5FF
#define COL_MUTED 0xAAB8CB
#define COL_WARN 0xF2CB76
static uint32_t utoa(uint32_t v,char*o){char t[12];uint32_t n=0,k=0;do{t[n++]='0'+v%10;v/=10;}while(v);while(n)o[k++]=t[--n];o[k]=0;return k;}
static void sadd(char*d,uint32_t cap,const char*src){uint32_t l=length(d);if(l+1<cap)strcopy(d+l,src,cap-l);}
static void snum(char*d,uint32_t cap,uint32_t v){char b[12];utoa(v,b);sadd(d,cap,b);}
static void ans_clear(void){answer[0]=0;}
static void ans_add(const char*t){sadd(answer,sizeof answer,t);}
static void ans_num(uint32_t v){snum(answer,sizeof answer,v);}
static void fmsg_set(const char*m){strcopy(fmsg,m,sizeof fmsg);}
static const char*err_text(uint32_t e){
 if(e==E_FULL)return "No space or file entries available";if(e==E_NAME)return "Invalid UTF-8 name (1-127 bytes)";
 if(e==E_EXISTS)return "That name already exists here";if(e==E_IO)return "Disk I/O failed - volume is read-only";
 if(e==E_BIG)return "File or document exceeds size limit";if(e==E_BUSY)return "Another writer is active";if(e==E_NOTEMPTY)return "Folder is not empty";if(e==E_NOENT)return "No such file or folder";if(e==E_ISDIR)return "That is a folder";return "Error";}
static void path_of(uint32_t dir,char*out,uint32_t cap){if(cap<2)return;uint32_t chain[FS_ENTRIES],n=0,at=0;while(dir&&n<FS_ENTRIES){if(dir>=FS_ENTRIES||ent[dir].type!=T_DIR){strcopy(out,"[invalid path]",cap);return;}chain[n++]=dir;dir=ent[dir].parent;}if(dir){strcopy(out,"[cycle]",cap);return;}if(!n){out[0]='/';out[1]=0;return;}for(uint32_t k=n;k>0;k--){if(at+1<cap)out[at++]='/';const char*nm=ent[chain[k-1]].name;for(uint32_t j=0;nm[j]&&at+1<cap;j++)out[at++]=nm[j];}out[at]=0;}

/* ---- Notepad ---- */
uint32_t note_new(void){nlen=0;note[0]=0;doc_current=NONE;s[24]=0;return 0;}
uint32_t note_save(void){
 if(doc_current==NONE){char n[24];uint32_t k;for(k=1;k<=8192;k++){memcpy(n,"Note",4);uint32_t l=4+utoa(k,n+4);memcpy(n+l,".TXT",5);if(find_child(cwd,n)==NONE)break;}if(k>8192){s[24]=2;return 0;}uint32_t id=entry_make(cwd,n,T_FILE,"");if(IS_ERR(id)){s[24]=id==E_FULL?2:4;return 0;}doc_current=id;}
 uint32_t r=fs_replace(doc_current,note,nlen);if(IS_ERR(r)){s[24]=r==E_FULL?2:4;return 0;}s[24]=disk_state==1?3:1;return 0;}
uint32_t file_open(uint32_t id){if(id>=FS_ENTRIES||ent[id].type!=T_FILE)return 0;uint32_t size=ent[id].size;if(size>NOTE_CAP){s[24]=5;fmsg_set("Document exceeds 1 MiB editor limit");return 0;}uint8_t b[BLOCK];for(uint32_t off=0;off<size;){uint32_t n=size-off;if(n>BLOCK)n=BLOCK;uint32_t got=fs_read_at(id,off,b,n);if(IS_ERR(got)||got!=n){s[24]=4;return 0;}for(uint32_t i=0;i<n;i++)if(!((b[i]>=32&&b[i]<127)||b[i]==9||b[i]==10||b[i]==13)){s[24]=5;fmsg_set("Binary file: stored safely, not opened as text");return 0;}off+=n;}uint32_t got=fs_read_at(id,0,note,size);if(IS_ERR(got)||got!=size){s[24]=4;return 0;}note[size]=0;nlen=size;doc_current=id;s[4]=1;s[24]=disk_state==1?3:1;s[7]=1;return 0;}
uint32_t note_key(uint32_t ch){if(ch==256)return note_save();if(ch==257)return note_new();if(ch>=258)return 0;
 if(ch==8){if(nlen)note[--nlen]=0;}else if(ch==9){for(uint32_t i=0;i<4&&nlen<NOTE_CAP;i++)note[nlen++]=' ';note[nlen]=0;}else if((ch==10||ch>=32)&&ch<127&&nlen<NOTE_CAP){note[nlen++]=ch;note[nlen]=0;}s[24]=0;return 0;}
uint32_t note_draw(uint32_t x,uint32_t y){const uint32_t cols=84,rows=17;uint32_t line=0,col=0;for(uint32_t i=0;i<nlen;i++){if(note[i]=='\n'){line++;col=0;}else if(++col>=cols){line++;col=0;}}uint32_t first=line>=rows?line-rows+1:0;line=0;col=0;for(uint32_t i=0;i<nlen;i++){if(note[i]=='\n'){line++;col=0;}else{if(line>=first&&line-first<rows)glyph(sx(x+col*9),sy(y+(line-first)*23),note[i],COL_TEXT,0);if(++col>=cols){line++;col=0;}}}rect(x+col*9,y+(line-first)*23+17,7,1,accent());return 0;}
uint32_t note_name_draw(uint32_t x,uint32_t y){char b[24];b[0]=0;if(doc_current!=NONE){sadd(b,sizeof b,"- ");sadd(b,sizeof b,ent[doc_current].name);}else sadd(b,sizeof b,"- (new, unsaved)");text(x,y,(uintptr_t)b,COL_MUTED);return 0;}

/* ---- File explorer ---- */
static void view_build(void){view_n=0;for(uint32_t pass=0;pass<2;pass++)for(uint32_t i=1;i<FS_ENTRIES;i++)if(ent[i].type&&ent[i].parent==cwd&&((pass==0)==(ent[i].type==T_DIR)))view[view_n++]=i;
 if(sel!=NONE&&sel>=view_n)sel=view_n?view_n-1:NONE;if(sel!=NONE){if(sel<scroll)scroll=sel;if(sel>=scroll+11)scroll=sel-10;}if(scroll&&scroll>=view_n)scroll=view_n?view_n-1:0;}
static void select_entry(uint32_t id){view_build();sel=NONE;for(uint32_t i=0;i<view_n;i++)if(view[i]==id){sel=i;break;}view_build();}
static void fs_changed(void){sel=NONE;scroll=0;view_build();s[7]=1;}
static void files_init(void){view_build();fmsg[0]=0;if(disk_state==0)fmsg_set("No IDE disk detected: files live in RAM only");else if(disk_state==2)fmsg_set("Disk is not OceanFS and is untouched. Format disk to use it");else if(disk_state==3)fmsg_set("Disk error: writes disabled");else fmsg_set("OceanFS disk mounted");}
uint32_t files_reset(void){rename_on=0;format_armed=0;return 0;}
uint32_t storage_state(void){return disk_state;}
uint32_t files_up(void){files_reset();if(cwd){uint32_t from=cwd;cwd=ent[cwd].parent;scroll=0;select_entry(from);fmsg[0]=0;}else fmsg_set("Already at the top folder");return 0;}
uint32_t files_open(void){files_reset();if(sel==NONE||sel>=view_n){fmsg_set("Select a file or folder first");return 0;}uint32_t id=view[sel];if(ent[id].type==T_DIR){cwd=id;sel=NONE;scroll=0;view_build();fmsg[0]=0;}else file_open(id);return 0;}
uint32_t files_click_row(uint32_t j){files_reset();uint32_t idx=scroll+j;if(idx>=view_n)return 0;if(sel==idx)return files_open();sel=idx;fmsg[0]=0;return 0;}
uint32_t files_mkdir(void){files_reset();char n[24];uint32_t k;for(k=1;k<=8192;k++){n[0]=0;sadd(n,sizeof n,"NewFolder");if(k>1)snum(n,sizeof n,k);if(find_child(cwd,n)==NONE)break;}
 uint32_t r=entry_make(cwd,n,T_DIR,0);if(IS_ERR(r)){fmsg_set(err_text(r));return 0;}select_entry(r);rename_on=1;strcopy(rbuf,ent[r].name,FS_NAME);rlen=length(rbuf);fmsg_set("Type a name, Enter to confirm, Esc to keep");return 0;}
uint32_t files_rename(void){files_reset();if(sel==NONE||sel>=view_n){fmsg_set("Select a file or folder first");return 0;}rename_on=1;strcopy(rbuf,ent[view[sel]].name,FS_NAME);rlen=length(rbuf);fmsg_set("Type a name, Enter to confirm, Esc to cancel");return 0;}
uint32_t files_delete(void){files_reset();if(sel==NONE||sel>=view_n){fmsg_set("Select a file or folder first");return 0;}uint32_t id=view[sel];uint32_t r=entry_delete(id);
 if(IS_ERR(r)){fmsg_set(err_text(r));return 0;}fmsg_set("Deleted");view_build();return 0;}
uint32_t files_format(void){if(disk_state!=2){fmsg_set("Nothing to format");return 0;}
 if(!format_armed){format_armed=1;rename_on=0;fmsg_set("Click Format disk again to ERASE the whole disk");return 0;}
 format_armed=0;if(disk_sectors/8<2048||disk_sectors/8>MAX_BLOCKS){fmsg_set("Unsupported disk size: requires 8 MiB to 8 GiB");return 0;}if(storage_format()){fs_changed();fmsg_set("Disk formatted as OceanFS 3");}else{fs_changed();fmsg_set("Format I/O failed; preserve disk and inspect driver");}return 0;}
uint32_t files_key(uint32_t ch){
 if(rename_on){if(ch==10){if(sel!=NONE&&sel<view_n){uint32_t id=view[sel];uint32_t r=entry_rename(id,rbuf);if(IS_ERR(r))fmsg_set(err_text(r));else{rename_on=0;select_entry(id);fmsg_set("Renamed");}}else rename_on=0;}
  else if(ch==8){if(rlen)rbuf[--rlen]=0;}else if(ch>=32&&ch<127&&rlen<FS_NAME-1){rbuf[rlen++]=ch;rbuf[rlen]=0;}return 0;}
 if(ch==258&&sel!=NONE&&sel>0){sel--;view_build();}else if(ch==258&&sel==NONE&&view_n){sel=0;view_build();}
 else if(ch==259&&view_n&&(sel==NONE||sel+1<view_n)){sel=sel==NONE?0:sel+1;view_build();}
 else if(ch==10)files_open();else if(ch==260)files_delete();else if(ch==8)files_up();return 0;}
uint32_t files_draw(uint32_t x,uint32_t y){view_build();
if(rename_on){text(x,y-28,(uintptr_t)"Rename:",COL_WARN);text(x+80,y-28,(uintptr_t)(rbuf+(rlen>70?rlen-70:0)),COL_TEXT);}else{char path[110];path_of(cwd,path,sizeof path);text(x,y-28,(uintptr_t)path,accent());}
for(uint32_t j=0;j<11;j++){uint32_t idx=scroll+j;if(idx>=view_n)break;uint32_t id=view[idx],ry=y+j*30;round_rect(x,ry,760,28,5,idx==sel?0x264F70:((j&1)?0x14283A:0x192E41));
if(ent[id].type==T_DIR){round_rect(x+12,ry+6,11,6,2,0xD2A34F);round_rect(x+12,ry+10,23,13,3,0xF0CA78);}else{round_rect(x+16,ry+5,14,19,3,0x82B8DA);rect(x+19,ry+10,7,1,0x19394C);rect(x+19,ry+15,7,1,0x19394C);}
char shown[62];strcopy(shown,ent[id].name,sizeof shown);text(x+48,ry+4,(uintptr_t)shown,COL_TEXT);if(ent[id].type==T_DIR)text(x+640,ry+4,(uintptr_t)"Folder",COL_MUTED);else{char size[20];size[0]=0;if(ent[id].size>=1048576){snum(size,sizeof size,ent[id].size/1048576);sadd(size,sizeof size," MiB");}else if(ent[id].size>=1024){snum(size,sizeof size,ent[id].size/1024);sadd(size,sizeof size," KiB");}else{snum(size,sizeof size,ent[id].size);sadd(size,sizeof size," B");}text(x+640,ry+4,(uintptr_t)size,COL_MUTED);}}
if(!view_n)text(x+18,y+18,(uintptr_t)"This folder is empty. Create something.",COL_MUTED);text(x,y+344,(uintptr_t)fmsg,COL_WARN);return 0;}
uint32_t files_home(void){cwd=0;fs_changed();return 0;}
uint32_t files_notes(void){uint32_t id=find_child(0,"Notes");if(id!=NONE&&ent[id].type==T_DIR)cwd=id;else cwd=0;fs_changed();return 0;}
uint32_t storage_meter(uint32_t x,uint32_t y,uint32_t w){uint32_t free=free_blocks(),total=total_blocks>DATA_START?total_blocks-DATA_START:1;round_rect(x,y,w,8,4,0x102334);round_rect(x,y,w*(total-free)/total,8,4,accent());return 0;}
uint32_t fs_label(void){return (uint32_t)(uintptr_t)(disk_state==1?"OceanFS disk":disk_state==2?"Disk: no FS":disk_state==3?"Read-only":"RAM session");}
uint32_t fs_status(void){return (uint32_t)(uintptr_t)(disk_state==1?"OceanFS disk - changes are written immediately":disk_state==2?"Disk is not OceanFS - untouched until you Format":disk_state==3?"Disk error / writes disabled / preserve disk for recovery":"No IDE disk - RAM only, lost at power-off");}
uint32_t note_status(void){return (uint32_t)(uintptr_t)(s[24]==3?"Saved to OceanFS disk":s[24]==1?"Saved in RAM - lost at power-off":s[24]==2?"No room: file table full or too many Notes":s[24]==5?"Not opened: binary file or over 1 MiB":s[24]==4?"Save FAILED - volume read-only":"Unsaved changes / 1 MiB ASCII editor / OceanFS 3");}

/* ---- Storage info (Settings) ---- */
uint32_t storage_draw(uint32_t x,uint32_t y){char b[96];uint32_t files=0,dirs=0;for(uint32_t i=1;i<FS_ENTRIES;i++){if(ent[i].type==T_FILE)files++;else if(ent[i].type==T_DIR)dirs++;}
 b[0]=0;if(disk_state==1){sadd(b,sizeof b,"Storage: OceanFS on IDE disk, ");snum(b,sizeof b,total_blocks/256);sadd(b,sizeof b," MiB");}
 else if(disk_state==2)sadd(b,sizeof b,"Storage: disk found, not OceanFS (untouched)");else if(disk_state==3)sadd(b,sizeof b,"Storage: disk unusable or write failed");else sadd(b,sizeof b,"Storage: no IDE disk detected");
 text(x,y,(uintptr_t)b,accent());b[0]=0;sadd(b,sizeof b,"Files: ");snum(b,sizeof b,files);sadd(b,sizeof b,"  Folders: ");snum(b,sizeof b,dirs);sadd(b,sizeof b,"  Entries: ");snum(b,sizeof b,files+dirs);sadd(b,sizeof b," of 8192");text(x,y+24,(uintptr_t)b,COL_TEXT);
 b[0]=0;sadd(b,sizeof b,"Free: ");snum(b,sizeof b,free_blocks()/256);sadd(b,sizeof b," MiB / max file 1 GiB");text(x,y+48,(uintptr_t)b,COL_MUTED);return 0;}
uint32_t display_draw(uint32_t x,uint32_t y){char b[100];b[0]=0;sadd(b,sizeof b,"Resolution: ");snum(b,sizeof b,width);sadd(b,sizeof b," x ");snum(b,sizeof b,height);sadd(b,sizeof b," / 32-bit");text(x,y,(uintptr_t)b,COL_TEXT);text(x,y+30,(uintptr_t)"Native-size antialiased fonts / coverage-smoothed geometry",COL_MUTED);text(x,y+60,(uintptr_t)"Mode selected at boot. No live resolution switch yet.",COL_MUTED);text(x,y+90,(uintptr_t)(theme?"Accent: Seafoam":"Accent: Ocean blue"),accent());storage_draw(x,y+146);storage_meter(x,y+236,650);return 0;}

/* ---- Terminal ---- */
static uint32_t resolve_dir(const char*p){uint32_t d=cwd;if(*p=='/'){d=0;p++;}while(*p){char part[FS_NAME];uint32_t n=0;while(*p&&*p!='/'){if(n<FS_NAME-1)part[n++]=*p;p++;}part[n]=0;while(*p=='/')p++;if(!n||equal(part,"."))continue;if(equal(part,"..")){if(d>=FS_ENTRIES)return NONE;d=ent[d].parent;if(d>=FS_ENTRIES)return NONE;continue;}uint32_t c=find_child(d,part);if(c==NONE||ent[c].type!=T_DIR)return NONE;d=c;}return d;}
static void report(uint32_t r,const char*ok){if(IS_ERR(r)){ans_add(err_text(r));}else ans_add(ok);}
static uint32_t parse_size(const char*p){uint32_t n=0;if(!*p)return NONE;while(*p){if(*p<'0'||*p>'9'||n>MAX_FILE/10)return NONE;n=n*10+(*p++-'0');if(n>MAX_FILE)return NONE;}return n;}
static void terminal_run(void){
 char*arg=command;while(*arg&&*arg!=' ')arg++;if(*arg){*arg++=0;while(*arg==' ')arg++;}
 char*arg2=arg;while(*arg2&&*arg2!=' ')arg2++;if(*arg2){*arg2++=0;while(*arg2==' ')arg2++;}
 const char*c=command;ans_clear();
 if(equal(c,"help"))ans_add("help ver clear about res theme pwd ls cd\nmkdir touch cat hex rm mv write mkfile truncate\ndisk df format\nExample: write hi.txt hello  |  cat hi.txt\nformat erase = ERASE and format an attached disk");
 else if(equal(c,"ver"))ans_add("OceanOS 0.5.0 / Tidal compiler / OceanFS 3 / BIOS x86");
 else if(equal(c,"about"))ans_add("Native OceanOS desktop in Tidal.\nOceanFS on IDE disk; RAM-only without a disk.\nNo network or app compatibility yet.");
 else if(equal(c,"res")){ans_num(width);ans_add("x");ans_num(height);ans_add(", 32-bit VESA framebuffer");}
 else if(equal(c,"theme")){theme_toggle();ans_add("Accent theme changed.");}
 else if(equal(c,"clear")){}
 else if(equal(c,"pwd")){char q[64];path_of(cwd,q,sizeof q);ans_add(q);}
 else if(equal(c,"ls")){uint32_t shown=0,total=child_count(cwd);for(uint32_t pass=0;pass<2;pass++)for(uint32_t i=1;i<FS_ENTRIES;i++)if(ent[i].type&&ent[i].parent==cwd&&((pass==0)==(ent[i].type==T_DIR))){if(shown<8){ans_add(ent[i].name);if(ent[i].type==T_DIR)ans_add("/");else{ans_add("  ");ans_num(ent[i].size);ans_add(" B");}ans_add("\n");}shown++;}
  if(total>8){ans_num(total-8);ans_add(" more...");}else if(!total)ans_add("(empty)");}
 else if(equal(c,"cd")){uint32_t d=*arg?resolve_dir(arg):0;if(d==NONE)ans_add("No such folder");else{cwd=d;fs_changed();}}
 else if(equal(c,"mkdir")){report(entry_make(cwd,arg,T_DIR,0),"Folder created");fs_changed();}
 else if(equal(c,"touch")){uint32_t e=find_child(cwd,arg);if(e!=NONE)ans_add("Already exists");else report(entry_make(cwd,arg,T_FILE,""),"File created");fs_changed();}
 else if(equal(c,"cat")){uint32_t e=find_child(cwd,arg);if(e==NONE)ans_add("No such file");else if(ent[e].type==T_DIR)ans_add("That is a folder");else{if(!ent[e].size)ans_add("(empty file)");else{char t[420];uint32_t n=ent[e].size;if(n>sizeof(t)-1)n=sizeof(t)-1;uint32_t got=fs_read_at(e,0,t,n);if(IS_ERR(got))ans_add("Read error");else{for(uint32_t j=0;j<got;j++)if((uint8_t)t[j]<32&&t[j]!='\n'&&t[j]!='\t')t[j]='.';t[got]=0;ans_add(t);if(got<ent[e].size)ans_add("\n[preview truncated]");}}}}
 else if(equal(c,"rm")){uint32_t e=find_child(cwd,arg);if(e==NONE)ans_add("No such file or folder");else report(entry_delete(e),"Deleted");fs_changed();}
 else if(equal(c,"mv")){uint32_t e=find_child(cwd,arg);if(e==NONE)ans_add("No such file or folder");else report(entry_rename(e,arg2),"Renamed");fs_changed();}
 else if(equal(c,"write")){uint32_t e=find_child(cwd,arg);if(e!=NONE&&ent[e].type==T_DIR)ans_add("That is a folder");else if(e!=NONE)report(entry_write_text(e,arg2),"Written");else report(entry_make(cwd,arg,T_FILE,arg2),"Created and written");fs_changed();}
 else if(equal(c,"mkfile")){uint32_t size=parse_size(arg2);if(size==NONE)ans_add("Size must be decimal bytes, 0..1073741824");else if(find_child(cwd,arg)!=NONE)ans_add("Already exists");else{uint32_t id=entry_make(cwd,arg,T_FILE,"");if(IS_ERR(id))report(id,"");else{uint32_t r=fs_begin_replace(id);uint8_t zero[BLOCK];memset(zero,0,BLOCK);for(uint32_t left=size;left&&!IS_ERR(r);){uint32_t n=left>BLOCK?BLOCK:left;r=fs_append(zero,n);left-=n;}if(IS_ERR(r))fs_abort();else r=fs_finish();report(r,"Binary file created");fs_changed();}}}
 else if(equal(c,"truncate")){uint32_t size=parse_size(arg2),id=find_child(cwd,arg);if(size==NONE)ans_add("Size must be decimal bytes, 0..1073741824");else report(fs_truncate(id,size),"File resized");fs_changed();}
 else if(equal(c,"hex")){uint32_t id=find_child(cwd,arg);uint8_t bytes[32];uint32_t n=fs_read_at(id,0,bytes,sizeof bytes);if(IS_ERR(n))report(n,"");else{const char*h="0123456789ABCDEF";for(uint32_t i=0;i<n;i++){char t[4]={h[bytes[i]>>4],h[bytes[i]&15],' ',0};ans_add(t);if(i%16==15)ans_add("\n");}if(!n)ans_add("(empty)");}}
 else if(equal(c,"disk")){ans_add(disk_state==1?"OceanFS disk mounted (":disk_state==2?"IDE disk found but not OceanFS; untouched (":disk_state==3?"IDE disk unusable or write failed (":"No IDE disk; RAM only (");ans_num(disk_sectors/2);ans_add(" KiB)");}
 else if(equal(c,"df")){uint32_t used=0;for(uint32_t i=1;i<FS_ENTRIES;i++)if(ent[i].type)used++;ans_add("Entries used: ");ans_num(used);ans_add(" of 8192\nFree: ");ans_num(8192-used);ans_add("\nFree KiB: ");ans_num(free_blocks()*4);ans_add(disk_state==1?"\nBacked by OceanFS 3 disk":"\nRAM/readonly mode");}
 else if(equal(c,"format")){if(disk_state!=1&&disk_state!=2)ans_add("No formattable disk attached");else if(!equal(arg,"erase"))ans_add("This ERASES the whole disk. Type: format erase");else{ans_add(storage_format()?"Disk formatted as OceanFS":"Format failed");fs_changed();}}
 else if(*c)ans_add("Unknown command. Type help.");
 clen=0;command[0]=0;}
uint32_t terminal_key(uint32_t ch){if(ch==8){if(clen)command[--clen]=0;}else if(ch==10)terminal_run();else if(ch>=32&&ch<127&&clen<sizeof(command)-1){command[clen++]=ch;command[clen]=0;}return 0;}
uint32_t terminal_draw(uint32_t x,uint32_t y){char q[64];path_of(cwd,q,sizeof q);text(x,y,(uintptr_t)"OceanOS console 0.3.0",accent());text(x+350,y,(uintptr_t)q,COL_MUTED);text(x,y+24,(uintptr_t)"Type help to see commands.",COL_MUTED);text(x,y+55,(uintptr_t)answer,COL_TEXT);text(x,y+362,(uintptr_t)"ocean> ",0x7CDFCE);text(x+56,y+362,(uintptr_t)(command+(clen>56?clen-56:0)),COL_TEXT);return 0;}
