# 0.3

Windows-inspired desktop redesign, new taskbar/start/window chrome, snapping, virtual filesystem tree, notes editor, explorer, settings, terminal, task list, Tidal Studio, declarative UI commands, print scaling in windows, standalone build and expanded unit tests.

This is a desktop dialect release, not a merged release of the earlier game SDK.
