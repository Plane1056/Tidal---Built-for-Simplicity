# OceanOS Desktop 0.3

A Windows-11-inspired browser desktop, configured and composed in Tidal. Original local SVG icons and CSS wallpaper; no Microsoft branding or external assets. This project is not affiliated with Microsoft and does not run Windows programs.

## Launch — no server

Extract the ZIP and open **index.html**. Keep its neighboring files/folders in place. No terminal, installation, server, npm or internet is required.

Alternatively open **OceanOS-Standalone.html**, the same build with all runtime/style assets embedded. That file can be copied on its own. Both launch modes use only local assets and deliberately disable network connections through CSP.

Requires a modern desktop browser with dialog, pointer events, Canvas-independent DOM/CSS, Blob downloads and local script execution. Browser policies may restrict file downloads/storage. Mobile/touch support is partial; desktop mouse/keyboard is the target.

## What's new

- Centered (or left-aligned) taskbar with running/active indicators and task buttons.
- Start menu with app search and pinned/all-app launchers.
- Desktop shortcuts; right-click desktop menu; calendar and appearance flyout.
- Translucent surfaces, original bloom/aurora/dusk/solid wallpapers, dark/light theme and accents.
- Draggable/resizable windows, minimize/restore, maximize, double-click titlebar, edge snapping.
- File Explorer with virtual folders, import, export, rename, recursive delete and one-level undo-delete.
- Notepad with save/save-as, multiple windows, word wrap, character/line counts and dirty-state prompts.
- Settings, virtual-file JSON backup/restore, accessibility preference.
- Safe utility Terminal, application-window Task Manager, and Tidal Studio.
- Tidal Studio imports/exports source, validates it and applies a new desktop without a server.

## What runs in Tidal

The boot program in oceanos.tidal defines desktop settings, app registration, shortcuts, pinned apps, startup apps, window sizes, static content, layout and button actions. `washup ocean` enables this desktop dialect. `washup language` enables print, including `print "Hello World"x4` INSIDE a window.

The JavaScript interpreter and standard library implement the browser adapters, window manager, filesystem operations and complex app components. `component explorer` asks that runtime to mount its built-in explorer. The explorer's implementation is not written in Tidal function bodies. This is not a self-hosted language or a complete OS written entirely in Tidal.

This desktop dialect does NOT merge the earlier 2D/game SDK. Shape/game entities, expression variables, repeats, 3D, conditionals, user-defined functions and runtime event blocks are not implemented here. No claims of prior SDK compatibility beyond documented commands. See docs/SYNTAX.md.

## Change the desktop

Open Tidal Studio. Edit the active source, click Validate, then Apply desktop. Applying closes all open windows after confirmation; export unsaved content first. Theme preferences set in Settings override boot theme values until those preferences are removed/reset in browser storage.

Use the sample in examples/custom-desktop.tidal to try another desktop. Source imported/applied in Studio is session-only; export it to keep it. To permanently change the default, edit oceanos.tidal and run the OPTIONAL developer helper `python3 build.py` (Windows `py build.py`). That refreshes index.html and OceanOS-Standalone.html. Launching never requires Python.

## Files and persistence

Files live in a virtual, flat-ID folder tree backed by localStorage under oceanos03:. This is not direct filesystem access. Local-file storage behavior varies by browser and privacy settings. Writes fall back to memory with a warning when browser storage is unavailable/full. Export files or a JSON backup before closing. Preferences are stored separately. No cloud sync, account authentication or encryption.

File Explorer: double-click a folder/file to open it. Select an item before Rename/Delete/Export. Import a user-selected text file, or drop text files into Explorer. Imported data is treated as text; no binary asset viewer or executable file association is provided. Refresh open Explorer windows after changes made elsewhere.

Notepad Ctrl+S saves; Ctrl+Shift+S saves as. Existing files opened from Explorer use their original virtual ID. Save as stores in Documents if present, otherwise root. Closing a dirty note asks before discarding. A browser reload may show an unsaved-change prompt; do not rely on it for backups.

## Keyboard and windows

- Ctrl+Esc: Start menu.
- Esc: dismiss desktop menus.
- Ctrl+S / Ctrl+Shift+S: save/save-as in Notepad.
- Ctrl+Enter: validate source in Studio.
- Drag normal titlebars to move; drag to left/right edge to snap, top edge to maximize.
- Double-click titlebar or use maximize button to maximize/restore.
- Taskbar click minimizes the active app window or restores/focuses a minimized one.

Snapped windows should be restored using maximize/restore before dragging. Browser/system-reserved shortcuts are not overridden. Task Manager lists application windows, not actual browser/native processes. Network and hardware tray status are not real device controls.

## Project layout

- index.html: folder-based entry and embedded Tidal boot program.
- OceanOS-Standalone.html: generated one-file entry.
- styles.css: desktop appearance.
- tidal/parser.js: command parser and validator.
- tidal/files.js: virtual file model.
- tidal/desktop.js: browser runtime, windows and standard app components.
- oceanos.tidal: editable default OS composition.
- docs/: implemented syntax, architecture, limitations and manual checks.
- tests/test.cjs: parser and virtual-file automated tests.
- build.py: optional development rebuild.

Developer checks: `node tests/test.cjs` and `python3 build.py`. No npm dependencies. JavaScript syntax, source parsing and file-model tests were executed. Interactive visual/browser checks have NOT been executed in this environment.

## Safety / licensing

Trusted local-development prototype, not a security-reviewed third-party app container. No eval, arbitrary JS command, system shell, network API or native executable support is exposed by the language/terminal. Runtime and custom desktop content share one browser page, not isolated app origins. A hostile script injected into trusted runtime code could access all virtual data. Choose a license before public open-source distribution; none is selected here.
