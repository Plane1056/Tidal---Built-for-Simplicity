from pathlib import Path
import re
root=Path(__file__).resolve().parent
source=(root/'oceanos.tidal').read_text(encoding='utf-8')
if '</script' in source.lower(): raise ValueError('Unsafe embedded source')
page=(root/'index.html').read_text(encoding='utf-8')
page,count=re.subn(r'(<script type="text/tidal" id="tidal-source">)[\s\S]*?(</script>)',lambda m:m[1]+source+m[2],page,count=1)
if count!=1: raise ValueError('Missing boot source')
(root/'index.html').write_text(page,encoding='utf-8')
standalone=page
for rel in re.findall(r'<link rel="stylesheet" href="([^\"]+)">',page):
    standalone=standalone.replace('<link rel="stylesheet" href="'+rel+'">','<style>'+(root/rel).read_text(encoding='utf-8')+'</style>')
for rel in re.findall(r'<script src="([^\"]+)"></script>',page):
    code=(root/rel).read_text(encoding='utf-8')
    if '</script' in code.lower(): raise ValueError('Unsafe inline script')
    standalone=standalone.replace('<script src="'+rel+'"></script>','<script>'+code+'</script>')
(root/'OceanOS-Standalone.html').write_text(standalone,encoding='utf-8')
print('Built folder and standalone OceanOS with Tidal Code')
