# Manual browser acceptance checklist — not yet executed

Run in each intended browser/version, including direct local-file launch:

1. Extract folder; open index.html without any server. Confirm no failed resource loads. Repeat using only OceanOS-Standalone.html copied elsewhere.
2. Check desktop wallpaper/shortcuts, centered taskbar, Start menu search, app launches and clock/calendar.
3. Drag/resize windows, minimize/restore through taskbar, maximize/double-click, snap to each edge and restore.
4. Switch light/dark/accent/wallpaper/alignment in Settings. Check text contrast, menus and resize to a smaller workspace.
5. In Explorer create folders/files, rename, open, delete a nested folder, undo-delete; refresh after Terminal writes.
6. In Notepad type, save, save-as, export, open another file and close dirty windows; confirm loss prompts. Test Ctrl+S and Ctrl+Shift+S.
7. Import/drop user-selected text into Explorer; export it. Check download behavior under the browser's local-file policy.
8. Reload. Verify persisted files/preferences if supported; block storage and verify memory-only warning plus successful export.
9. Export JSON file backup; create extra files; restore backup and refresh Explorer. Confirm replacement warning and malformed-backup rejection.
10. Enter Terminal help/ls/pwd/cd/cat/mkdir/touch/open. Confirm it cannot execute JS/native shell commands.
11. In Studio validate bad source and confirm current desktop remains. Apply valid source after confirmation; check original desktop can be restored by browser reload.
12. Use sample custom-desktop.tidal and confirm print "Hello World"x2 renders once at 32px.
13. Open Task Manager; switch/close windows, then close Task Manager. Verify periodic refresh timer stops.
14. Tab through Start controls, dialogs and editors. Escape dismisses menus; Ctrl+Esc opens Start where the browser permits it. Test reduced motion.
15. No microphone/camera/clipboard/network requests. Verify network-blocking CSP and no remote dependencies in browser developer tools.

Known limitations: touch UI is partial; snapped windows must restore before dragging; half-screen sizes may be cramped on small displays; browser-reserved shortcuts can win; no automated browser/visual tests accompany this release.
