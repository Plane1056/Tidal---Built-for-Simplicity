# Architecture and next steps

## Current layering

1. index.html contains the launcher DOM and an embedded text/tidal boot program.
2. parser.js validates it into a desktop config plus window/component declarations.
3. desktop.js materializes those declarations and routes button actions.
4. files.js is the virtual tree model; desktop.js adapts it to browser storage/file pickers/downloads.
5. styles.css supplies the Windows-inspired visual language.

No fetch, XHR, remote fonts, image downloads, server calls, native binaries or package installation is used. The standalone build embeds CSS and scripts; the folder build loads relative local files. The optional Python builder only runs during development.

The parser never evaluates source as JavaScript. Dynamic source is displayed with textContent. Small developer-owned SVG path strings are used for original icons. No Windows/Microsoft graphics are included. The result is an inspired desktop UI, not a pixel-identical clone.

## What is not "all Tidal" yet

Tidal currently describes composition and actions. Browsers execute the JavaScript interpreter, and complex built-ins such as explorer are JS standard-library components. We have NOT implemented a general Tidal application language with functions, mutable state, async I/O and event callbacks. Do not describe this as a self-hosted Tidal OS, Windows compatibility layer or complete browser OS security architecture.

The earlier language/game SDK has not been merged. This package deliberately states its command surface. A sensible next implementation step is one parser/AST/module registry shared by language, 2D, game and ocean environments, with compatibility tests for existing programs before claiming unification.

## Persistence/security boundaries

LocalStorage uses oceanos03:files and oceanos03:prefs. Documents remain in the browser profile; file:// storage behavior is browser-dependent and may change when a folder is moved. Exports/backups are the recovery path. There is no user account, access control, encryption, sync or actual disk filesystem.

The runtime has a network-blocking CSP, but inline scripts are allowed for the standalone build. There are no per-app sandbox origins: all apps are trusted components in one document. This is not safe as an unreviewed third-party HTML/app installation platform. Imported source can create UI using a limited command vocabulary, not arbitrary code; resource bounds are basic validation, not hard CPU/memory isolation.

## Next substantial language work

- Consolidate interpreters and version the AST/standard libraries.
- Add explicit state, safe event handlers, functions, collections and component properties.
- Move standard apps progressively into real Tidal implementations once primitives exist.
- IndexedDB filesystem transactions, recovery, live file-change subscriptions and robust undo.
- Dedicated app focus manager, keyboard navigation, screen-reader audit, touch controls.
- Worker execution budgets and audited capability-based services before untrusted packages.
- Browser integration/visual regression tests alongside existing parser/file-model unit tests.
