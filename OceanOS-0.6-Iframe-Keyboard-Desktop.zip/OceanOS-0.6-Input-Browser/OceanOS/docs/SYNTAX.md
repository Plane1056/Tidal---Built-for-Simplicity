# Tidal ocean desktop dialect 0.3 — implemented syntax

Statements occupy one physical line. Keywords and identifiers are case-sensitive. Text uses double-quoted JSON strings (`\n`, `\"`, `\\` escapes). `//` comments are ignored outside strings. No semicolons. Identifiers match `[A-Za-z_]\w*`. Imports must precede commands. This is a declarative desktop dialect, not the earlier game interpreter.

## Imports

`washup ocean` activates desktop commands. `washup language` activates print. Other environments are rejected. Multiple imports are harmless.

## Top level

```
desktop title "OceanOS"
desktop subtitle "Your space. Your ocean."
desktop theme dark
desktop accent "#73c9ff"
desktop wallpaper bloom
taskbar position center
start greeting "Welcome back"
app notes "Notepad" icon notes
pin notes
shortcut notes
autorun notes
```

- title/subtitle/greeting accept quoted text.
- theme: dark or light.
- accent: exactly #RRGGBB, quoted.
- wallpaper: bloom, aurora, dusk, solid.
- position: center or left.
- app ID "LABEL" icon ICON: register launcher for a window ID. Icons: folder, notes, code, terminal, settings, tasks, ocean.
- pin ID: taskbar shortcut. Start currently lists all registered apps, not a separate pin-only subset.
- shortcut ID: desktop shortcut.
- autorun ID: open during boot.

References may be forward-declared; all are validated. Registered app IDs must have window definitions. Duplicate app/window IDs are errors. Repeated pin/shortcut/autorun declarations are deduplicated.

## Windows

```
window hello "My app"
size 760 520
heading "Hello"
text "A native-looking Tidal window."
end
```

Window defaults are 760×520 CSS pixels. Width range 320–1800, height 250–1200; actual launch size is constrained to the workspace. No nested windows. Each block ends with end on its own line. Declarations do not open windows unless launched/autorun. Window ID need not be an app ID if opened by a button; all registered launchers require windows.

## Content/layout

- `heading "TEXT"`: heading.
- `text "TEXT"`: plain paragraph.
- `print "TEXT"`: paragraph with 16px base font; requires language.
- `print "Hello World"x4`: one text item at 4× base size, not four repetitions. Also accepts whitespace before x4. Multiplier numeric >0 and <=20, no expression.
- `hero "TITLE" "SUBTITLE"`: prominent banner.
- `card "TITLE" "BODY"`: bordered content card.
- `row` ... `endrow`: horizontal wrapping group. Rows cannot nest; close before end.
- `button "LABEL" open WINDOW_ID`: launch/focus that window.
- `button "LABEL" notify "MESSAGE"`: toast.
- `button "LABEL" theme dark|light`: session preference, persisted if browser storage allows.
- `button "LABEL" wallpaper bloom|aurora|dusk|solid`: update wallpaper preference.

Text is inserted as textContent, never interpreted as markup. No arbitrary style attributes or HTML in source.

## Standard components

```
window files "File Explorer"
size 900 570
component explorer
end
```

A component must be the only content item in its window; size is permitted. Available:

| Component | Runtime-provided behavior |
|---|---|
| explorer | Virtual folders/files, import/export, rename, delete/undo |
| notes | Editable plain text, save/save-as/export and dirty-state prompts |
| studio | Tidal source editor, validation, application and source export |
| terminal | Limited filesystem/app utilities, no native shell |
| settings | Theme/wallpaper/accent, taskbar alignment, backup/restore, motion setting |
| tasks | List/focus/close app windows |

These are standard-library UI adapters implemented in JavaScript, not user-defined Tidal functions. Runtime services find the first registered window using a relevant component (e.g. Explorer opens files in the first notes window definition). Keep one canonical app per component for predictable associations. Opening a file creates a new Notepad window. Launching an already-open app focuses its first window; Notepad New creates an additional window.

## Terminal commands

help; ls; pwd; cd "Folder"; cd ..; cd /; cat "file.txt"; mkdir "Folder"; touch "file.txt"; echo "text"; apps; open APP_ID; date; whoami; clear.

Commands are entered individually. Relative resolution is one folder/file name, not a full path parser. Quotes allow spaces. Terminal writes use the same virtual files as Explorer. No piping, shell expansion, processes, scripts, network, or JavaScript execution.

## Limits / errors

200000 source characters; 30 window definitions; 100 content items per window; 15 simultaneous windows. Most parse errors include a line number; whole-program reference errors may not. Validation occurs before the current desktop is replaced. Applying valid source deliberately closes current windows after a confirmation.

Virtual storage: 400 nodes via normal file creation; 200000 text characters per file; text imports <=200000 bytes, max 20 per import/drop; JSON backup import <=2000000 bytes and 400 nodes; persistence serialization <=1800000 characters before memory fallback. Browser quota may be lower. Rename/delete do not automatically update already-open buffers. Undo-delete is one global last deletion, not a persistent trash bin. Appearance preferences override boot values when present.

Not implemented: expressions/variables/loops; user functions; event blocks; arbitrary modules/assets; numeric 2D positioning; spawn/game commands; 3D; widgets beyond the above declarative blocks. The former 0.2 editor/save button primitives are replaced by standard components and are not backward-compatible.


## Input/Browser 0.6

Additional standard component names: framebrowser and inputhelp. They mount the iframe Web Browser and Keyboard & Desktop app. They are runtime-provided browser adapters, not arbitrary Tidal code execution. See the package-level README and docs for keyboard/framing constraints.
