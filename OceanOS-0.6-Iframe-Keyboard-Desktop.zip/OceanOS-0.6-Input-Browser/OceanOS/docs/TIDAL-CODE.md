ENVIRONMENTS
washup language — text and echo
washup 2D — decorative shapes
washup game — player/enemy/physics simulation
washup ocean — desktop program; separate from scene mode

TEXT
print "Hello World"x4 [as name]
echo "Ready"
align left|center|right

SHAPES
spawn square|rectangle|circle|ellipse|triangle|line [scale (n)] [as name]
select name
x n / y n / z n
scale (n) / width n / height n
color CSS_COLOR / stroke CSS_COLOR|none
thickness n / opacity n / rotate n
spin degreesPerSecond / move vx vy / pulse amplitude hz
hide / show / delete

SCENE
background CSS_COLOR / grid on|off / zoom n

VARIABLES AND MATH
let size = 2 + 1
repeat 5 {  // body on following lines; closing } on own line
  spawn square
  x index - 2
}
+ - * / % ^, parentheses, pi, tau
sin/cos/tan/abs/sqrt/floor/ceil/round(x)
min(a,b), max(a,b)

GAME
spawn player|enemy|wall|coin|medkit|goal|spawner [as name]
control wasd|arrows [speed] / control off
speed n / health n / damage n
shoot on|off / fire rate n / bullet speed n / bullet damage n
behavior chase|wander|still / behavior patrol x|y radius
value n / heal n / interval n / limit n
world width height / camera fixed|follow / hud on|off
title "Name" / win score n / win survive seconds / win clear

OCEAN (depends on host's installed desktop compiler)
desktop title|subtitle "Text"
desktop theme dark|light / accent "#RRGGBB" / wallpaper bloom|aurora|dusk|solid
app id "Name" icon code|ocean|folder|notes|terminal|settings|tasks
pin id / shortcut id / autorun id
window id "Title"
size width height
hero "Title" "Subtitle" / card "Title" "Text"
heading "Text" / text "Text" / print "Text"x2
row / endrow
button "Label" open id / notify "Text" / theme dark|light / wallpaper bloom
component explorer|notes|studio|terminal|settings|tasks|code
end
Horizon host additionally supports its browser, bookmarks, calculator and workspaces.

NOT IMPLEMENTED
3D, user-defined functions, if/while, runtime event blocks, arbitrary JS/network imports, binary assets, audio and multiplayer.
Scene variables/loops are compile-time numbers, not a general runtime scripting language.
Ocean and 2D/game execute as separate program modes, not one mixed scene.


SEMANTICS AND DEFAULTS

Scene command keywords/imports are case-insensitive. Variable/object identifiers and expression function names are case-sensitive. Ocean syntax follows the installed desktop compiler (case-sensitive in the supplied host). One command per physical line. JSON-style double-quoted strings and // comments outside strings are supported. Numeric statements accept expressions unless a two-argument command requires whitespace-free tokens (move/pulse/world). Parenthesize and omit spaces within those argument expressions.

Scene statements construct a scene at compile time. The most recently created or selected object is the property target. x/y/z set absolute values. x points right, y up, higher z draws in front. One unit is 40 CSS pixels at zoom 1. Text base font 16px; x4 scales one text object, never repeats it. scale must be positive. Variables are numbers. Repeat index starts at 0; nested loops restore the previous index. Loop variable assignments other than index persist. pi/tau/index cannot be assigned. ^ is right-associative and exponentiation precedes unary minus.

Decorative shapes have no collisions. width/height are base dimensions; scale multiplies them. Game collisions are axis-aligned rectangles, including circles. Rotation and pulse are visual and do not rotate/change hitboxes. z does not affect collision. Initial game entities must be in world bounds and the player cannot begin inside a wall. Game actors collide with walls/world, not each other; enemy contact can damage player. Chase is direct movement, not obstacle pathfinding. Default player speed 5, health 5, input WASD, shooting off. Enemy default speed 1.8, health 2, damage 1, chase behavior. Patrol uses its initial center and positive radius. Wander is deterministic directional variation.

Shooting uses last movement direction (right initially); bullets last 2 seconds. Default fire rate 5, bullet speed 12, damage 1. Player has one second of contact invulnerability. Coins default value 1, medkits default healing 2. Enemies award one point when defeated, so win score includes kills and coins. Goals win on contact regardless of explicit rule; death wins priority over victory on the same step. Last explicit win rule wins. No explicit rule means no automatic win except goals.

Spawner interval defaults 3 seconds, limit 10 living owned enemies. Its health/damage/speed configure emitted enemies, NOT destructible portal health. Portals cannot be shot/destroyed; a visible portal prevents win clear. Emitted enemies skip a spawn blocked by walls. Hidden objects neither render nor act. Delete removes the target and clears selection.

VALIDATION LIMITS

Source <=200000 characters; expressions <=500 characters; 40 nested expression atoms; finite numeric magnitude <=100000; 10 nested repeat blocks; repeat integer 0–1000; 20000 compile steps; 1500 authored objects. Preview editor tabs max 15; output retains last 120 console entries; inspector shows first 100 objects; gutter shows at most 15000 line numbers.

Zoom .1–5. World dimensions 2–1000. Opacity 0–1. Pulse amplitude >=0 and <1; frequency 0–100 Hz. Game speed >0 and <=30. Fire rate >0 and <=30; bullet speed >0 and <=60. Spawner interval >=.25 seconds; limit integer 1–100. Active bullets capped 200. Emitted-enemy cap 300 active visible enemies (authored enemy count may exceed that, within object limit). Game move/bullet substeps reduce tunneling but are not perfect continuous collision detection; avoid extreme velocities or very thin obstacles.

API

window.TidalEngine: VERSION, TidalError, compile(source, options), expression(source, vars), Runtime, Renderer, overlap.
compile returns kind 'scene' or 'ocean'. options.compileOcean is a host desktop compiler; validateColor can use CSS.supports. Scene return includes objects/config/messages/steps/imports. Runtime.load compiles then replaces valid scene atomically; ocean return is delegated to caller without replacing simulation. Runtime update(dt) caps step to 1/30; use fixed 1/60 updates. Runtime exposes keys Set, objects, config, player, state/time/score/kills. pause/resume/stop/dispose manage lifecycle; events are won/lost with score/time. Renderer renders to supplied Canvas; it owns no animation loop.

window.TidalCode.mount(windowAdapter, hostAdapter) mounts the editor. windowAdapter needs body, optional title, dirty, dispose. hostAdapter optionally provides fs/persist/download/compileDesktop/applyDesktop/openComponent. Returned API: newTab(name,text,fileId), validate(), run(), dispose(), element. Always call dispose on host close. See assets/code-app.js for implementation.
