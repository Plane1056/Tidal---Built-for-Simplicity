"""Optional development build. Not needed to launch index.html."""
from pathlib import Path
import re
root=Path(__file__).resolve().parent
source=(root/'oceanos.tidal').read_text(encoding='utf-8')
if '</script' in source.lower():
    raise ValueError('Embedded boot source must not contain a closing script tag')
page=(root/'index.html').read_text(encoding='utf-8')
page,count=re.subn(r'(<script type="text/tidal" id="tidal-source">)[\s\S]*?(</script>)',lambda m:m[1]+source+m[2],page,count=1)
if count!=1: raise ValueError('Boot source placeholder missing')
(root/'index.html').write_text(page,encoding='utf-8')
standalone=page.replace('<link rel="stylesheet" href="styles.css">','<style>'+(root/'styles.css').read_text(encoding='utf-8')+'</style>')
for name in ['parser','files','desktop']:
    script=(root/'tidal'/f'{name}.js').read_text(encoding='utf-8')
    if '</script' in script.lower(): raise ValueError('Unsafe inline script content')
    standalone=standalone.replace(f'<script src="tidal/{name}.js"></script>','<script>'+script+'</script>')
(root/'OceanOS-Standalone.html').write_text(standalone,encoding='utf-8')
print('Updated index.html boot source and OceanOS-Standalone.html')
