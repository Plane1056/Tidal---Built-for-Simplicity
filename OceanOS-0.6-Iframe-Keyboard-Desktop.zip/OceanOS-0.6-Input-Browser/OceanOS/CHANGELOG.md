# 0.6

Iframe Browser app, parent-page keyboard window controls/fallback switcher, optional fullscreen/Keyboard Lock requests, draggable persistent shortcuts, icon keyboard navigation/rename, Explorer list navigation. Tidal Code retained. Ready host provenance: supplied 0.5 extension integration, not a reconstructed Horizon release.
