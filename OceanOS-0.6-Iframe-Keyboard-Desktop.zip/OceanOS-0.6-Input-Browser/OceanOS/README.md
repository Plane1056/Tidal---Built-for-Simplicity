# OceanOS 0.6 ready build

Open index.html or OceanOS-Standalone.html directly. This build extends the supplied Tidal Code 0.5 integration (which was 0.3-based), keeping Code and adding iframe Web Browser, keyboard/window switcher and draggable icons. See ../README.md for current instructions, limits and installer guidance for a newer Horizon folder.
