# OceanOS 0.6 — Iframe Browser, Keyboard and Desktop Input

## Launch

Open **OceanOS-Standalone.html** at the top of this package. It is the complete updated build in one HTML file. Or open **OceanOS/index.html**, keeping its neighboring files together. No installation, server, terminal or network is required to launch. Internet is only needed for remote websites.

The ready build extends the supplied Tidal Code 0.5 package's 0.3-based integration. Tidal Code is kept, including its language/2D/game runner. The separate Horizon 0.4 archive was not available in this turn; its iframe-free browser, workspaces, etc. are NOT claimed to be present in this ready build. If you have that newer/custom folder, use the included installer on a COPY to retain those features and add this extension separately.

## Iframe Web Browser app

Launch Web Browser from desktop (double click), Start or taskbar. It is a NEW app using a real iframe, not a replacement for any existing iframe-free Ocean Browser in a different host.

- Multiple frame tabs, address/search entry, toolbar-request history, reload-requested, local home and external-open fallback.
- URLs accept HTTP/HTTPS, domains, text search, or ocean://home. Unsupported schemes and embedded credentials are rejected.
- The initial home is embedded static content; no remote site is contacted until navigation.
- Websites may reject embedding using X-Frame-Options or CSP frame-ancestors. This app cannot bypass that. A blank/error frame is not reported as successful page display.
- The URL bar shows the LAST TOOLBAR REQUEST, not the current path after following links inside a cross-origin frame. Back/Forward follow toolbar-request history only. Reload reloads the last requested URL. Open externally also opens that URL.
- A frame load event is NOT proof the site is visible or functional. OceanOS cannot reliably inspect remote frame errors or content.
- Embedded-site keyboard events do not propagate to OceanOS. Click browser toolbar, OS focus button, window titlebar or desktop before using OS shortcuts.
- Login, third-party cookies, popups, media or some scripts may fail depending on sandbox/site/browser policies. HTTPS is preferable; browsers may restrict insecure subframes.

Frames allow scripts, forms, same-origin site identity and sandboxed popups, but not top-level navigation or sandbox escape. Camera/microphone/geolocation are not granted. Direct same-origin app embedding is rejected in hosted mode to avoid casually exposing the host page to same-origin scripts. This is a prototype, not an audited hostile-site container. In particular, arbitrary redirects/same-origin deployments still require a proper security review. No unrestricted postMessage or browser-privileged bridge is installed.

## Keyboard control

These shortcuts work only when the browser/OS DELIVERS the key event to the OceanOS page. Ordinary pages cannot guarantee that Alt+Tab/Alt+F4 or OS-reserved shortcuts arrive. The real browser/OS can keep them.

| Shortcut | Action |
|---|---|
| Alt+Tab / Alt+Shift+Tab | Next/previous OceanOS window, if delivered; release Alt to commit |
| Ctrl+` / Ctrl+Shift+` | Fallback switcher; release Ctrl to commit |
| Esc while switcher open | Cancel switching |
| Enter while switcher open | Commit selection |
| Alt+F4 | Close active OS window if delivered |
| Ctrl+Shift+X | Close active OS window fallback (dirty prompts retained) |
| Ctrl+Alt+M | Minimize active window |
| Ctrl+Alt+Enter | Maximize/restore active window |
| Alt+Shift+Left/Right | Snap window left/right |
| Alt+Shift+Up/Down | Maximize/restore |
| Ctrl+Shift+F | Toggle browser fullscreen |
| Ctrl+Esc | Existing Start toggle if delivered |

The floating Switch button works without a special shortcut. The Keyboard button opens Keyboard & Desktop with all instructions. Optional Request Keyboard Lock asks for selected key codes after fullscreen, only where supported. It can capture only keys granted by the underlying OS, may fail for local-file contexts/browser policy, and does NOT guarantee Alt+Tab. Escape is deliberately not requested so browser fullscreen-exit behavior remains available. Release Keyboard Lock is always provided. Lock is released on fullscreen exit when supported.

Normal Tab navigation and text-editor shortcuts are not globally stolen. Global OS actions deliberately work while an OS editor has focus; its unsaved-change prompts remain active. Cross-origin iframe focus is a separate limitation. Full hardware/native keyboard ownership is not implemented or claimed.

## Draggable desktop icons

- Single click selects; DOUBLE CLICK launches. This replaces the previous single-click launch behavior.
- Drag with mouse/touch-pointer to move; default grid snap, clamped to the desktop.
- Positions and custom labels persist in browser storage when available; failed writes warn and are session-only.
- Arrow keys select a neighboring icon; Enter launches; F2 renames the shortcut label.
- Ctrl+Shift+arrows moves the selected icon one grid cell.
- Keyboard & Desktop toggles snap and arranges/resets positions/labels.
- Positions can overlap; automatic collision avoidance, multi-selection and desktop-file dragging are not implemented. This feature moves application shortcuts, not virtual document files.

Explorer additionally gets Up/Down/Home/End row selection plus F2 rename and Delete via its existing actions. Text editing is left alone. Resize clamps visible icon locations to the workspace.

## Tidal declarations

```
app framebrowser "Web Browser" icon ocean
app inputhelp "Keyboard & Desktop" icon settings
pin framebrowser
shortcut framebrowser
shortcut inputhelp

window framebrowser "Web Browser"
size 1120 720
component framebrowser
end
window inputhelp "Keyboard & Desktop"
size 920 690
component inputhelp
end
```

These are standard runtime components; their browser/input implementation is JavaScript, as with other OceanOS components. This does not add 3D/functions/if/while to Tidal. Tidal Code's prior scope and separate scene/desktop program modes are retained.

## Add to a newer/custom OceanOS folder

1. Back up the entire current OS folder.
2. Keep this package intact.
3. Run `python3 install.py /path/to/OceanOS-folder` (Windows `py install.py "C:\path\to\folder"`).
4. Open that folder's usual index.html.

Python is only a one-time developer install/build tool, never required for launch. The installer extends the existing component registry, source registrations, CSP and boot initialization; adds enhancements.js/css; and preserves other local script dependencies. It backs up edited files once in .input06-backup/ and rebuilds the standalone file. Generated standalone HTML is not separately backed up. It is not a transactional package manager; use the complete-folder backup to recover.

It was tested on the actual provided 0.5 package's integrated host. It is designed for the shared layout of 0.3/0.4/0.5 variants but NOT tested against an unavailable original Horizon 0.4 archive. Unsupported structural markers produce an error; review custom projects before installing. Rerunning is idempotent for default registrations and byte-stable for index.html.

## Testing and limitations

- 43 Tidal engine/example regression tests.
- 26 host parser/virtual-file regression tests.
- 15 mock-DOM/service checks for boot, Browser tabs/navigation/disposal, keyboard fallback, icon drag/selection, and Code integration.
- Script syntax/build/registration/CSP checks.

These are not real-browser tests. Actual Alt+Tab delivery, Keyboard Lock/fullscreen permission, real remote-site framing, pointer geometry, styling, focus and file:// persistence MUST be tested in target browsers; see docs/BROWSER-CHECKLIST.md. No browser binary was available in this environment.

No server-side proxy, security-header bypass, native keyboard driver, browser extension, permission escalation, cloud storage or arbitrary code evaluation is bundled. Source and local storage share a trusted browser page; this is not a production OS security boundary. No license is selected for public open-source distribution.
