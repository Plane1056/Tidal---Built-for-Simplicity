# Web-platform constraints

An ordinary browser OS only receives key events the host browser/platform delivers. Keyboard Lock can request selected keys, usually with fullscreen/user activation and browser/context limitations, but is explicitly limited to keys the underlying OS grants. It cannot guarantee native Alt+Tab or Alt+F4 takeover. There is no local security bypass here.

External iframe documents can refuse framing through X-Frame-Options or CSP frame-ancestors. Sandboxing, JavaScript, HTML attributes and page controls cannot override those server policies. Browser onload events do not reliably tell a parent that a remote page rendered successfully. Cross-origin parent scripts cannot inspect its current URL, DOM, title, content, errors or key events. This release therefore reports navigation requests/load events with qualified wording and offers an external-open fallback.

The source URL can also be affected by redirects, authentication, third-party cookies, mixed content and browser permissions. The browser toolbar deliberately tracks only its own address requests. It is an iframe host, not a separate complete browser engine.

References:
- https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/X-Frame-Options
- https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Content-Security-Policy/frame-ancestors
- https://developer.mozilla.org/en-US/docs/Web/API/Keyboard/lock
- https://developer.chrome.com/docs/capabilities/web-apis/keyboard-lock
