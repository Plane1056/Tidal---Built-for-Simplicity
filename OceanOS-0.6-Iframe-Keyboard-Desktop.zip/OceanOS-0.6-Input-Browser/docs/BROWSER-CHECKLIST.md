# Manual acceptance checklist — NOT executed here

1. Open root OceanOS-Standalone.html and OceanOS/index.html via file:// with no server. Check startup and Tidal Code preserved.
2. Double-click Web Browser. Verify real iframe exists with expected sandbox and no top-navigation permission; test allowed and framing-denied sites without falsely declaring success.
3. Try unsafe URLs (javascript:, data:, file:, credentials), invalid URLs, bare domains and text search. Test same-origin initial URL rejection when hosted via HTTP.
4. Use browser tabs/back/forward/reload and links inside a remote page. Confirm labels accurately describe requested-URL history rather than remote page history. Test external-open fallback/popups.
5. Focus an embedded page and observe that parent shortcuts may not arrive; click toolbar/OS focus to return. No promises of cross-origin keyboard interception.
6. Open multiple OS windows including dirty Notes/Tidal Code; test Alt+Tab where delivered and Ctrl+` fallback. Release modifier selects; Esc cancels; click Switch always works. Leaving browser cancels stuck switcher.
7. Test close/minimize/maximize/snap shortcuts plus dirty-state cancellation. Verify normal Tab and editor Ctrl+S are not hijacked.
8. Request fullscreen and optional Keyboard Lock in supported browsers. Reject permission or use unsupported API; verify clear failure/fallback message. Ensure Escape/exit and unlock remain available. Do not infer native Alt+Tab capture from a resolved lock promise.
9. Select, double-click and drag icons; snap on/off; cancel pointer drag; resize workspace; reload with storage allowed/blocked. F2 label rename; keyboard arrows/Enter/Ctrl+Shift+arrows; reset arrangement.
10. In Explorer test Up/Down/Home/End row focus plus F2/Delete and confirm dialogs. Test editing inside fields is unaffected.
11. Close Browser with several tabs; verify frames/timers disposed. Close Tidal Code with running game; verify original cleanup still works.
12. Test source reload/apply in Tidal Code; confirm icon enhancement is re-applied to a newly rendered desktop. Keep reload recovery route if custom source removes helper app.
13. Test install into a COPY of your real Horizon folder if using one. Confirm its original Browser/workspaces/apps remain. That original 0.4 archive was unavailable for direct validation.
14. Check accessibility/contrast/focus indicators on dark/light themes and small workspaces. Floating controls must not obscure titlebar window buttons.

Mock-DOM tests do not measure actual browser layout, external response headers, mixed-content policy, third-party login, pointer capture, keyboard permissions, or platform-reserved shortcuts.
