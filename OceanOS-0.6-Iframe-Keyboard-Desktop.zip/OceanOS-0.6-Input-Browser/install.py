
"""Add iframe browser and input/desktop enhancements to a compatible OceanOS folder.
Usage: python install.py PATH_TO_OCEANOS_FOLDER
No network/dependencies. Back up the entire target folder before installation.
"""
from pathlib import Path
import re, shutil, sys
ASSETS=Path(__file__).resolve().parent/'extension-assets'
def install(target):
    target=Path(target).resolve()
    for name in ['index.html','oceanos.tidal','tidal/parser.js','tidal/desktop.js','styles.css']:
        if not (target/name).is_file(): raise ValueError('Missing '+name)
    parser=(target/'tidal/parser.js').read_text(encoding='utf-8')
    app=(target/'tidal/desktop.js').read_text(encoding='utf-8')
    html=(target/'index.html').read_text(encoding='utf-8')
    source=(target/'oceanos.tidal').read_text(encoding='utf-8')
    pattern=r"(\[[^\]\n]*'explorer'[^\]\n]*'notes'[^\]\n]*)(\]\.includes\(a\[1\]\))"
    def extend(m):
        value=m[1]
        for name in ['framebrowser','inputhelp']:
            if "'"+name+"'" not in value:value+=",'"+name+"'"
        return value+m[2]
    parser,count=re.subn(pattern,extend,parser,count=1)
    if count!=1:raise ValueError('Unsupported parser structure; no edits written')
    if 'function frameBrowserApp(w' not in app:
        if 'tasks:tasksApp' not in app:raise ValueError('Unsupported app registry; no edits written')
        app=app.replace('tasks:tasksApp','tasks:tasksApp,framebrowser:frameBrowserApp,inputhelp:inputHelpApp',1)
        marker="$('start-button').append"
        if marker not in app:raise ValueError('Unsupported initialization; no edits written')
        init="""
function frameBrowserApp(w){return OceanEnhancements.mountBrowser(w);}
function inputHelpApp(w){return OceanEnhancements.mountHelp(w);}
OceanEnhancements.install({
 getConfig:()=>config,getWindows:()=>windows,getFocused:()=>windows.get(focusId),
 getWorkspace:()=>typeof workspace==='undefined'?0:workspace,
 focus,minimize,close:closeWindow,bounds,launch,findComponent,toast,
 clearFocus:()=>{focusId=null;for(const w of windows.values())w.node.classList.remove('focused');taskbar();},
 desktop:$('desktop'),shortcuts:$('shortcuts')
});
"""
        app=app.replace(marker,init+'\n'+marker,1)
    if 'OceanEnhancements.refreshDesktop();' not in app:
        marker='appearance();taskbar();drawStart();'
        if marker not in app:raise ValueError('Unsupported boot path; no edits written')
        app=app.replace(marker,marker+'OceanEnhancements.refreshDesktop();',1)
    if not re.search(r'^app\s+framebrowser\s',source,re.M):
        match=re.search(r'^window\s',source,re.M)
        if not match:raise ValueError('Missing window declarations')
        source=source[:match.start()]+'app framebrowser "Web Browser" icon ocean\napp inputhelp "Keyboard & Desktop" icon settings\npin framebrowser\nshortcut framebrowser\nshortcut inputhelp\n\n'+source[match.start():]
        source+='\nwindow framebrowser "Web Browser"\nsize 1120 720\ncomponent framebrowser\nend\nwindow inputhelp "Keyboard & Desktop"\nsize 920 690\ncomponent inputhelp\nend\n'
    if 'tidal/enhancements.js' not in html:
        marker='<script src="tidal/desktop.js"></script>'
        if marker not in html:raise ValueError('Missing desktop script')
        html=html.replace(marker,'<script src="tidal/enhancements.js"></script>'+marker,1)
    if 'tidal/enhancements.css' not in html:
        marker='<link rel="stylesheet" href="styles.css">'
        if marker not in html:raise ValueError('Missing stylesheet marker')
        html=html.replace(marker,marker+'<link rel="stylesheet" href="tidal/enhancements.css">',1)
    # Permit frames only; keep the desktop's other network restrictions unchanged.
    def csp(m):
        value=m[1]
        value=re.sub(r'frame-src\s+[^;]*;?', '',value)
        value='; '.join(part.strip() for part in value.split(';') if part.strip())
        return 'content="'+value+"; frame-src https: http: about:;"+'"'
    html,count=re.subn(r'content="(default-src[^\"]*)"',csp,html,count=1)
    if count!=1:raise ValueError('Missing expected desktop CSP')
    if '</script' in source.lower():raise ValueError('Unsafe embedded source')
    html,count=re.subn(r'(<script type="text/tidal" id="tidal-source">)[\s\S]*?(</script>)',lambda m:m[1]+source+m[2],html,count=1)
    if count!=1:raise ValueError('Missing embedded desktop source')
    builder="""from pathlib import Path
import re
root=Path(__file__).resolve().parent
source=(root/'oceanos.tidal').read_text(encoding='utf-8')
if '</script' in source.lower():raise ValueError('Unsafe source')
page=(root/'index.html').read_text(encoding='utf-8')
page,count=re.subn(r'(<script type="text/tidal" id="tidal-source">)[\\s\\S]*?(</script>)',lambda m:m[1]+source+m[2],page,count=1)
if count!=1:raise ValueError('Missing boot program')
(root/'index.html').write_text(page,encoding='utf-8')
standalone=page
for rel in re.findall(r'<link rel="stylesheet" href="([^\\"]+)">',page):
    standalone=standalone.replace('<link rel="stylesheet" href="'+rel+'">','<style>'+(root/rel).read_text(encoding='utf-8')+'</style>')
for rel in re.findall(r'<script src="([^\\"]+)"></script>',page):
    script=(root/rel).read_text(encoding='utf-8')
    if '</script' in script.lower():raise ValueError('Unsafe inline script')
    standalone=standalone.replace('<script src="'+rel+'"></script>','<script>'+script+'</script>')
(root/'OceanOS-Standalone.html').write_text(standalone,encoding='utf-8')
print('Rebuilt OceanOS folder/standalone')
"""
    changes={'tidal/parser.js':parser,'tidal/desktop.js':app,'index.html':html,'oceanos.tidal':source,'build.py':builder}
    codeapp=target/'tidal/code-app.js'
    if codeapp.exists():
        text=codeapp.read_text(encoding='utf-8')
        old='component explorer|notes|studio|terminal|settings|tasks|code'
        if old+'|framebrowser' not in text:text=text.replace(old,old+'|framebrowser|inputhelp')
        changes['tidal/code-app.js']=text
    for name,text in changes.items():
        old=target/name;backup=target/'.input06-backup'/name
        if old.exists() and not backup.exists():backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,backup)
    for name,text in changes.items():(target/name).write_text(text,encoding='utf-8')
    for name in ['enhancements.js','enhancements.css']:shutil.copy2(ASSETS/name,target/'tidal'/name)
    exec(compile(builder,str(target/'build.py'),'exec'),{'__file__':str(target/'build.py'),'__name__':'__main__'})
    return target
if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python install.py PATH_TO_OCEANOS_FOLDER')
    try:print('Installed into',install(sys.argv[1]))
    except Exception as e:raise SystemExit('Install failed: '+str(e))
