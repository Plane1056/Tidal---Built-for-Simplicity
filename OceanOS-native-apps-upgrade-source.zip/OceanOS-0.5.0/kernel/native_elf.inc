#include "native_elf.h"
static uint32_t ne_u16(const uint8_t*p){return p[0]|((uint32_t)p[1]<<8);}
static uint32_t ne_u32(const uint8_t*p){return ne_u16(p)|(ne_u16(p+2)<<16);}
static int ne_span(uint32_t at,uint32_t n,uint32_t size){return at<=size&&n<=size-at;}
int ne_validate(const uint8_t*b,uint32_t size,ne_image*out){ne_image q={0};if(!b||!out||size<52||size>NE_MAX_FILE)return -8;
 if(ne_u32(b)!=0x464c457f||b[4]!=1||b[5]!=1||b[6]!=1||b[7]!=255||b[8]!=NE_ABI_VERSION)return -8;
 if(ne_u16(b+16)!=2||ne_u16(b+18)!=3||ne_u32(b+20)!=1||ne_u32(b+36)!=0||ne_u16(b+40)!=52||ne_u16(b+42)!=32)return -8;
 uint32_t ph=ne_u32(b+28),n=ne_u16(b+44);if(ph<52||!n||n>8||!ne_span(ph,n*32,size))return -8;q.entry=ne_u32(b+24);uint32_t entry_valid=0;
 for(uint32_t i=0;i<n;i++){const uint8_t*h=b+ph+i*32;uint32_t type=ne_u32(h);if(type==0)continue;if(type==0x6474e551){if(ne_u32(h+24)!=6)return -8;continue;}if(type!=1)return -8;
  ne_segment s={ne_u32(h+4),ne_u32(h+8),ne_u32(h+16),ne_u32(h+20),ne_u32(h+24)};uint32_t align=ne_u32(h+28),base=s.flags==5?NE_CODE:s.flags==6?NE_DATA:0;
  if(!s.memory_size&&!s.file_size)continue;
  if(!base||!s.memory_size||s.file_size>s.memory_size||s.address<base||!ne_span(s.address-base,s.memory_size,4096)||!ne_span(s.offset,s.file_size,size))return -8;
  if(align>4096||(align>1&&((align&(align-1))||s.offset%align!=s.address%align)))return -8;
  for(uint32_t j=0;j<q.count;j++){ne_segment*t=&q.segments[j];if(s.address<t->address+t->memory_size&&t->address<s.address+s.memory_size)return -8;if(s.file_size&&t->file_size&&s.offset<t->offset+t->file_size&&t->offset<s.offset+s.file_size)return -8;}
  if(s.flags==5&&q.entry>=s.address&&q.entry-s.address<s.file_size)entry_valid=1;q.segments[q.count++]=s;
 }if(!q.count||!entry_valid)return -8;*out=q;return 0;}
