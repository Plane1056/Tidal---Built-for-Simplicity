ENTRY(_start)
PHDRS { code PT_LOAD FLAGS(5); data PT_LOAD FLAGS(6); }
SECTIONS {
 . = 0x10000;
 .text : { *(.start) *(.text*) } :code
 .rodata : { *(.rodata*) } :code
 . = ALIGN(4096);
 .data : { *(.data*) } :data
 . = ALIGN(0x100000);
 __bss_start = .;
 .bss : { *(.bss*) *(COMMON) } :data
 __bss_end = .;
 /DISCARD/ : { *(.eh_frame*) *(.comment*) *(.note*) }
}
