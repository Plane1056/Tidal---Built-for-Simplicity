/* Fixed-size native motion engine. No allocation and no interrupt dependency. */
#define MOTION_CHANNELS 32
static struct {uint32_t value,from,target,elapsed,duration;} motion[MOTION_CHANNELS]={{1024,1024,1024,0,0}};
static uint64_t motion_last;
static struct {uint32_t x,y,w,h;} motion_buttons[22];
static uint32_t motion_button_count,motion_mouse_x,motion_mouse_y;
static uint32_t motion_ready,motion_reduced,motion_frame_ms,motion_previous_app,motion_hover,motion_focus;
uint32_t motion_ease(uint32_t t){if(t>=1024)return 1024;return (t*t*(3072-2*t)+524288)/1048576;}
uint32_t motion_set(uint32_t ch,uint32_t value){if(ch>=MOTION_CHANNELS||value>1024)return 1;motion[ch].value=motion[ch].from=motion[ch].target=value;motion[ch].elapsed=motion[ch].duration=0;return 0;}
uint32_t motion_to(uint32_t ch,uint32_t target,uint32_t ms){if(ch>=MOTION_CHANNELS||target>1024||ms>2000)return 1;if(motion[ch].target==target)return 0;
 if(motion_reduced||!ms||!ui_cycles_ms)return motion_set(ch,target);
 motion[ch].from=motion[ch].value;motion[ch].target=target;motion[ch].elapsed=0;motion[ch].duration=ms;return 0;}
uint32_t motion_value(uint32_t ch){return ch<MOTION_CHANNELS?motion[ch].value:0;}
uint32_t motion_step(uint32_t ms){uint32_t changed=0;if(ms>64)ms=64;for(uint32_t i=0;i<MOTION_CHANNELS;i++)if(motion[i].value!=motion[i].target){
 uint32_t d=motion[i].duration;if(!d||motion_reduced){motion[i].value=motion[i].target;changed=1;continue;}
 uint32_t elapsed=motion[i].elapsed+ms;if(elapsed>d)elapsed=d;motion[i].elapsed=elapsed;uint32_t t=motion_ease(elapsed*1024/d),a=motion[i].from,b=motion[i].target;
 uint32_t next=b>=a?a+(b-a)*t/1024:a-(a-b)*t/1024;if(next!=motion[i].value)changed=1;motion[i].value=next;
 }if(changed)s[7]|=1;return changed;}
uint32_t motion_reduce(uint32_t on){motion_reduced=on?1:0;if(motion_reduced)for(uint32_t i=0;i<MOTION_CHANNELS;i++)motion_set(i,motion[i].target);s[7]|=1;return motion_reduced;}
uint32_t motion_is_reduced(void){return motion_reduced;}
uint32_t motion_tick(void){uint64_t now=ui_clock();if(!motion_ready){motion_ready=1;motion_last=now;return 0;}if(!ui_cycles_ms)return 0;
 uint64_t elapsed=now-motion_last;if(elapsed<(uint64_t)ui_cycles_ms*16)return 0;motion_last=now;uint32_t ms=elapsed>(uint64_t)ui_cycles_ms*64?64:(uint32_t)elapsed/ui_cycles_ms;motion_frame_ms=ms;if((s[0]!=motion_mouse_x||s[1]!=motion_mouse_y)&&(s[4]||s[5]))s[7]|=1;motion_mouse_x=s[0];motion_mouse_y=s[1];return motion_step(ms);}
uint32_t motion_observe(void){
 if(s[4]!=motion_previous_app){motion_button_count=0;for(uint32_t i=10;i<32;i++)motion_set(i,0);motion_previous_app=s[4];if(s[4]){motion_set(0,0);motion_to(0,1024,170);}}
 motion_to(1,s[5]?1024:0,150);motion_to(2,s[20]?1024:0,120);
 uint32_t hover=0;uint32_t x=s[0],y=s[1],base=ui_left?12:472;
 if(y>=747)for(uint32_t i=0;i<7;i++)if(inside(x,y,base+i*48,747,42,53))hover=i+1;
 if(hover!=motion_hover){motion_hover=hover;s[7]|=1;}
 for(uint32_t i=0;i<7;i++)motion_to(3+i,hover==i+1?1024:0,150);
 if((s[3]&1)!=motion_focus){motion_focus=s[3]&1;s[7]|=1;}
 for(uint32_t i=0;i<motion_button_count;i++)motion_to(10+i,inside(s[0],s[1],motion_buttons[i].x,motion_buttons[i].y,motion_buttons[i].w,motion_buttons[i].h)?1024:0,150);
 return motion_tick();}
uint32_t motion_color(uint32_t a,uint32_t b,uint32_t t){return blend(a,b,t>1024?255:t*255/1024);}
uint32_t motion_hover_color(uint32_t x,uint32_t y,uint32_t w,uint32_t h,uint32_t base){uint32_t i;for(i=0;i<motion_button_count;i++)if(motion_buttons[i].x==x&&motion_buttons[i].y==y&&motion_buttons[i].w==w&&motion_buttons[i].h==h)break;
 if(i==motion_button_count&&i<22){motion_buttons[i].x=x;motion_buttons[i].y=y;motion_buttons[i].w=w;motion_buttons[i].h=h;motion_button_count++;}
 uint32_t v=i<22?motion_value(10+i):(inside(s[0],s[1],x,y,w,h)?1024:0);return blend(base,ui_color(7),v*35/1024);}
uint32_t motion_button(uint32_t x,uint32_t y,uint32_t w,uintptr_t title){uint32_t active=inside(s[0],s[1],x,y,w,34),down=active&&(s[3]&1);uint32_t c=motion_hover_color(x,y,w,34,ui_color(2));if(down)c=blend(c,ui_color(7),45);
 round_rect(x+(down?1:0),y+(down?1:0),w-(down?2:0),34-(down?2:0),6,c);ui_text(x+12,y+7,title,ui_color(3));return 0;}
