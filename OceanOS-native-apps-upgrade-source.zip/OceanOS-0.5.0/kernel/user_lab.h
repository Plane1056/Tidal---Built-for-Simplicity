#ifndef OCEAN_USER_LAB_H
#define OCEAN_USER_LAB_H
#include "runtime.h"
#define UL_CODE 0x40000000u
#define UL_STACK 0x40004000u
int ul_range(uint32_t address,uint32_t n);
int ul_selftest(void);
uint32_t ul_last_vector(void);
uint32_t ul_last_error(void);
const char *ul_report(void);
#endif
