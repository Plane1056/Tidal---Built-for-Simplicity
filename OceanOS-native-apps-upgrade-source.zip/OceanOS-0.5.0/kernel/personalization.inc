/* Native personalization, inspired by the supplied HTML; no DOM/JS dependency. */
#include "../assets/ui-font.h"
static uint32_t ui_mode,ui_accent,ui_wall,ui_left,ui_labels=1,ui_saved,ui_selected,ui_drag,ui_last,ui_moved;
static uint32_t ui_x[6],ui_y[6],ui_dx,ui_dy,ui_px,ui_py,ui_cycles_ms;
static uint64_t ui_last_time;
static const uint32_t ui_accents[6]={0x73c9ff,0x80e4c1,0xc6a7ff,0xffa9bc,0xffcb80,0x94d9e0};
static const uint32_t ui_dark[7]={0x182330,0x202c3b,0x293747,0xeef5ff,0xaab8cb,0x354352,0x172433};
static const uint32_t ui_light[7]={0xf7f9fc,0xffffff,0xeaf0f7,0x172334,0x57667b,0xcdd5df,0xf4f8ff};
uint32_t ui_color(uint32_t n){if(n==7)return ui_accents[ui_accent];return n<7?(ui_mode?ui_light[n]:ui_dark[n]):0;}
uint32_t ui_get(uint32_t n){if(n==0)return ui_mode;if(n==1)return ui_accent;if(n==2)return ui_wall;if(n==3)return ui_left;if(n==4)return ui_labels;return 0;}
uint32_t ui_set(uint32_t n,uint32_t v){if((n==0||n==3||n==4)&&v>1)return 1;if(n==1&&v>5)return 1;if(n==2&&v>3)return 1;if(n>4)return 1;
 if(n==0)ui_mode=v;if(n==1)ui_accent=v;if(n==2)ui_wall=v;if(n==3)ui_left=v;if(n==4)ui_labels=v;
 wallpaper_ready=0;ui_saved=0;s[7]|=1;return 0;}
static uint32_t ui_font_draw(uint32_t x,uint32_t y,uintptr_t ptr,uint32_t c,uint32_t scale){const unsigned char*t=(const unsigned char*)ptr;uint32_t start=x,px=sx(x),py=sy(y),gw=20*width*scale/1600,gh=22*height*scale/900;
 if(!gw)gw=1;if(!gh)gh=1;
 for(uint32_t i=0;t[i]&&i<4096;i++){uint32_t ch=t[i];if(ch=='\n'){y+=22;px=sx(start);py=sy(y);continue;}if(ch<32||ch>126)ch='?';ch-=32;
  for(uint32_t j=0;j<gh;j++)for(uint32_t k=0;k<gw;k++){uint32_t at=ch*990+(j*33/gh)*30+k*30/gw;uint32_t a=((ui_glyphs[at/2]>>(at&1?0:4))&15)*17;if(a)alpha_pixel(px+k,py+j,c,a);}
  px+=(ui_widths[ch]*width*scale+800)/1600;
 }return 0;}
uint32_t ui_text(uint32_t x,uint32_t y,uintptr_t p,uint32_t c){return ui_font_draw(x,y,p,c,1);}
uint32_t ui_heading(uint32_t x,uint32_t y,uintptr_t p,uint32_t c){return ui_font_draw(x,y,p,c,2);}
static void ui_defaults(void){ui_mode=ui_accent=ui_wall=ui_left=0;ui_labels=1;for(uint32_t i=0;i<6;i++){ui_x[i]=14;ui_y[i]=16+i*103;}ui_saved=0;wallpaper_ready=0;}
static uint32_t ui_checksum(const uint32_t*b){uint32_t v=0x539f13;for(uint32_t i=0;i<19;i++)v=(v^b[i])*16777619U;return v;}
static int ui_decode(const uint32_t*b){if(b[0]!=0x4f554931||b[1]!=1||b[19]!=ui_checksum(b)||b[2]>1||b[3]>5||b[4]>3||b[5]>1||b[6]>1)return 0;
 for(uint32_t i=0;i<6;i++)if(b[7+i*2]>1190||b[8+i*2]>635)return 0;
 ui_mode=b[2];ui_accent=b[3];ui_wall=b[4];ui_left=b[5];ui_labels=b[6];for(uint32_t i=0;i<6;i++){ui_x[i]=b[7+i*2];ui_y[i]=b[8+i*2];}ui_saved=1;wallpaper_ready=0;return 1;}
uint32_t ui_save(void){if(disk_state!=1){ui_saved=2;s[7]|=1;return 1;}uint32_t b[20]={0};b[0]=0x4f554931;b[1]=1;b[2]=ui_mode;b[3]=ui_accent;b[4]=ui_wall;b[5]=ui_left;b[6]=ui_labels;
 for(uint32_t i=0;i<6;i++){b[7+i*2]=ui_x[i];b[8+i*2]=ui_y[i];}b[19]=ui_checksum(b);
 uint32_t id=find_child(0,"OceanUI.CFG");if(id==NONE)id=entry_make(0,"OceanUI.CFG",T_FILE,"");
 if(IS_ERR(id)||IS_ERR(fs_replace(id,b,sizeof b))){ui_saved=3;s[7]|=1;return 2;}ui_saved=1;fs_changed();s[7]|=1;return 0;}
#ifdef OCEANOS_HOST_TEST
static uint64_t ui_test_clock;
static uint64_t ui_clock(void){return ui_test_clock;}
#else
static uint64_t ui_clock(void){uint32_t lo,hi;__asm__ volatile("rdtsc":"=a"(lo),"=d"(hi));return ((uint64_t)hi<<32)|lo;}
#endif
uint32_t ui_init(void){ui_defaults();ui_selected=ui_drag=ui_last=0;uint32_t b[20],id=find_child(0,"OceanUI.CFG");if(id!=NONE&&ent[id].size==sizeof b&&fs_read_at(id,0,b,sizeof b)==sizeof b)ui_decode(b);
#ifdef OCEANOS_HOST_TEST
 ui_cycles_ms=1000;
#else
 uint8_t old=in8(0x61);out8(0x61,(old&0xfc)|1);out8(0x43,0xb0);out8(0x42,0x9c);out8(0x42,0x2e);uint64_t a=ui_clock();uint32_t limit=10000000;while(limit&&!(in8(0x61)&0x20))limit--;uint64_t d=ui_clock()-a;out8(0x61,old);ui_cycles_ms=limit&&d>=10000&&d<1000000000ULL?(uint32_t)d/10:0;
#endif
 return 0;}
uint32_t ui_icon_x(uint32_t id){return id&&id<=6?ui_x[id-1]:0;}
uint32_t ui_icon_y(uint32_t id){return id&&id<=6?ui_y[id-1]:0;}
uint32_t ui_selection(void){return ui_selected;}
uint32_t ui_desktop_press(uint32_t x,uint32_t y){ui_drag=0;for(uint32_t id=6;id;id--)if(inside(x,y,ui_x[id-1],ui_y[id-1],90,92)){uint64_t now=ui_clock();ui_selected=id;
 if(ui_last==id&&ui_cycles_ms&&now-ui_last_time<(uint64_t)ui_cycles_ms*450){ui_last=0;s[4]=id;s[7]|=1;return id;}
 ui_last=id;ui_last_time=now;ui_drag=id;ui_dx=x-ui_x[id-1];ui_dy=y-ui_y[id-1];ui_px=x;ui_py=y;ui_moved=0;s[7]|=1;return 0;}ui_selected=ui_last=0;s[7]|=1;return 0;}
uint32_t ui_desktop_update(void){if(!(s[3]&1)){ui_drag=0;return 0;}if(!ui_drag)return 0;uint32_t x=s[0],y=s[1],dx=x>ui_px?x-ui_px:ui_px-x,dy=y>ui_py?y-ui_py:ui_py-y;if(!ui_moved&&dx<5&&dy<5)return 0;ui_moved=1;ui_last=0;
 uint32_t nx=x>=ui_dx?x-ui_dx:0,ny=y>=ui_dy?y-ui_dy:0;if(nx>1190)nx=1190;if(ny>635)ny=635;ui_x[ui_drag-1]=nx;ui_y[ui_drag-1]=ny;ui_saved=0;s[7]|=1;return 0;}
static void ui_append_number(char*b,uint32_t*at,uint32_t v){char t[12];uint32_t n=0;do{t[n++]=(char)('0'+v%10);v/=10;}while(v);while(n)b[(*at)++]=t[--n];b[*at]=0;}
static void ui_card(uint32_t x,uint32_t y,uint32_t w,uint32_t h,const char*title,const char*desc){round_rect(x,y,w,h,8,ui_color(5));round_rect(x+1,y+1,w-2,h-2,7,ui_color(1));ui_text(x+16,y+11,(uintptr_t)title,ui_color(3));ui_text(x+16,y+33,(uintptr_t)desc,ui_color(4));}
static void ui_choice(uint32_t x,uint32_t y,uint32_t w,const char*t,uint32_t active){round_rect(x,y,w,29,5,motion_hover_color(x,y,w,29,active?ui_color(7):ui_color(2)));ui_text(x+12,y+6,(uintptr_t)t,active?0x082238:ui_color(3));}
uint32_t ui_settings_draw(uint32_t x,uint32_t y,uint32_t w,uint32_t h){
 round_rect(x+12,y+65,170,h-80,7,ui_color(1));ui_text(x+28,y+86,(uintptr_t)"Settings",ui_color(3));round_rect(x+20,y+130,154,37,5,ui_color(2));rect(x+20,y+140,3,16,accent());ui_text(x+30,y+140,(uintptr_t)"Personalization",ui_color(3));ui_text(x+28,y+193,(uintptr_t)"OceanOS native",ui_color(4));ui_text(x+28,y+218,(uintptr_t)"Appearance & layout",ui_color(4));char resolution[40];uint32_t at=0;ui_append_number(resolution,&at,width);resolution[at++]=' ';resolution[at++]='x';resolution[at++]=' ';ui_append_number(resolution,&at,height);ui_text(x+28,y+260,(uintptr_t)resolution,ui_color(3));ui_text(x+28,y+285,(uintptr_t)"Active boot resolution",ui_color(4));
 uint32_t a=x+204,b=y+68,c=w-226;
 ui_text(a,b,(uintptr_t)"Personalization",ui_color(3));ui_text(a,b+25,(uintptr_t)"Make OceanOS feel like yours.",ui_color(4));
 ui_card(a,b+58,c,91,"Choose your mode","Set the color theme for windows, menus and the taskbar.");ui_choice(a+16,b+112,87,"Dark",!ui_mode);ui_choice(a+112,b+112,87,"Light",ui_mode);
 ui_card(a,b+159,c,112,"Background","Choose a built-in, offline wallpaper.");const char*names[4]={"Bloom","Aurora","Dusk","Solid"};const uint32_t colors[4]={0x165b83,0x086d60,0x9b527d,0x0c2034};
 for(uint32_t i=0;i<4;i++){uint32_t xx=a+16+i*116;round_rect(xx,b+213,105,46,6,ui_wall==i?accent():ui_color(5));round_rect(xx+2,b+215,101,42,4,colors[i]);ui_text(xx+12,b+226,(uintptr_t)names[i],0xffffff);}
 ui_card(a,b+281,c,88,"Accent color","Used for selections and primary controls.");for(uint32_t i=0;i<6;i++){uint32_t xx=a+16+i*45;round_rect(xx,b+333,31,27,5,ui_accent==i?ui_color(3):ui_color(5));round_rect(xx+3,b+336,25,21,3,ui_accents[i]);}
 ui_card(a,b+379,c,90,"Taskbar & desktop","Choose alignment and desktop labels.");ui_choice(a+16,b+431,87,"Center",!ui_left);ui_choice(a+112,b+431,87,"Left",ui_left);ui_choice(a+218,b+431,150,ui_labels?"Labels: on":"Labels: off",ui_labels);
 ui_choice(a,b+481,145,"Save preferences",0);ui_choice(a+155,b+481,110,"Reset",0);ui_choice(a+280,b+481,170,motion_is_reduced()?"Animations: off":"Animations: on",!motion_is_reduced());
 const char*msg=ui_saved==1?"Saved / loaded from OceanFS":ui_saved==2?"No writable OceanFS disk. Changes are session-only.":ui_saved==3?"Save failed. Your current appearance is unchanged.":"Unsaved changes. Save to keep preferences and icon positions.";
 ui_text(a,b+522,(uintptr_t)msg,ui_color(4));return 0;}
uint32_t ui_settings_click(uint32_t px,uint32_t py,uint32_t x,uint32_t y){uint32_t a=x+204,b=y+68;
 if(inside(px,py,a+16,b+112,87,29))ui_set(0,0);if(inside(px,py,a+112,b+112,87,29))ui_set(0,1);
 for(uint32_t i=0;i<4;i++)if(inside(px,py,a+16+i*116,b+213,105,46))ui_set(2,i);
 for(uint32_t i=0;i<6;i++)if(inside(px,py,a+16+i*45,b+333,31,27))ui_set(1,i);
 if(inside(px,py,a+16,b+431,87,29))ui_set(3,0);if(inside(px,py,a+112,b+431,87,29))ui_set(3,1);if(inside(px,py,a+218,b+431,150,29))ui_set(4,!ui_labels);
 if(inside(px,py,a+280,b+481,170,29))motion_reduce(!motion_is_reduced());
 if(inside(px,py,a,b+481,145,29))ui_save();if(inside(px,py,a+155,b+481,110,29)){ui_defaults();s[7]|=1;}return 0;}

uint32_t ui_reset_icons(void){for(uint32_t i=0;i<6;i++){ui_x[i]=14;ui_y[i]=16+i*103;}ui_saved=0;s[7]|=1;return 0;}
