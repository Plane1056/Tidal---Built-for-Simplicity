#include "host_services.h"
/* A reserved BSS arena, not a physical frame manager or virtual memory system. */
static uint8_t oh_arena[OH_POOL_PAGES*OH_PAGE_SIZE] __attribute__((aligned(4096)));
static uint16_t oh_runs[OH_POOL_PAGES];
static uint32_t oh_owners[OH_POOL_PAGES];
static uint32_t oh_page_free=OH_POOL_PAGES;
uintptr_t oh_pages_alloc(uint32_t owner,uint32_t pages){if(!owner||!pages||pages>OH_POOL_PAGES||pages>oh_page_free)return 0;
 uint32_t run=0;for(uint32_t i=0;i<OH_POOL_PAGES;i++){run=oh_runs[i]?0:run+1;if(run==pages){uint32_t start=i+1-pages;oh_runs[start]=(uint16_t)pages;oh_owners[start]=owner;for(uint32_t j=1;j<pages;j++)oh_runs[start+j]=0xffff;oh_page_free-=pages;memset(oh_arena+start*OH_PAGE_SIZE,0,pages*OH_PAGE_SIZE);return (uintptr_t)(oh_arena+start*OH_PAGE_SIZE);}}return 0;}
int oh_pages_free(uint32_t owner,uintptr_t ptr){uintptr_t base=(uintptr_t)oh_arena;if(!owner||ptr<base||ptr-base>=sizeof oh_arena||(ptr-base)%OH_PAGE_SIZE)return -22;uint32_t at=(uint32_t)((ptr-base)/OH_PAGE_SIZE),n=oh_runs[at];if(!n||n==0xffff)return -22;if(oh_owners[at]!=owner)return -13;
 memset(oh_arena+at*OH_PAGE_SIZE,0,n*OH_PAGE_SIZE);for(uint32_t i=0;i<n;i++)oh_runs[at+i]=oh_owners[at+i]=0;oh_page_free+=n;return 0;}
uint32_t oh_pages_available(void){return oh_page_free;}
typedef struct {uint32_t active,generation,owner,id,offset,flags;} oh_descriptor;
static oh_descriptor oh_fds[OH_FD_COUNT];
static void oh_invalidate_files(void){for(uint32_t i=0;i<OH_FD_COUNT;i++)oh_fds[i].active=0;}
static uint32_t oh_files_open(void){for(uint32_t i=0;i<OH_FD_COUNT;i++)if(oh_fds[i].active)return 1;return 0;}
static int oh_error(uint32_t e){if(e==E_NOENT)return -2;if(e==E_NAME)return -22;if(e==E_FULL)return -28;if(e==E_EXISTS)return -17;if(e==E_BIG)return -27;if(e==E_BUSY)return -16;if(e==E_ISDIR)return -21;return -5;}
static uint32_t oh_file_busy(uint32_t id){for(uint32_t i=0;i<OH_FD_COUNT;i++)if(oh_fds[i].active&&oh_fds[i].id==id)return 1;return 0;}
static oh_descriptor*oh_lookup(uint32_t owner,int fd){if(!owner||fd<3)return 0;uint32_t n=(uint32_t)fd-3,index=n%OH_FD_COUNT,generation=n/OH_FD_COUNT;oh_descriptor*f=&oh_fds[index];if(!f->active||f->owner!=owner||f->generation!=generation)return 0;return f;}
/* Bounded path resolution, root-clamped '..'; there are no symbolic links. */
static int oh_resolve(uint32_t parent,const char*path,uint32_t*out_parent,char*leaf){if(!path||!*path)return -2;if(parent>=FS_ENTRIES||ent[parent].type!=T_DIR)return -20;
 uint32_t n=0;while(n<=1024&&path[n])n++;if(n>1024)return -36;uint32_t at=0,dir=parent;if(path[0]=='/')dir=0;
 while(path[at]){while(path[at]=='/')at++;if(!path[at])return -21;uint32_t len=0;while(path[at]&&path[at]!='/'){if(len>=FS_NAME-1)return -36;leaf[len++]=path[at++];}leaf[len]=0;
  uint32_t slash=path[at]=='/';while(path[at]=='/')at++;if(equal(leaf,".")){if(!path[at])return -21;continue;}if(equal(leaf,"..")){dir=ent[dir].parent;if(!path[at])return -21;continue;}
  if(!path[at]&&!slash){*out_parent=dir;return 0;}
  uint32_t id=find_child(dir,leaf);if(id==NONE)return -2;if(ent[id].type!=T_DIR)return -20;dir=id;
 }return -21;}
int oh_open(uint32_t owner,uint32_t parent,const char*path,uint32_t flags){if(!owner||(flags&~63u)||!(flags&(OH_READ|OH_WRITE))||((flags&(OH_TRUNC|OH_APPEND))&&!(flags&OH_WRITE))||((flags&OH_EXCL)&&!(flags&OH_CREATE)))return -22;
 uint32_t slot=0;while(slot<OH_FD_COUNT&&oh_fds[slot].active)slot++;if(slot==OH_FD_COUNT)return -24;
 char leaf[FS_NAME];uint32_t dir;int r=oh_resolve(parent,path,&dir,leaf);if(r)return r;uint32_t id=find_child(dir,leaf);
 if(id!=NONE){if(ent[id].type!=T_FILE)return -21;if((flags&(OH_CREATE|OH_EXCL))==(OH_CREATE|OH_EXCL))return -17;}
 else{if(!(flags&OH_CREATE))return -2;id=entry_make(dir,leaf,T_FILE,"");if(IS_ERR(id))return oh_error(id);}
 if(flags&OH_TRUNC){uint32_t rr=fs_truncate(id,0);if(IS_ERR(rr))return oh_error(rr);}
 oh_descriptor*f=&oh_fds[slot];f->generation=(f->generation+1)&0x007fffff;if(!f->generation)f->generation=1;f->owner=owner;f->id=id;f->offset=0;f->flags=flags;f->active=1;return (int)(3+slot+f->generation*OH_FD_COUNT);}
int oh_read(uint32_t owner,int fd,void*buf,uint32_t n){oh_descriptor*f=oh_lookup(owner,fd);if(!f)return -9;if(!(f->flags&OH_READ))return -13;if(n&&!buf)return -14;if(n>MAX_FILE)return -22;if(!n)return 0;uint32_t r=fs_read_at(f->id,f->offset,buf,n);if(IS_ERR(r))return oh_error(r);f->offset+=r;return (int)r;}
int oh_write(uint32_t owner,int fd,const void*buf,uint32_t n){oh_descriptor*f=oh_lookup(owner,fd);if(!f)return -9;if(!(f->flags&OH_WRITE))return -13;if(n&&!buf)return -14;if(n>MAX_FILE)return -22;if(!n)return 0;uint32_t off=(f->flags&OH_APPEND)?ent[f->id].size:f->offset;
 /* Existing OceanFS does not implement sparse writes: report unsupported. */
 if(off>ent[f->id].size)return -38;if(n>MAX_FILE-off)return -27;uint32_t r=fs_write_at(f->id,off,buf,n);if(IS_ERR(r))return oh_error(r);f->offset=off+r;return (int)r;}
int oh_seek(uint32_t owner,int fd,int offset,uint32_t whence){oh_descriptor*f=oh_lookup(owner,fd);if(!f)return -9;uint32_t base;if(whence==0)base=0;else if(whence==1)base=f->offset;else if(whence==2)base=ent[f->id].size;else return -22;
 if(offset<0){uint32_t magnitude=0u-(uint32_t)offset;if(magnitude>base)return -22;f->offset=base-magnitude;}else{if((uint32_t)offset>MAX_FILE-base)return -27;f->offset=base+(uint32_t)offset;}return (int)f->offset;}
int oh_close(uint32_t owner,int fd){oh_descriptor*f=oh_lookup(owner,fd);if(!f)return -9;f->active=0;return 0;}
int oh_size(uint32_t owner,int fd){oh_descriptor*f=oh_lookup(owner,fd);return f?(int)ent[f->id].size:-9;}
uint32_t oh_fd_available(void){uint32_t n=0;for(uint32_t i=0;i<OH_FD_COUNT;i++)if(!oh_fds[i].active)n++;return n;}
uint32_t oh_owner_release(uint32_t owner){if(!owner)return 0;uint32_t n=0;for(uint32_t i=0;i<OH_FD_COUNT;i++)if(oh_fds[i].active&&oh_fds[i].owner==owner){oh_fds[i].active=0;n++;}for(uint32_t i=0;i<OH_POOL_PAGES;i++)if(oh_runs[i]&&oh_runs[i]!=0xffff&&oh_owners[i]==owner){oh_pages_free(owner,(uintptr_t)(oh_arena+i*OH_PAGE_SIZE));n++;}return n;}
