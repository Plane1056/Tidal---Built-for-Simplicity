#ifndef OCEAN_PE32_H
#define OCEAN_PE32_H
#include "runtime.h"
typedef struct { uint32_t image_base,image_size,entry_rva,section_count,imports_rva,imports_size,relocations_rva,relocations_size; } ocean_pe_info;
/* Inspection only: never maps or executes untrusted input. Returns zero on success. */
int ocean_pe32_inspect(const uint8_t *data,uint32_t size,ocean_pe_info *out);
#endif
