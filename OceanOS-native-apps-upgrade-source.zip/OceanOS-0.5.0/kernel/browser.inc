
/* Browser platform bridge: bounded storage, file loading and text metrics.
   HTML parsing, flow layout, navigation, history and hit testing are Tidal. */
static char browser_buf[112][1024],browser_doc[65536];
static uint32_t browser_num[4096];
uint32_t bc(uint32_t b,uint32_t p){if(b==0)return p<65536?(uint8_t)browser_doc[p]:0;return b<112&&p<1024?(uint8_t)browser_buf[b][p]:0;}
uint32_t bs(uint32_t b,uint32_t p,uint32_t c){if(b==0){if(p<65535){browser_doc[p]=c;browser_doc[p+1]=0;}}else if(b<112&&p<1023){browser_buf[b][p]=c;browser_buf[b][p+1]=0;}return 0;}
uint32_t bp(uint32_t b,uintptr_t p){if(b&&b<112)strcopy(browser_buf[b],(const char*)p,1024);return 0;}
uint32_t bcopy(uint32_t d,uint32_t a){if(d&&d<112&&a&&a<112)strcopy(browser_buf[d],browser_buf[a],1024);return 0;}
uint32_t beq(uint32_t b,uintptr_t p){return b<112&&b&&equal(browser_buf[b],(const char*)p);}
uint32_t bn(uint32_t i){return i<4096?browser_num[i]:0;}
uint32_t bv(uint32_t i,uint32_t v){if(i<4096)browser_num[i]=v;return 0;}
#ifdef OCEANOS_BROWSER_TEST
static char browser_test_text[131072];
#endif
uint32_t bt(uint32_t x,uint32_t y,uint32_t b,uint32_t color){
#ifdef OCEANOS_BROWSER_TEST
if(b==4){sadd(browser_test_text,sizeof browser_test_text,browser_buf[4]);sadd(browser_test_text,sizeof browser_test_text," ");}
#endif
if(b&&b<112)return text(x,y,(uintptr_t)browser_buf[b],color);return 0;}
static const char browser_home[]="<h1>Ocean Browser</h1><p>A native local HTML browser written in Tidal.</p><p><a href='ocean://guide'>Read the browser guide</a> or <a href='ocean://demo'>explore a sample page</a>.</p><h2>Open your own documents</h2><p>Click the address bar, type file:///Welcome.html and press Enter. Files must already exist on OceanFS.</p><p>Press Ctrl+L to replace the address. Use Up and Down to scroll. Click links to navigate. Back and Forward preserve page history.</p><p>No HTTP, HTTPS, JavaScript or CSS engine is included in this first release.</p>";
static const char browser_guide[]="<h1>Browser guide</h1><p><a href='ocean://welcome'>Home</a> | <a href='ocean://demo'>Demo</a></p><h2>Supported HTML</h2><p>Headings, paragraphs, line breaks, horizontal rules, lists, links and plain inline text. Script and style contents are hidden, never executed.</p><h2>Storage</h2><p>Enter file:///folder/page.html to load an OceanFS file. Relative links resolve against the current document folder. Parent directory links are supported.</p><h2>Limits</h2><p>Pages: 65535 bytes. Address: 255 printable ASCII characters. Link targets: 511 bytes. Up to 60 links, 500 clickable word regions and 16 history entries.</p><h2>Navigation</h2><p>Click address bar to edit, Enter to load, Up and Down to scroll. Toolbar buttons navigate history and reload.</p><h2>Not implemented</h2><p>Networking, CSS, images, forms, JavaScript, Unicode shaping, downloads and process isolation.</p>";
static const char browser_demo[]="<h1>A deeper ocean</h1><p><a href='ocean://welcome'>Home</a> / <a href='ocean://guide'>Guide</a></p><h2>Real document flow</h2><p>This document is tokenized and laid out by Tidal functions. Resize the window using maximize to see words wrap into the available width.</p><ul><li>Native antialiased desktop fonts</li><li>OceanFS document loading</li><li>Relative links and bounded history</li></ul><hr><p>Entities: &amp; &lt; &gt; &quot; &#65;.</p><h2>Scroll test</h2><p>Line one</p><p>Line two</p><p>Line three</p><p>Line four</p><p>Line five</p><p>Line six</p><p>Line seven</p><p>Line eight</p><p>Line nine</p><p>Line ten</p><p><a href='ocean://welcome'>Return home</a></p>";
uint32_t bload(void){
 char target[1024];strcopy(target,browser_buf[1],sizeof target);
 if(equal(target,"ocean://welcome")||equal(target,"ocean://guide")||equal(target,"ocean://demo")){
 strcopy(browser_doc,equal(target,"ocean://guide")?browser_guide:equal(target,"ocean://demo")?browser_demo:browser_home,sizeof browser_doc);strcopy(browser_buf[7],target,1024);bp(5,(uintptr_t)"Local page / HTML subset / no network");return 1;}
 const char *p=target;char full[1024];uint32_t n=0;
 if(length(p)>=7&&memcmp_eq(p,"file://",7))p+=7;
 else {for(uint32_t i=0;p[i];i++)if(p[i]==':'){bp(5,(uintptr_t)"Unsupported scheme: only file:/// and ocean://");return 0;}}
 if(*p!='/') {const char *base=browser_buf[7];if(length(base)>=8&&memcmp_eq(base,"file:///",8)){strcopy(full,base+7,sizeof full);n=length(full);while(n&&full[n-1]!='/')n--;}else full[n++]='/';}
 while(*p&&*p!='#'&&n<sizeof(full)-1)full[n++]=*p++;full[n]=0;
 if(n==sizeof(full)-1||*p=='?'){bp(5,(uintptr_t)"Address too long or unsupported query");return 0;}
 uint32_t dir=0;char part[128];p=full;
 while(*p){while(*p=='/')p++;if(!*p)break;uint32_t k=0;while(*p&&*p!='/'){if(k>=127){bp(5,(uintptr_t)"Path component too long");return 0;}part[k++]=*p++;}part[k]=0;if(equal(part,"."))continue;if(equal(part,"..")){dir=ent[dir].parent;continue;}uint32_t id=find_child(dir,part);if(id==NONE){bp(5,(uintptr_t)"File not found (previous page retained)");return 0;}dir=id;if(*p&&ent[dir].type!=T_DIR){bp(5,(uintptr_t)"Not a folder");return 0;}}
 if(ent[dir].type!=T_FILE||ent[dir].size>65535){bp(5,(uintptr_t)"Expected an HTML file of at most 65535 bytes");return 0;}
 /* Read to temporary buffer so a failed read cannot replace the current page. */
 static char staged[65536];uint32_t got=fs_read_at(dir,0,staged,ent[dir].size);
 if(IS_ERR(got)||got!=ent[dir].size){bp(5,(uintptr_t)"File read failed");return 0;}
 for(uint32_t i=0;i<got;i++)if((uint8_t)staged[i]>=128||(!staged[i])){bp(5,(uintptr_t)"Only non-NUL ASCII HTML is supported");return 0;}
 staged[got]=0;memcpy(browser_doc,staged,got+1);char path[1017];path_of(ent[dir].parent,path,sizeof path);strcopy(browser_buf[7],"file://",1024);sadd(browser_buf[7],1024,path);if(!equal(path,"/"))sadd(browser_buf[7],1024,"/");sadd(browser_buf[7],1024,ent[dir].name);bp(5,(uintptr_t)"OceanFS page / HTML subset / no network");return 1;
}
