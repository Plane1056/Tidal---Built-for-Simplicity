#ifndef OCEAN_NATIVE_ELF_H
#define OCEAN_NATIVE_ELF_H
#include "runtime.h"
#define NE_CODE 0x40000000u
#define NE_DATA 0x40002000u
#define NE_MAX_FILE 65536u
#define NE_ABI_VERSION 1u
typedef struct {uint32_t offset,address,file_size,memory_size,flags;} ne_segment;
typedef struct {uint32_t entry,count;ne_segment segments[8];} ne_image;
int ne_validate(const uint8_t*,uint32_t,ne_image*);
#endif
