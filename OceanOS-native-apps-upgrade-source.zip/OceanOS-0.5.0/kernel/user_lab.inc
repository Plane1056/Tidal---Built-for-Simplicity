#include "user_lab.h"
/* Opt-in, fixed native fixtures only. This is NOT an executable loader. */
static uint32_t ul_directory[1024] __attribute__((aligned(4096)));
static uint32_t ul_table[1024] __attribute__((aligned(4096)));
static uint8_t ul_code[4096] __attribute__((aligned(4096)));
static uint8_t ul_data[4096] __attribute__((aligned(4096)));
static uint32_t ul_data_enabled;
static uint8_t ul_stack[4096] __attribute__((aligned(4096)));
static uint32_t ul_vector,ul_error,ul_running,ul_exit;
static char ul_log[129];
int ul_range(uint32_t address,uint32_t n){if(n>4096)return 0;if(ul_data_enabled&&address>=NE_DATA&&address-NE_DATA<=4096&&n<=4096-(address-NE_DATA))return 1;if(address>=UL_CODE&&address-UL_CODE<=4096&&n<=4096-(address-UL_CODE))return 1;if(address>=UL_STACK&&address-UL_STACK<=4096&&n<=4096-(address-UL_STACK))return 1;return 0;}
static void ul_map_build(void){for(uint32_t i=0;i<1024;i++){ul_directory[i]=(i<<22)|0x83;ul_table[i]=0;}ul_directory[UL_CODE>>22]=((uint32_t)(uintptr_t)ul_table)|7;ul_table[0]=((uint32_t)(uintptr_t)ul_code)|5;ul_table[4]=((uint32_t)(uintptr_t)ul_stack)|7;if(ul_data_enabled)ul_table[2]=((uint32_t)(uintptr_t)ul_data)|7;}
static int ul_copy(uint32_t address,uint32_t n){if(!ul_running||n>128||!ul_range(address,n))return -14;const uint8_t*source;if(address>=UL_STACK)source=ul_stack+(address-UL_STACK);else if(ul_data_enabled&&address>=NE_DATA)source=ul_data+(address-NE_DATA);else source=ul_code+(address-UL_CODE);for(uint32_t i=0;i<n;i++)ul_log[i]=(char)source[i];ul_log[n]=0;return (int)n;}
uint32_t ul_last_vector(void){return ul_vector;}
uint32_t ul_last_error(void){return ul_error;}
const char *ul_report(void){return ul_log;}
static int np_syscall(uint32_t,uint32_t,uint32_t,uint32_t);
static uint32_t np_limit_reached(void);
#ifndef OCEANOS_HOST_TEST
extern void ul_enter(uint32_t entry,uint32_t stack);
extern void ul_isr_default(void),ul_syscall_entry(void);
extern uintptr_t ul_exception_table[32];
extern const uint8_t ul_good_start[],ul_good_end[],ul_badptr_start[],ul_badptr_end[],ul_fault_start[],ul_fault_end[],ul_io_start[],ul_io_end[];
static uint64_t ul_gdt[6];
struct __attribute__((packed)) ul_descriptor {uint16_t limit;uint32_t base;};
struct __attribute__((packed)) ul_gate {uint16_t low,selector;uint8_t zero,flags;uint16_t high;};
static struct ul_gate ul_idt[256];
static uint8_t ul_tss[104],ul_kernel_stack[65536] __attribute__((aligned(16)));
/* Stack built by user_mode.S: all saved items are 32-bit slots. */
struct ul_frame {uint32_t gs,fs,es,ds,edi,esi,ebp,esp,ebx,edx,ecx,eax,vector,error,eip,cs,eflags,useresp,ss;};
int ul_trap(struct ul_frame*f){
 if(!ul_running||(f->cs&3)!=3)return 2;
 if(f->vector==128){if(f->eax==0){ul_exit=f->ebx;return 1;}f->eax=(uint32_t)np_syscall(f->eax,f->ebx,f->ecx,f->edx);if(np_limit_reached()){ul_exit=124;return 1;}return 0;}
 ul_vector=f->vector;ul_error=f->error;return 1;
}
static void ul_gate_set(uint32_t i,uintptr_t entry,uint8_t flags){ul_idt[i].low=(uint16_t)entry;ul_idt[i].selector=8;ul_idt[i].zero=0;ul_idt[i].flags=flags;ul_idt[i].high=(uint16_t)(entry>>16);}
static int ul_cpu_pse(void){uint32_t a=1,b,c,d;__asm__ volatile("cpuid":"+a"(a),"=b"(b),"=c"(c),"=d"(d));return (d&8)!=0;}
static int ul_execute(uint32_t entry){if(ul_running||!ul_cpu_pse()||entry<UL_CODE||entry-UL_CODE>=4096)return -1;
 uint32_t cr0,cr3,cr4;__asm__ volatile("mov %%cr0,%0":"=r"(cr0));if(cr0&0x80000000u)return -2;
 __asm__ volatile("mov %%cr3,%0":"=r"(cr3));__asm__ volatile("mov %%cr4,%0":"=r"(cr4));if(cr4&0x20)return -3;
 struct ul_descriptor old_gdt,old_idt,gd={sizeof ul_gdt-1,(uint32_t)(uintptr_t)ul_gdt},id={sizeof ul_idt-1,(uint32_t)(uintptr_t)ul_idt};
 uint32_t flags;__asm__ volatile("pushfl;popl %0;cli":"=r"(flags)::"memory");__asm__ volatile("sgdt %0":"=m"(old_gdt));__asm__ volatile("sidt %0":"=m"(old_idt));
 memset(ul_tss,0,sizeof ul_tss);ul_map_build();
 ul_gdt[0]=0;ul_gdt[1]=0x00cf9a000000ffffULL;ul_gdt[2]=0x00cf92000000ffffULL;ul_gdt[3]=0x00cffa000000ffffULL;ul_gdt[4]=0x00cff2000000ffffULL;
 uint32_t base=(uint32_t)(uintptr_t)ul_tss;ul_gdt[5]=103u|((uint64_t)(base&0xffffff)<<16)|((uint64_t)0x89<<40)|((uint64_t)(base>>24)<<56);
 *(uint32_t*)(ul_tss+4)=(uint32_t)(uintptr_t)(ul_kernel_stack+sizeof ul_kernel_stack);*(uint16_t*)(ul_tss+8)=16;*(uint16_t*)(ul_tss+102)=104;
 for(uint32_t i=0;i<256;i++)ul_gate_set(i,(uintptr_t)ul_isr_default,0x8e);for(uint32_t i=0;i<32;i++)ul_gate_set(i,ul_exception_table[i],0x8e);ul_gate_set(128,(uintptr_t)ul_syscall_entry,0xee);
 ul_vector=ul_error=0;ul_exit=0xffffffffu;ul_log[0]=0;ul_running=1;
 __asm__ volatile("lgdt %0;lidt %1"::"m"(gd),"m"(id):"memory");uint16_t tr=40;__asm__ volatile("ltr %0"::"r"(tr):"memory");
 uint32_t active_cr4=cr4|0x10,active_cr3=(uint32_t)(uintptr_t)ul_directory,active_cr0=cr0|0x80010000u;
 __asm__ volatile("mov %0,%%cr4;mov %1,%%cr3;mov %2,%%cr0"::"r"(active_cr4),"r"(active_cr3),"r"(active_cr0):"memory");
 ul_enter(entry,UL_STACK+4096);
 __asm__ volatile("mov %0,%%cr0;mov %1,%%cr3;mov %2,%%cr4"::"r"(cr0),"r"(cr3),"r"(cr4):"memory");
 __asm__ volatile("lgdt %0;lidt %1"::"m"(old_gdt),"m"(old_idt):"memory");ul_running=0;__asm__ volatile("pushl %0;popfl"::"r"(flags):"memory","cc");return 0;
}
static int ul_run_fixture(const uint8_t*start,const uint8_t*end){if(end<=start||(uintptr_t)(end-start)>4096)return -1;memset(ul_code,0,sizeof ul_code);memset(ul_stack,0,sizeof ul_stack);memset(ul_data,0,sizeof ul_data);ul_data_enabled=0;memcpy(ul_code,start,(uint32_t)(end-start));return ul_execute(UL_CODE);}
int ul_selftest(void){int r=ul_run_fixture(ul_good_start,ul_good_end);if(r)return r;if(ul_vector||ul_exit)return -10;
 r=ul_run_fixture(ul_badptr_start,ul_badptr_end);if(r||ul_vector||ul_exit)return -11;
 r=ul_run_fixture(ul_fault_start,ul_fault_end);if(r||ul_vector!=14||(ul_error&5)!=5)return -12;
 r=ul_run_fixture(ul_io_start,ul_io_end);if(r||ul_vector!=13)return -13;return 0;}
#else
static int ul_execute(uint32_t entry){(void)entry;return -38;}
int ul_selftest(void){return -38;} /* Never simulate successful privilege execution. */
#endif
