#ifndef OCEAN_HOST_SERVICES_H
#define OCEAN_HOST_SERVICES_H
#include "runtime.h"
/* Native kernel-call ABI, NOT a POSIX or Wine ABI. No user-pointer validation. */
#define OH_READ 1u
#define OH_WRITE 2u
#define OH_CREATE 4u
#define OH_TRUNC 8u
#define OH_APPEND 16u
#define OH_EXCL 32u
#define OH_PAGE_SIZE 4096u
#define OH_POOL_PAGES 2048u
#define OH_FD_COUNT 64u
uintptr_t oh_pages_alloc(uint32_t owner,uint32_t pages);
int oh_pages_free(uint32_t owner,uintptr_t ptr);
uint32_t oh_pages_available(void);
int oh_open(uint32_t owner,uint32_t parent,const char*path,uint32_t flags);
int oh_read(uint32_t owner,int fd,void*buf,uint32_t n);
int oh_write(uint32_t owner,int fd,const void*buf,uint32_t n);
int oh_seek(uint32_t owner,int fd,int offset,uint32_t whence);
int oh_close(uint32_t owner,int fd);
int oh_size(uint32_t owner,int fd);
uint32_t oh_owner_release(uint32_t owner);
uint32_t oh_fd_available(void);
#endif
