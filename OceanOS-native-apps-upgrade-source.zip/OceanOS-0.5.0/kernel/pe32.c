#include "pe32.h"
static uint32_t r16(const uint8_t*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8);}
static uint32_t r32(const uint8_t*p){return r16(p)|(r16(p+2)<<16);}
static int span(uint32_t at,uint32_t n,uint32_t size){return at<=size&&n<=size-at;}
int ocean_pe32_inspect(const uint8_t*d,uint32_t n,ocean_pe_info*out){
 ocean_pe_info q={0};uint32_t pe,opt,os,ns,st,headers,dirs;
 if(!d||!out||n<64||r16(d)!=0x5a4d)return 1;
 pe=r32(d+60);if(!span(pe,24,n)||r32(d+pe)!=0x4550)return 2;
 if(r16(d+pe+4)!=0x14c)return 3;
 ns=r16(d+pe+6);os=r16(d+pe+20);opt=pe+24;
 if(!ns||ns>96||os<96||!span(opt,os,n))return 4;
 if(r16(d+opt)!=0x10b)return 5;
 if(!(r16(d+pe+22)&2)||(r16(d+pe+22)&0x2000))return 6;
 q.entry_rva=r32(d+opt+16);q.image_base=r32(d+opt+28);
 q.image_size=r32(d+opt+56);headers=r32(d+opt+60);q.section_count=ns;
 if(!q.image_size||!headers||headers>n||headers>q.image_size||q.entry_rva>=q.image_size)return 7;
 if(q.image_base>0xffffffffU-(q.image_size-1))return 7;
 dirs=r32(d+opt+92);if(dirs>(os-96)/8)return 8;
 st=opt+os;if(!span(st,ns*40,n)||st+ns*40>headers)return 9;
 if(dirs>1){q.imports_rva=r32(d+opt+104);q.imports_size=r32(d+opt+108);if(!span(q.imports_rva,q.imports_size,q.image_size))return 10;}
 if(dirs>5){q.relocations_rva=r32(d+opt+136);q.relocations_size=r32(d+opt+140);if(!span(q.relocations_rva,q.relocations_size,q.image_size))return 10;}
 for(uint32_t i=0;i<ns;i++){
  const uint8_t*s=d+st+i*40;uint32_t vs=r32(s+8),va=r32(s+12),rs=r32(s+16),rp=r32(s+20),extent=vs>rs?vs:rs;
  if((rs&&!span(rp,rs,n))||!span(va,extent,q.image_size))return 11;
 }
 *out=q;return 0;
}
