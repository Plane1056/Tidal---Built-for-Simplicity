static void oh_invalidate_files(void);
static uint32_t oh_files_open(void);
/* OceanFS 3: 4 KiB blocks, 8192 user entries, streamed copy-on-write file replacement.
 * Files <=1 GiB; linked extent index pages; bounded data cache and writer staging.
 * No journal or torn-sector guarantee. Explicit format only; never mounts OceanFS1. */
#define SECTOR 512u
#define BLOCK 4096u
#define FS_ENTRIES 8193u
#define FS_NAME 128u
#define FS_TABLE_LBA 520u
#define FS_TABLE_SECTORS 4097u
#define TABLE_BLOCKS 513u
#define DATA_START 578u
#define MAX_BLOCKS 2097152u
#define BITMAP_BYTES 262144u
#define MAX_FILE (1024u*1024u*1024u)
#define MAX_FILE_BLOCKS (MAX_FILE/BLOCK)
#define BITMAP_BLOCKS (BITMAP_BYTES/BLOCK)
#define TABLE_START (1u+BITMAP_BLOCKS)
#define MAX_INDEX_PAGES ((MAX_FILE_BLOCKS+509u)/510u)
#define NOTE_CAP (1024u*1024u)
#define RAM_BLOCKS 2048u
#define FS_MIN_SECTORS (2048u*8u)
#define T_FREE 0u
#define T_FILE 1u
#define T_DIR 2u
#define NONE 0xffffffffu
#define E_FULL 0xfffffff0u
#define E_NAME 0xfffffff1u
#define E_EXISTS 0xfffffff2u
#define E_IO 0xfffffff3u
#define E_NOTEMPTY 0xfffffff4u
#define E_NOENT 0xfffffff5u
#define E_ISDIR 0xfffffff6u
#define E_BIG 0xfffffff7u
#define E_BUSY 0xfffffff8u
#define IS_ERR(v) ((v)>=0xfffffff0u)
static int memcmp_eq(const void*a,const void*b,uint32_t n){const uint8_t*x=a,*y=b;while(n--)if(*x++!=*y++)return 0;return 1;}
typedef struct{char name[128];uint32_t type,parent,size,index,flags;uint8_t reserved[108];}fs_entry;
typedef char entry_size_check[sizeof(fs_entry)==256?1:-1];
static fs_entry ent[FS_ENTRIES];
static uint8_t bitmap_dirty[BITMAP_BLOCKS];
static uint8_t bitmap[BITMAP_BYTES],seen_blocks[BITMAP_BYTES],ramdisk[RAM_BLOCKS*BLOCK];
static uint32_t disk_state,disk_sectors,cwd,doc_current=NONE,disk_writes,total_blocks=RAM_BLOCKS,backend;
static uint32_t alloc_hint=DATA_START;
#ifdef OCEANOS_HOST_TEST
static uint32_t host_disk_sectors,host_fail_after=NONE;
extern int ocean_test_read(uint32_t lba,void*out);
extern int ocean_test_write(uint32_t lba,const void*in);
static int disk_probe(void){if(!host_disk_sectors)return 0;disk_sectors=host_disk_sectors;return 1;}
static int disk_read(uint32_t lba,void*b){if(lba>=disk_sectors)return 0;return ocean_test_read(lba,b);}
static int disk_write(uint32_t lba,const void*b){if(lba>=disk_sectors)return 0;if(host_fail_after!=NONE){if(!host_fail_after)return 0;host_fail_after--;}if(!ocean_test_write(lba,b))return 0;disk_writes++;return 1;}
#else
static inline uint16_t in16(uint16_t p){uint16_t x;__asm__ volatile("inw %1,%0":"=a"(x):"Nd"(p));return x;}
static inline void out16(uint16_t p,uint16_t x){__asm__ volatile("outw %0,%1"::"a"(x),"Nd"(p));}
static uint16_t ata_io;static uint8_t ata_sel;
static void ata_delay(void){for(uint32_t i=0;i<4;i++)in8(ata_io+0x206);}
static int ata_busy_wait(void){for(uint32_t i=0;i<4000000;i++)if(!(in8(ata_io+7)&0x80))return 1;return 0;}
static int ata_drq_wait(void){for(uint32_t i=0;i<4000000;i++){uint8_t st=in8(ata_io+7);if(st&0x80)continue;if(st&0x21)return 0;if(st&8)return 1;}return 0;}
static int ata_identify(uint16_t io,uint8_t sel){
 uint16_t id[256];ata_io=io;out8(io+6,sel);ata_delay();if(in8(io+7)==0xff)return 0;
 out8(io+0x206,2);out8(io+2,0);out8(io+3,0);out8(io+4,0);out8(io+5,0);out8(io+7,0xec);
 if(in8(io+7)==0)return 0;if(!ata_busy_wait())return 0;
 if(in8(io+4)||in8(io+5))return 0; /* ATAPI (CD-ROM) or SATA signature: not a plain IDE disk */
 if(!ata_drq_wait())return 0;for(uint32_t i=0;i<256;i++)id[i]=in16(io);
 if(!(id[49]&0x200))return 0; /* LBA required */
 uint32_t n=id[60]|((uint32_t)id[61]<<16);if(!n)return 0;disk_sectors=n;ata_sel=sel;return 1;}
static int disk_probe(void){static const uint16_t bus[2]={0x1f0,0x170};for(uint32_t b=0;b<2;b++)for(uint32_t d=0;d<2;d++)if(ata_identify(bus[b],d?0xf0:0xe0))return 1;return 0;}
static int ata_setup(uint32_t lba,uint8_t cmd){if(lba>=disk_sectors||lba>=0x10000000u)return 0;if(!ata_busy_wait())return 0;out8(ata_io+6,ata_sel|((lba>>24)&15));ata_delay();out8(ata_io+2,1);out8(ata_io+3,lba);out8(ata_io+4,lba>>8);out8(ata_io+5,lba>>16);out8(ata_io+7,cmd);return ata_drq_wait();}
static int disk_read(uint32_t lba,void*b){if(!ata_setup(lba,0x20))return 0;uint16_t*w=b;for(uint32_t i=0;i<256;i++)w[i]=in16(ata_io);return 1;}
static int disk_write(uint32_t lba,const void*b){if(!ata_setup(lba,0x30))return 0;const uint16_t*w=b;for(uint32_t i=0;i<256;i++)out16(ata_io,w[i]);if(!ata_busy_wait()||(in8(ata_io+7)&0x21))return 0;out8(ata_io+7,0xe7);if(!ata_busy_wait())return 0;disk_writes++;return !(in8(ata_io+7)&0x21);}
#endif
static int raw_read(uint32_t block,void*out){if(block>=total_blocks)return 0;if(!backend){memcpy(out,ramdisk+block*BLOCK,BLOCK);return 1;}for(uint32_t i=0;i<8;i++)if(!disk_read(block*8+i,(uint8_t*)out+i*SECTOR))return 0;return 1;}
static int raw_write(uint32_t block,const void*in){if(block>=total_blocks||disk_state==3)return 0;if(!backend){memcpy(ramdisk+block*BLOCK,in,BLOCK);return 1;}for(uint32_t i=0;i<8;i++)if(!disk_write(block*8+i,(const uint8_t*)in+i*SECTOR)){disk_state=3;return 0;}return 1;}
/* Eight read cache blocks (32 KiB). All writes update/invalidate matching cache lines. */
static uint8_t cache[8][BLOCK];static uint32_t tags[8],next_cache;
static void cache_clear(void){for(uint32_t i=0;i<8;i++)tags[i]=NONE;next_cache=0;}
static int read_block(uint32_t b,void*out){for(uint32_t i=0;i<8;i++)if(tags[i]==b){memcpy(out,cache[i],BLOCK);return 1;}uint32_t c=next_cache++%8;if(!raw_read(b,cache[c])){tags[c]=NONE;return 0;}tags[c]=b;memcpy(out,cache[c],BLOCK);return 1;}
static int write_block(uint32_t b,const void*in){for(uint32_t i=0;i<8;i++)if(tags[i]==b)tags[i]=NONE;return raw_write(b,in);}
static uint32_t rd32(const uint8_t*p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static void wr32(uint8_t*p,uint32_t n){p[0]=n;p[1]=n>>8;p[2]=n>>16;p[3]=n>>24;}
static uint32_t hash32(const uint8_t*p,uint32_t n){uint32_t h=2166136261u;for(uint32_t i=0;i<n;i++)h=(h^p[i])*16777619u;return h;}
static int used(uint32_t b){return b>=total_blocks||((bitmap[b>>3]>>(b&7))&1);}
static void bitset(uint32_t b,int v){if(b<total_blocks){uint32_t at=b>>3;uint8_t old=bitmap[at];if(v)bitmap[at]|=1u<<(b&7);else bitmap[at]&=~(1u<<(b&7));if(old!=bitmap[at])bitmap_dirty[at/BLOCK]=1;}}
static uint32_t block_alloc(void){for(uint32_t k=0;k<total_blocks-DATA_START;k++){uint32_t b=alloc_hint++;if(alloc_hint>=total_blocks)alloc_hint=DATA_START;if(!used(b)){bitset(b,1);return b;}}return NONE;}
static int bitmap_write(void){for(uint32_t i=0;i<BITMAP_BLOCKS;i++)if(bitmap_dirty[i]){if(!write_block(1+i,bitmap+i*BLOCK))return 0;bitmap_dirty[i]=0;}return 1;}
static uint32_t free_blocks(void){uint32_t n=0;for(uint32_t b=DATA_START;b<total_blocks;b++)if(!used(b))n++;return n;}
static int entry_store(uint32_t id){uint8_t b[BLOCK];uint32_t block=TABLE_START+(id*256)/BLOCK,offset=(id*256)%BLOCK;if(!read_block(block,b))return 0;memcpy(b+offset,&ent[id],256);return write_block(block,b);}
static void fs_zero(void){memset(ent,0,sizeof ent);memset(bitmap,0,sizeof bitmap);memset(bitmap_dirty,1,sizeof bitmap_dirty);ent[0].type=T_DIR;ent[0].parent=0;ent[0].name[0]='/';cwd=0;doc_current=NONE;alloc_hint=DATA_START;for(uint32_t i=0;i<DATA_START;i++)bitset(i,1);cache_clear();}
static int name_ok(const char*n){uint32_t len=0;while(len<FS_NAME&&n[len])len++;if(!len||len>=FS_NAME||n[0]==' '||n[len-1]==' '||equal(n,".")||equal(n,".."))return 0;for(uint32_t i=0;i<len;){uint8_t c=n[i++];if(c<32||c==127||c=='/'||c=='\\')return 0;if(c<128)continue;uint32_t need,cp,min;if(c>=0xc2&&c<=0xdf){need=1;cp=c&31;min=128;}else if(c>=0xe0&&c<=0xef){need=2;cp=c&15;min=2048;}else if(c>=0xf0&&c<=0xf4){need=3;cp=c&7;min=65536;}else return 0;if(i+need>len)return 0;while(need--){uint8_t t=n[i++];if((t&0xc0)!=0x80)return 0;cp=(cp<<6)|(t&63);}if(cp<min||cp>0x10ffff||(cp>=0xd800&&cp<=0xdfff))return 0;}return 1;}
static uint32_t find_child(uint32_t dir,const char*n){if(dir>=FS_ENTRIES||ent[dir].type!=T_DIR)return NONE;for(uint32_t i=1;i<FS_ENTRIES;i++)if(ent[i].type&&ent[i].parent==dir&&equal(ent[i].name,n))return i;return NONE;}
static uint32_t child_count(uint32_t dir){uint32_t n=0;for(uint32_t i=1;i<FS_ENTRIES;i++)if(ent[i].type&&ent[i].parent==dir)n++;return n;}
/* Extent pages: magic EX2P, count@4, next@8, reserved@12; 510 (start,count) pairs. */
static uint32_t file_block(uint32_t id,uint32_t logical){uint8_t page[BLOCK];uint32_t index=ent[id].index;for(uint32_t guard=0;index&&guard<MAX_FILE_BLOCKS;guard++){if(index<DATA_START||index>=total_blocks||!read_block(index,page)||!memcmp_eq(page,"EX2P",4))return NONE;uint32_t n=rd32(page+4);if(n>510)return NONE;for(uint32_t i=0;i<n;i++){uint32_t start=rd32(page+16+i*8),count=rd32(page+20+i*8);if(!count||start<DATA_START||start>=total_blocks||count>total_blocks-start)return NONE;if(logical<count)return start+logical;logical-=count;}index=rd32(page+8);}return NONE;}
static uint32_t fs_read_at(uint32_t id,uint32_t off,void*out,uint32_t n){if(id>=FS_ENTRIES||ent[id].type!=T_FILE)return E_NOENT;if(off>=ent[id].size)return 0;if(n>ent[id].size-off)n=ent[id].size-off;uint8_t buf[BLOCK];uint32_t done=0;while(done<n){uint32_t pos=off+done,b=file_block(id,pos/BLOCK),take=BLOCK-pos%BLOCK;if(take>n-done)take=n-done;if(b==NONE||!read_block(b,buf))return E_IO;memcpy((uint8_t*)out+done,buf+pos%BLOCK,take);done+=take;}return done;}
static void chain_free(uint32_t index){uint8_t page[BLOCK];for(uint32_t g=0;index&&g<MAX_FILE_BLOCKS;g++){if(index<DATA_START||index>=total_blocks||!read_block(index,page)||!memcmp_eq(page,"EX2P",4))return;uint32_t n=rd32(page+4),next=rd32(page+8);if(n>510)return;for(uint32_t i=0;i<n;i++){uint32_t b=rd32(page+16+i*8),count=rd32(page+20+i*8);if(b<DATA_START||b>=total_blocks||count>total_blocks-b)return;for(uint32_t j=0;j<count;j++)bitset(b+j,0);}bitset(index,0);index=next;}}
/* One sequential replacement writer; data staged in blocks, never whole-file RAM. */
static uint32_t writer_id=NONE,writer_map[MAX_FILE_BLOCKS],writer_count,writer_size,writer_fill;
static uint8_t writer_buf[BLOCK];
static void fs_abort(void){if(writer_id!=NONE){for(uint32_t i=0;i<writer_count;i++)bitset(writer_map[i],0);}writer_id=NONE;writer_fill=writer_count=writer_size=0;}
static uint32_t fs_begin_replace(uint32_t id){if(writer_id!=NONE)return E_BUSY;if(disk_state==3)return E_IO;if(id>=FS_ENTRIES||ent[id].type!=T_FILE)return E_NOENT;writer_id=id;writer_count=writer_size=writer_fill=0;memset(writer_buf,0,BLOCK);return 0;}
static uint32_t writer_flush(void){uint32_t b=block_alloc();if(b==NONE)return E_FULL;if(!write_block(b,writer_buf)){bitset(b,0);return E_IO;}writer_map[writer_count++]=b;writer_fill=0;memset(writer_buf,0,BLOCK);return 0;}
static uint32_t fs_append(const void*data,uint32_t n){if(writer_id==NONE)return E_NOENT;if(n>MAX_FILE-writer_size)return E_BIG;const uint8_t*p=data;while(n){uint32_t take=BLOCK-writer_fill;if(take>n)take=n;memcpy(writer_buf+writer_fill,p,take);writer_fill+=take;writer_size+=take;p+=take;n-=take;if(writer_fill==BLOCK){uint32_t r=writer_flush();if(IS_ERR(r))return r;}}return 0;}
static uint32_t fs_finish(void){if(writer_id==NONE)return E_NOENT;uint32_t r;if(writer_fill){r=writer_flush();if(IS_ERR(r)){fs_abort();return r;}}uint32_t runs=0;for(uint32_t i=0;i<writer_count;i++)if(!i||writer_map[i]!=writer_map[i-1]+1)runs++;uint32_t pages=(runs+509)/510,indices[MAX_INDEX_PAGES];if(pages>MAX_INDEX_PAGES){fs_abort();return E_FULL;}uint32_t made=0;for(;made<pages;made++){indices[made]=block_alloc();if(indices[made]==NONE){for(uint32_t i=0;i<made;i++)bitset(indices[i],0);fs_abort();return E_FULL;}}
uint8_t page[BLOCK];uint32_t at=0;for(uint32_t p=0;p<pages;p++){memset(page,0,BLOCK);memcpy(page,"EX2P",4);wr32(page+8,p+1<pages?indices[p+1]:0);uint32_t n=0;while(at<writer_count&&n<510){uint32_t start=writer_map[at++],count=1;while(at<writer_count&&writer_map[at]==start+count){count++;at++;}wr32(page+16+n*8,start);wr32(page+20+n*8,count);n++;}wr32(page+4,n);if(!write_block(indices[p],page)){for(uint32_t i=0;i<pages;i++)bitset(indices[i],0);fs_abort();return E_IO;}}
if(!bitmap_write()){fs_abort();return E_IO;}uint32_t id=writer_id,oldindex=ent[id].index,oldsize=ent[id].size;ent[id].index=pages?indices[0]:0;ent[id].size=writer_size;if(!entry_store(id)){ent[id].index=oldindex;ent[id].size=oldsize;writer_id=NONE;return E_IO;}writer_id=NONE;chain_free(oldindex);if(!bitmap_write())return E_IO;return id;}
static uint32_t fs_replace(uint32_t id,const void*data,uint32_t n){uint32_t r=fs_begin_replace(id);if(IS_ERR(r))return r;r=fs_append(data,n);if(IS_ERR(r)){fs_abort();return r;}return fs_finish();}
static uint32_t entry_make(uint32_t dir,const char*name,uint32_t type,const char*content){if(disk_state==3)return E_IO;if(dir>=FS_ENTRIES||ent[dir].type!=T_DIR)return E_NOENT;if(type!=T_FILE&&type!=T_DIR)return E_NAME;if(!name_ok(name))return E_NAME;if(find_child(dir,name)!=NONE)return E_EXISTS;uint32_t id=NONE;for(uint32_t i=1;i<FS_ENTRIES;i++)if(!ent[i].type){id=i;break;}if(id==NONE)return E_FULL;memset(&ent[id],0,sizeof ent[id]);strcopy(ent[id].name,name,FS_NAME);ent[id].type=type;ent[id].parent=dir;
/* Publish empty entry, then replace; rollback RAM on failure without retaining ghost IDs. */
if(!entry_store(id)){memset(&ent[id],0,sizeof ent[id]);return E_IO;}if(type==T_FILE&&content&&*content){uint32_t r=fs_replace(id,content,length(content));if(IS_ERR(r)){/* Published empty file remains identifiable for retry. */return r;}}return id;}
static uint32_t entry_write_text(uint32_t id,const char*t){return fs_replace(id,t,length(t));}
static uint32_t oh_file_busy(uint32_t id);
static uint32_t entry_delete(uint32_t id){if(oh_file_busy(id))return E_BUSY;if(disk_state==3)return E_IO;if(writer_id!=NONE)return E_BUSY;if(id==0||id>=FS_ENTRIES||!ent[id].type)return E_NOENT;if(ent[id].type==T_DIR&&child_count(id))return E_NOTEMPTY;fs_entry old=ent[id];memset(&ent[id],0,sizeof ent[id]);if(!entry_store(id)){ent[id]=old;return E_IO;}chain_free(old.index);if(!bitmap_write())return E_IO;if(doc_current==id)doc_current=NONE;return id;}
static uint32_t entry_rename(uint32_t id,const char*n){if(disk_state==3)return E_IO;if(id==0||id>=FS_ENTRIES||!ent[id].type)return E_NOENT;if(!name_ok(n))return E_NAME;uint32_t other=find_child(ent[id].parent,n);if(other!=NONE&&other!=id)return E_EXISTS;char old[FS_NAME];memcpy(old,ent[id].name,FS_NAME);strcopy(ent[id].name,n,FS_NAME);if(!entry_store(id)){memcpy(ent[id].name,old,FS_NAME);return E_IO;}return id;}
static uint32_t fs_write_at(uint32_t id,uint32_t off,const void*data,uint32_t n){if(id>=FS_ENTRIES||ent[id].type!=T_FILE)return E_NOENT;if(off>MAX_FILE||n>MAX_FILE-off)return E_BIG;uint32_t old=ent[id].size,end=off+n,size=end>old?end:old;if(!n)return 0;uint32_t r=fs_begin_replace(id);if(IS_ERR(r))return r;uint8_t buf[BLOCK];for(uint32_t pos=0;pos<size;){uint32_t take=size-pos;if(take>BLOCK)take=BLOCK;memset(buf,0,take);if(pos<old){uint32_t got=fs_read_at(id,pos,buf,take);if(IS_ERR(got)){fs_abort();return got;}}uint32_t a=pos>off?pos:off,b=pos+take<end?pos+take:end;if(b>a)memcpy(buf+a-pos,(const uint8_t*)data+a-off,b-a);r=fs_append(buf,take);if(IS_ERR(r)){fs_abort();return r;}pos+=take;}r=fs_finish();return IS_ERR(r)?r:n;}
static uint32_t fs_truncate(uint32_t id,uint32_t size){if(size>MAX_FILE)return E_BIG;if(id>=FS_ENTRIES||ent[id].type!=T_FILE)return E_NOENT;uint32_t old=ent[id].size,r=fs_begin_replace(id);if(IS_ERR(r))return r;uint8_t buf[BLOCK];for(uint32_t p=0;p<size;){uint32_t n=size-p;if(n>BLOCK)n=BLOCK;memset(buf,0,n);if(p<old){r=fs_read_at(id,p,buf,n);if(IS_ERR(r)){fs_abort();return r;}}r=fs_append(buf,n);if(IS_ERR(r)){fs_abort();return r;}p+=n;}return fs_finish();}
static int super_write(void){uint8_t b[BLOCK];memset(b,0,BLOCK);memcpy(b,"OCEANFS3",8);wr32(b+8,3);wr32(b+12,BLOCK);wr32(b+16,FS_ENTRIES);wr32(b+20,total_blocks);wr32(b+24,1);wr32(b+28,BITMAP_BLOCKS);wr32(b+32,TABLE_START);wr32(b+36,TABLE_BLOCKS);wr32(b+40,DATA_START);wr32(b+44,hash32(b,44));return write_block(0,b);}
static int metadata_blank(void){uint8_t b[BLOCK];memset(b,0,BLOCK);for(uint32_t i=0;i<TABLE_BLOCKS;i++)if(!write_block(TABLE_START+i,b))return 0;return entry_store(0)&&bitmap_write();}
static void seed_docs(void){entry_make(0,"Welcome.TXT",T_FILE,"Welcome to OceanOS 0.4!\nOceanFS 3 supports 1 GiB binary files and 8192 entries.\nNotepad edits ASCII documents up to 1 MiB.\nAttach the new disk image for persistent files.");entry_make(0,"Roadmap.TXT",T_FILE,"Next: journal, hardware tests, process isolation, application loading.\n.coral and .refraction remain planned formats.");uint32_t d=entry_make(0,"Notes",T_DIR,0);if(!IS_ERR(d))entry_make(d,"Todo.TXT",T_FILE,"- save and reopen files\n- test persistence in a disposable VM");}
static int mark_seen(uint32_t b){if(b<DATA_START||b>=total_blocks||!used(b)||(seen_blocks[b>>3]&(1u<<(b&7))))return 0;seen_blocks[b>>3]|=1u<<(b&7);return 1;}
static int validate(void){if(ent[0].type!=T_DIR||ent[0].parent||ent[0].size||ent[0].index||!equal(ent[0].name,"/"))return 0;memset(seen_blocks,0,sizeof seen_blocks);for(uint32_t b=0;b<DATA_START;b++)if(!used(b))return 0;for(uint32_t i=1;i<FS_ENTRIES;i++){fs_entry*e=&ent[i];if(!e->type)continue;if(e->type>T_DIR||e->name[FS_NAME-1]||!name_ok(e->name)||e->parent>=FS_ENTRIES||ent[e->parent].type!=T_DIR||e->size>MAX_FILE)return 0;uint32_t d=i;for(uint32_t depth=0;d;depth++){if(depth>=FS_ENTRIES||d>=FS_ENTRIES||ent[d].type==T_FREE)return 0;d=ent[d].parent;}for(uint32_t j=1;j<i;j++)if(ent[j].type&&ent[j].parent==e->parent&&equal(ent[j].name,e->name))return 0;if(e->type==T_DIR){if(e->size||e->index)return 0;continue;}uint32_t idx=e->index,count=0,pages=0;uint8_t b[BLOCK];while(idx){if(++pages>MAX_INDEX_PAGES||!mark_seen(idx)||!read_block(idx,b)||!memcmp_eq(b,"EX2P",4))return 0;uint32_t n=rd32(b+4);if(!n||n>510)return 0;for(uint32_t k=0;k<n;k++){uint32_t start=rd32(b+16+k*8),length=rd32(b+20+k*8);if(!length||start<DATA_START||start>=total_blocks||length>total_blocks-start||count+length>MAX_FILE_BLOCKS)return 0;for(uint32_t q=0;q<length;q++)if(!mark_seen(start+q))return 0;count+=length;}idx=rd32(b+8);}if(count!=(e->size+BLOCK-1)/BLOCK)return 0;}return 1;}
static void ram_start(uint32_t state_value){backend=0;total_blocks=RAM_BLOCKS;disk_state=0;memset(ramdisk,0,sizeof ramdisk);fs_zero();metadata_blank();super_write();seed_docs();disk_state=state_value;}
static void storage_init(void){oh_invalidate_files();writer_id=NONE;disk_state=0;backend=0;cache_clear();if(!disk_probe()){disk_sectors=0;ram_start(0);return;}uint8_t head[SECTOR];if(!disk_read(0,head)){ram_start(3);return;}if(!memcmp_eq(head,"OCEANFS3",8)){ram_start(2);return;}
uint32_t blocks=rd32(head+20);if(rd32(head+8)!=3||rd32(head+12)!=BLOCK||rd32(head+16)!=FS_ENTRIES||blocks<2048||blocks>MAX_BLOCKS||blocks>disk_sectors/8||rd32(head+24)!=1||rd32(head+28)!=BITMAP_BLOCKS||rd32(head+32)!=TABLE_START||rd32(head+36)!=TABLE_BLOCKS||rd32(head+40)!=DATA_START||rd32(head+44)!=hash32(head,44)){ram_start(3);return;}backend=1;total_blocks=blocks;fs_zero();backend=1;for(uint32_t i=0;i<BITMAP_BLOCKS;i++)if(!read_block(1+i,bitmap+i*BLOCK)){ram_start(3);return;}memset(bitmap_dirty,0,sizeof bitmap_dirty);uint8_t b[BLOCK];for(uint32_t i=0;i<TABLE_BLOCKS;i++){if(!read_block(TABLE_START+i,b)){ram_start(3);return;}uint32_t n=sizeof(ent)-i*BLOCK;if(n>BLOCK)n=BLOCK;memcpy((uint8_t*)ent+i*BLOCK,b,n);}if(!validate()){ram_start(3);return;}disk_state=1;}
static int storage_format(void){if(oh_files_open())return 0;if((disk_state!=1&&disk_state!=2)||!disk_sectors)return 0;uint32_t blocks=disk_sectors/8;if(blocks<2048||blocks>MAX_BLOCKS)return 0;backend=1;total_blocks=blocks;disk_state=1;writer_id=NONE;fs_zero();if(!metadata_blank()||!super_write()){disk_state=3;return 0;}seed_docs();return disk_state==1;}

/* Explicit byte-count binary API. Offsets do not depend on NUL terminators. */
uint32_t ocean_read(uint32_t id,uint32_t offset,void*out,uint32_t count){return fs_read_at(id,offset,out,count);}
uint32_t ocean_write(uint32_t id,uint32_t offset,const void*in,uint32_t count){return fs_write_at(id,offset,in,count);}
uint32_t ocean_truncate(uint32_t id,uint32_t size){return fs_truncate(id,size);}

/* Native C handle interface; one writer at a time, explicit errors. */
uint32_t ocean_open(ocean_file*h,uint32_t parent,const char*name){uint32_t id=find_child(parent,name);if(id==NONE||ent[id].type!=T_FILE)return E_NOENT;h->id=id;h->offset=0;h->active=1;return 0;}
uint32_t ocean_seek(ocean_file*h,uint32_t offset){if(!h->active)return E_NOENT;if(offset>MAX_FILE)return E_BIG;h->offset=offset;return 0;}
uint32_t ocean_read_next(ocean_file*h,void*buf,uint32_t n){if(!h->active)return E_NOENT;uint32_t r=fs_read_at(h->id,h->offset,buf,n);if(!IS_ERR(r))h->offset+=r;return r;}
uint32_t ocean_write_next(ocean_file*h,const void*buf,uint32_t n){if(!h->active)return E_NOENT;uint32_t r=fs_write_at(h->id,h->offset,buf,n);if(!IS_ERR(r))h->offset+=r;return r;}
uint32_t ocean_close(ocean_file*h){h->active=0;return 0;}
