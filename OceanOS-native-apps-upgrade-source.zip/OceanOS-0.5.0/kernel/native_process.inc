/* Single foreground native process. No scheduling, Wine, or Linux ABI. */
#include "../build/native_bundle.h"
#define NP_HISTORY 8u
#define NP_LOADED 1u
#define NP_RUNNING 2u
#define NP_EXITED 3u
#define NP_FAULTED 4u
#define NP_FAILED 5u
#define NP_LIMITED 6u
typedef struct {uint32_t pid,state,parent,exit_code,vector,error,calls;char name[64];} np_record;
static np_record np_records[NP_HISTORY],*np_active;
static uint32_t np_next_pid=1024,np_record_count,np_output_used,np_output_truncated,np_last_image_size;
static uint32_t np_stop,np_calls,np_write_bytes,np_read_bytes,np_stdout_bytes,np_create_calls;
static uint32_t np_break_base=NE_DATA,np_break_current=NE_DATA;
static uint32_t np_limit_reached(void){return np_active&&np_stop;}
static char np_output[1024];
static uint8_t np_elf_bytes[NE_MAX_FILE],np_io[4096];
static int np_user_range(uint32_t addr,uint32_t n,uint32_t write){if(!ul_range(addr,n))return 0;if(!write)return 1;if(addr>=UL_STACK&&addr-UL_STACK<=4096&&n<=4096-(addr-UL_STACK))return 1;return ul_data_enabled&&addr>=NE_DATA&&addr-NE_DATA<=4096&&n<=4096-(addr-NE_DATA);}
static uint8_t*np_pointer(uint32_t addr){if(addr>=UL_STACK)return ul_stack+(addr-UL_STACK);if(ul_data_enabled&&addr>=NE_DATA)return ul_data+(addr-NE_DATA);return ul_code+(addr-UL_CODE);}
static int np_cstring(uint32_t address,char*out,uint32_t cap){for(uint32_t i=0;i<cap;i++){if(address>0xffffffffu-i||!np_user_range(address+i,1,0))return -14;out[i]=(char)*np_pointer(address+i);if(!out[i])return 0;}return -36;}
static int np_syscall(uint32_t n,uint32_t a,uint32_t b,uint32_t c){
 if(!np_active)return n==1?ul_copy(a,b):-38;if(!ul_running||np_active->state!=NP_RUNNING)return -38;
 uint32_t owner=np_active->pid;if(++np_calls>1024){np_stop=1;return -11;}np_active->calls=np_calls;
 if(n==1){if(b>65536-np_stdout_bytes){np_stop=1;return -27;}if(b>4096)return -22;if(!np_user_range(a,b,0))return -14;np_stdout_bytes+=b;uint8_t*src=np_pointer(a);for(uint32_t i=0;i<b;i++){if(np_output_used<sizeof np_output-1)np_output[np_output_used++]=(char)src[i];else np_output_truncated=1;}np_output[np_output_used]=0;return (int)b;}
 if(n==2){if((b&OH_CREATE)&&++np_create_calls>32){np_stop=1;return -28;}char path[256];int r=np_cstring(a,path,sizeof path);return r?r:oh_open(owner,np_active->parent,path,b);}
 if(n==3){if(c>1048576-np_read_bytes){np_stop=1;return -27;}if(c>sizeof np_io)return -22;if(!np_user_range(b,c,1))return -14;int r=oh_read(owner,(int)a,np_io,c);if(r>0){memcpy(np_pointer(b),np_io,(uint32_t)r);np_read_bytes+=(uint32_t)r;}return r;}
 if(n==4){if(c>65536-np_write_bytes){np_stop=1;return -27;}if(c>sizeof np_io)return -22;if(!np_user_range(b,c,0))return -14;if(c)memcpy(np_io,np_pointer(b),c);int r=oh_write(owner,(int)a,np_io,c);if(r>0)np_write_bytes+=(uint32_t)r;return r;}
 if(n==5)return oh_close(owner,(int)a);if(n==6)return oh_seek(owner,(int)a,(int)b,c);if(n==7)return (int)owner;if(n==8)return oh_size(owner,(int)a);
 if(n==9){if(!a)return (int)np_break_current;if(a<np_break_base||a>NE_DATA+4096)return -12;uint32_t start=a<np_break_current?a:np_break_current,end=a>np_break_current?a:np_break_current;if(end>start)memset(ul_data+(start-NE_DATA),0,end-start);np_break_current=a;return (int)a;}return -38;
}
static int np_prepare(const uint8_t*b,uint32_t n,ne_image*out){ne_image image;int r=ne_validate(b,n,&image);if(r)return r;
 memset(ul_code,0,sizeof ul_code);memset(ul_data,0,sizeof ul_data);memset(ul_stack,0,sizeof ul_stack);ul_data_enabled=1;np_break_base=NE_DATA;
 for(uint32_t i=0;i<image.count;i++){ne_segment*s=&image.segments[i];uint8_t*target=s->flags==5?ul_code+(s->address-NE_CODE):ul_data+(s->address-NE_DATA);if(s->file_size)memcpy(target,b+s->offset,s->file_size);if(s->flags==6&&s->address+s->memory_size>np_break_base)np_break_base=s->address+s->memory_size;}
 np_break_base=(np_break_base+15)&~15u;np_break_current=np_break_base;*out=image;return 0;}
static int np_file_image(uint32_t parent,const char*path,ne_image*image,uint32_t load){np_last_image_size=0;const uint32_t loader_owner=0x7ffffffe;int fd=oh_open(loader_owner,parent,path,OH_READ);if(fd<0)return fd;int size=oh_size(loader_owner,fd);int r=-8;
 if(size>=52&&(uint32_t)size<=sizeof np_elf_bytes){r=oh_read(loader_owner,fd,np_elf_bytes,(uint32_t)size);if(r==size){np_last_image_size=(uint32_t)size;r=load?np_prepare(np_elf_bytes,(uint32_t)size,image):ne_validate(np_elf_bytes,(uint32_t)size,image);}else r=-5;}oh_close(loader_owner,fd);return r;}
static int np_run(uint32_t parent,const char*path){if(np_active||ul_running)return -16;ne_image image;int r=np_file_image(parent,path,&image,1);if(r)return r;
 uint32_t pid=np_next_pid++;if(np_next_pid>=0x7ffffffd)np_next_pid=1024;np_record*rec=&np_records[np_record_count%NP_HISTORY];np_record_count++;memset(rec,0,sizeof *rec);rec->pid=pid;rec->parent=parent;rec->state=NP_LOADED;strcopy(rec->name,path,sizeof rec->name);
 np_stop=np_calls=np_write_bytes=np_read_bytes=np_stdout_bytes=np_create_calls=0;np_output_used=np_output_truncated=0;np_output[0]=0;np_active=rec;rec->state=NP_RUNNING;r=ul_execute(image.entry);
 if(r){rec->state=NP_FAILED;rec->exit_code=(uint32_t)(-r);}else if(np_stop){rec->state=NP_LIMITED;rec->exit_code=124;}else if(ul_vector){rec->state=NP_FAULTED;rec->vector=ul_vector;rec->error=ul_error;}else{rec->state=NP_EXITED;rec->exit_code=ul_exit;}
 oh_owner_release(pid);np_active=0;return r;
}
static int np_install(uint32_t*installed,uint32_t*skipped){if(np_active||ul_running)return -16;*installed=*skipped=0;uint32_t dir=find_child(0,"Apps");if(dir==NONE)dir=entry_make(0,"Apps",T_DIR,0);if(IS_ERR(dir))return oh_error(dir);if(ent[dir].type!=T_DIR)return -20;
 for(uint32_t i=0;i<sizeof native_bundle/sizeof native_bundle[0];i++){const uint32_t owner=0x7ffffffe;int fd=oh_open(owner,dir,native_bundle[i].name,OH_READ|OH_WRITE|OH_CREATE|OH_EXCL);if(fd==-17){(*skipped)++;continue;}if(fd<0)return fd;int r=oh_write(owner,fd,native_bundle[i].bytes,native_bundle[i].size);oh_close(owner,fd);if(r!=(int)native_bundle[i].size)return r<0?r:-5;(*installed)++;}return 0;}
static const char*np_state(uint32_t state){if(state==NP_LOADED)return "loaded";if(state==NP_RUNNING)return "running";if(state==NP_EXITED)return "exited";if(state==NP_FAULTED)return "faulted";if(state==NP_LIMITED)return "limited";return "failed";}
