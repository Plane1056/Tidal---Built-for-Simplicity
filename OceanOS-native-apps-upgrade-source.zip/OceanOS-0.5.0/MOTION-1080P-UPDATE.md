# OceanOS 0.5.0 — Motion and Full-HD preview 2

Based on the attached personalization-preview-1 source, not an older foundation.
Focus remains native UI/customization; Windows and online browsing remain paused.

## Native motion and Tidal
kernel/motion.inc implements 32 bounded fixed-point easing channels. The existing
Tidal compiler can already call declared runtime functions, so this adds runtime
primitives and Tidal desktop integration, not a new language syntax or a CSS engine.

Tidal example (channels 0..31, values 0..1024, duration 0..2000ms):
  motion_set(0,0);
  motion_to(0,1024,170);
  let progress=motion_value(0);

Desktop allocations: 0 window entry, 1 Start, 2 reserved, 3..9 taskbar hover,
10..31 bounded button hover registry. motion_observe() is called in the kernel
loop; it advances timed motion and requests redraws. Smoothstep easing is used.
- Opening windows: short vertical settle (not scale or fade).
- Start: eased slide in/out; moving hit regions follow the visual position.
- Taskbar and registered buttons: interpolated hover color.
- Buttons: small immediate press inset (not a full animated CSS transform).
- Animations on/off toggle beside Save/Reset in Settings; session-only.
- No close/minimize animation, real blur, compositor, GPU acceleration or
  arbitrary CSS animation support. Context menu itself is not animated yet.

Timing targets approximately 16ms intervals when active. This is NOT a verified
60fps guarantee. Rendering remains software and single-threaded. Timing uses
PIT-calibrated TSC and assumes stable TSC. If calibration fails, transitions snap
to their targets rather than waiting indefinitely.

## Full-HD and fonts
Boot now tries 1920x1080 before existing fallback modes. Maximum framebuffer is
1920x1080. Firmware/video must expose a compatible 32-bit linear VESA mode within
the existing scan range. No SPICE guest agent, virtio-gpu driver, automatic resize
or resolution switching was added. Settings displays the active boot resolution.
The proportional shell font was rasterized from a 24px source, packed with 4-bit
coverage to fit the existing BIOS kernel-load window; it no longer enlarges the
old 16px shell atlas at Full-HD. Terminal/editor legacy content fonts are unchanged.
The screenshot is full-resolution; the GIF is a downscaled host-render preview.

## Save-path mitigation, NOT a confirmed freeze fix
Allocation bit changes now mark specific bitmap blocks dirty. bitmap_write writes
only changed blocks, and loaded bitmap blocks are marked clean. All existing
per-sector ATA flushes, filesystem commit ordering and file format are retained.
This reduces redundant writes without removing durability operations.
Measured with the existing sparse host-sector disk: first 5-byte replacement 32
sector writes; next 6-byte replacement 40. The prior algorithm wrote 1024 bitmap
sectors per replacement before file/index/entry writes.

Disk operations are STILL synchronous. Slow/missing hardware can still stall the
UI in polling waits. No async I/O, cooperative save state machine, scheduler,
time-based ATA deadlines or journal was added. The reported Boxes freeze has NOT
been reproduced or proven fixed. Do not treat the optimization as a data-safety
upgrade. Preserve a backup/disposable VM disk when testing.

## Verification actually performed
- ISO build and freestanding 32-bit compile completed.
- Existing 26 compiler tests, 10 disk-tool tests, 1145 runtime assertions,
  588 browser assertions and 58 personalization assertions passed.
- New 1049 motion/storage assertions under ASan/UBSan; includes 1025-point easing
  monotonicity sweep, endpoints, reversal, reduced motion, small save writes,
  unchanged-bitmap zero writes, remount/readback, Full-HD render and cursor tests.
- Host-rendered Full-HD settings image and deterministic Start motion GIF.
- NO GNOME Boxes boot, real ATA validation, wall-clock animation benchmark or
  physical hardware test. Ubuntu/Boxes host compatibility is not certified.

Build: node tools/build.js
Tests: node tests/run-tests.js

In Boxes, check the active resolution displayed in Settings. A fallback means
Full-HD was not selected; enabling host 3D alone does not add a driver to this OS.
For a persistent freeze, the domain XML / Boxes troubleshooting log is needed to
identify the actual virtual disk controller and display hardware.

This document supersedes prior UI/save-path status claims for this increment.
