# OceanOS 0.5.0 compatibility foundation — experimental increment

This is NOT an online-browsing or Windows-compatible release.
Built from the supplied 0.5.0 source. No Linux kernel was introduced.

## Implemented
- kernel/pe32.c and pe32.h: bounded inspection of i386 PE32 executable metadata.
- Rejects truncated headers, incompatible architecture, DLL images, invalid section extents,
  image-base overflow, oversized directory count and out-of-image directory ranges.
- Build compiles and links this module. No desktop launch command is added.
- tests/pe32-tests.c: synthetic positive and negative fixtures.

This inspector is preliminary, not a full PE validator or a security boundary.
It does not validate all alignment rules, section overlaps, imported names, relocation
entries, signatures, or instruction safety. It never executes or maps the input.
It is not yet connected to the OceanFS file browser.

## Verification actually performed
- New C tests compiled and ran with GCC AddressSanitizer and UndefinedBehaviorSanitizer.
- New module compiled as 32-bit freestanding C with warnings treated as errors.
- Full ISO build completed.
- Existing suite passed: 26 compiler tests, 10 disk-tool tests,
  1145 runtime assertions, 588 browser assertions.
- NO emulator boot, real hardware, live networking or Windows application testing.

Run the new tests on a host with GCC:
  gcc -std=c11 -Wall -Wextra -Werror -fsanitize=address,undefined -fno-pie -no-pie kernel/pe32.c tests/pe32-tests.c -o /tmp/ocean-pe-tests
  /tmp/ocean-pe-tests

## Required next work: browsing
1. Kernel exception handling, timeouts and safe buffer/allocator interfaces.
2. PCI discovery and a selected virtual NIC driver; choose QEMU e1000 as initial target.
3. Ethernet/ARP/IPv4, UDP, DHCP, DNS and TCP with packet and integration tests.
4. HTTP client with bounded parsing, redirects, chunking and download handling.
5. TLS with certificate verification, trust store, usable clock and secure entropy.
   Do not substitute disabled certificate checks for working HTTPS.
6. Connect network fetching to the existing limited HTML renderer. This is still NOT
   modern browser support: CSS, JavaScript, Unicode and other facilities remain.
7. Evaluate a browser port only after its runtime, graphics and process needs exist.

## Required next work: Windows applications
1. Isolated user-mode execution, address spaces, exceptions and system calls.
2. PE mapping, relocations, import resolution and process startup/exit.
3. A minimal Windows ABI with explicitly enumerated supported functions.
4. DLL loading, filesystem/path semantics, handles, threads and synchronization.
5. USER32/GDI services and a tested integration with the OceanOS desktop.
6. Select a named application and expand compatibility against repeatable tests.
7. Installers require their own dependencies: registry, process creation, services,
   COM/MSI and possibly runtimes. Supporting one setup.exe does not support all installers.

No claim of broad compatibility, Windows driver support, modern browser support,
or completion is made. Running arbitrary downloaded code in the current kernel
would be unsafe and is intentionally not implemented in this increment.
