# OceanOS 0.5.0 Current — Ocean Browser

New native local-document browser on the supplied OceanOS 0.4.0 source baseline.
The HTML tokenizer, entity decoder, flow layout, navigation, history, browser UI
and link hit testing are written in desktop/browser.Tide. kernel/browser.inc
provides bounded buffers, drawing/string primitives and OceanFS document loading.
Runtime/drivers remain C; boot remains assembly. There is no Linux kernel.

## Boot
Use your working SeaBIOS/i440FX/Bochs VGA VM configuration, x86_64 CPU and
128–256 MiB RAM. Replace only the CD ISO. Back up your disk image first.
Existing OceanFS 3 images are unchanged in format. Do not format to upgrade.
The browser opens automatically; F6 reopens it. F1–F5 retain prior apps.
Built-in pages work with no disk. Persistent local documents require a disk.

## Browser controls
- Ctrl+L, or click address bar: select address for replacement on next typing.
- Enter: load; Backspace: remove final character.
- Back/Forward/Reload/Home toolbar buttons.
- Up/Down keys: scroll by one line. Mouse wheel is not supported.
- Click blue underlined words to follow links.
- Title-bar maximize recalculates wrapping at the wider content width.
- Escape closes the app using existing desktop behavior.

Pages: ocean://welcome, ocean://guide, ocean://demo.
Files: file:///Web/index.html, or file:///Note1.TXT.
Any ASCII file extension can be loaded as HTML. Relative links resolve against
the current file's folder, including .. . Fragment identifiers are stripped;
there is no anchor scrolling or percent-decoding. Href entity decoding is not
implemented. Failed navigation retains the old page and reports an error.

To try a local page, write HTML in Notepad and save it. Check its exact filename
in Files, then use that name in a file:/// URL. Sample HTML files are in samples/;
they are not automatically copied onto your writable disk.

## HTML subset and limits
- Text, heading colors, paragraph/block separation, line breaks, list bullets.
- Anchor links, simple word wrapping, scrolling, named amp/lt/gt/quot/apos/nbsp
  and printable ASCII numeric entities.
- Script/style/head contents and comments are suppressed; nothing executes.
- 65535-byte ASCII non-NUL documents; 60 links/page; 500 visible clickable word
  regions; 16 history items; 255-character typed address; 511-byte href capture.
- Heading size remains the normal desktop font; inline emphasis is flattened.
- NO networking, HTTP, HTTPS, TLS, CSS engine, images, JavaScript, forms,
  downloads, Unicode, browser tabs, process sandbox or full HTML-standard parser.
- Long address text is visually cropped. Some CSS-only/complex documents will
  look wrong. This is a local HTML-subset browser, not a modern web browser.
- Parsing/layout runs on each repaint, bounded by document size; no performance
  guarantee for worst-case input. Trusted test documents only.

## Build and tests
Requires Node.js, GCC with 32-bit freestanding output, GNU as/ld/objcopy.
No npm packages or Python required to build the ISO.

    node tools/build.js
    node tests/run-tests.js

The browser sanitizer tests require a host GCC address/undefined sanitizer runtime
and -no-pie support. The existing runtime tests use a simulated sector store.
The build does not recreate or overwrite writable disk images.

## Verification boundaries
See build/verification.json and test logs. Host rendering is NOT an emulated boot.
No VM boot or ATA hardware validation was performed for this release.
Storage still has no journal or guaranteed power-loss recovery.
Original recovery documents/manifests under reference describe the 0.4.0 baseline,
not the modified 0.5.0 binaries. New ISO is deliberately not byte-identical.
