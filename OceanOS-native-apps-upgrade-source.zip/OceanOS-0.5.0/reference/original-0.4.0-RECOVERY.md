# 0.4.0 interrupted-generation recovery

Recovered from the user's OceanOS-0.4.0.iso: desktop main.Tide, JS compiler, runtime C/header, storage/apps includes, boot and kernel-entry assembly, linker script, original tiny README and stale storage guide. Native source files are unchanged.

Missing font.h was recovered from glyph-array addresses in the supplied kernel. Compiled source with matching-size temporary arrays to identify function boundaries; compared original glyph assembly and read the eight actual atlas addresses. Extracted exact coverage bytes, restored declaration order and rebuilt. Final font/header builds reproduce the ENTIRE original kernel byte-for-byte, not just approximate its appearance. Mapping recorded in assets/font-recovery-map.json. The earlier 0.2 source archive supplied ISO/build-tool scaffolding, font license and HTML reference. The original font-generation recipe was not recovered.

Reconstructed here: OceanFS 3 disk creation, OceanFS 1/2 migration, current docs, regression tests and verification tools. These are new helpers, not claimed to be lost originals. Build script never recreates mutable disks. Existing destinations are refused by disk tools.

Kernel, boot and ISO are byte-identical to uploaded input under this environment's GCC 15.2.0 and GNU binutils. See recovery-manifest.json. A different compiler may change output; strict verification intentionally flags that instead of silently claiming equality.

No firmware/VM boot or real ATA transfer was executed here. The disk model for tests gives exact 512-byte reads/writes with zero/repeated-pattern deduplication; it is not a performance benchmark or arbitrary torn-sector model. Full 1 GiB repeated-pattern readback was performed, not merely end-of-file sampling. Tests of 8 GiB refer to logical geometry in that model. The supplied 1 GiB disk was independently mounted read-only by kernel code on the host.

Preserved old embedded STORAGE.TXT is WRONG for 0.4 and remains only to preserve exact uploaded ISO identity. Use README.md and docs/storage-v3.md. Format support is now 8 MiB..8 GiB with distinct size/I/O messages, but compatibility with the user's VM still needs runtime verification.
