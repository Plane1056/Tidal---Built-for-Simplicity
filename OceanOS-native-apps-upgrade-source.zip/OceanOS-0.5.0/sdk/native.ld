ENTRY(_start)
PHDRS { code PT_LOAD FLAGS(5); data PT_LOAD FLAGS(6); }
SECTIONS {
 . = 0x40000000;
 .text : { *(.text.start) *(.text*) *(.rodata*) } :code
 . = 0x40002000;
 .data : { *(.data*) } :data
 .bss (NOLOAD) : { *(.bss*) *(COMMON) } :data
 /DISCARD/ : { *(.eh_frame*) *(.comment*) *(.note*) }
 ASSERT(SIZEOF(.text) <= 4096, "Native code page overflow")
 ASSERT(SIZEOF(.data) + SIZEOF(.bss) <= 4096, "Native data page overflow")
}
