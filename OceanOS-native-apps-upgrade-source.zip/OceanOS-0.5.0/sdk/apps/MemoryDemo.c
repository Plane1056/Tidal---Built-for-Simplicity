#include "ocean.h"
int main(void){unsigned char*p=alloc_o(128);if(!p)return 1;for(unsigned i=0;i<128;i++){if(p[i])return 2;p[i]=(unsigned char)i;}unsigned char*q=alloc_o(128);if(!q||q==p)return 3;for(unsigned i=0;i<128;i++)if(q[i])return 4;puts_o("Bounded user-data allocation passed.\n");return 0;}
