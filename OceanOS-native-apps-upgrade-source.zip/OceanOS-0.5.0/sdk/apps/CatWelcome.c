#include "ocean.h"
static char buffer[128];
int main(void){int f=open_o("/Welcome.TXT",O_READ);if(f<0){puts_o("Welcome.TXT not found.\n");return 2;}int n;while((n=read_o(f,buffer,sizeof buffer))>0)ocall(1,(unsigned)buffer,(unsigned)n,0);close_o(f);return n<0?3:0;}
