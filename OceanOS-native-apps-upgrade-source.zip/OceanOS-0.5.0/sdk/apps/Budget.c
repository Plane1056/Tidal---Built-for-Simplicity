#include "ocean.h"
int main(void){for(;;)pid_o();}
