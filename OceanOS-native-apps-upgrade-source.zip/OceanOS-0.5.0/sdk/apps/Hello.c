#include "ocean.h"
int main(void){puts_o("Hello from an OceanFS-loaded native ELF program.\n");return pid_o()>0?0:1;}
