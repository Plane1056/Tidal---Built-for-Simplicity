#include "ocean.h"
int main(void){int f=open_o("/Welcome.TXT",O_READ);if(f<0)return 2;return (int)*(volatile unsigned*)0x10000;}
