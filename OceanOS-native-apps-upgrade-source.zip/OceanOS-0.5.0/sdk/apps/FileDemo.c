#include "ocean.h"
static char buffer[128];
int main(void){const char*msg="Written by a ring-3 OceanOS application.\n";int f=open_o("UserDemo.TXT",O_READ|O_WRITE|O_CREATE|O_EXCL);if(f<0){puts_o("Create refused: UserDemo.TXT may already exist.\n");return 2;}int n=write_o(f,msg,olen(msg));if(n<0||seek_o(f,0,0)<0)return 3;int r=read_o(f,buffer,sizeof buffer);if(r!=n)return 4;for(int i=0;i<r;i++)if(buffer[i]!=msg[i])return 5;ocall(1,(unsigned)buffer,(unsigned)r,0);close_o(f);puts_o("File roundtrip passed.\n");return 0;}
