#include "ocean.h"
int main(void){volatile unsigned *p=(volatile unsigned*)0x10000;return (int)*p;}
