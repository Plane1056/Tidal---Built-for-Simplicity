#include "ocean.h"
int main(void){int x=ocall(1,0x10000,8,0);if(x!=-14)return 1;puts_o("Invalid pointer rejected; application continued.\n");return ocall(99,0,0,0)==-38?0:2;}
