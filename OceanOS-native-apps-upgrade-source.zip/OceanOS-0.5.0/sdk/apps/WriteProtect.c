#include "ocean.h"
int main(void){*(volatile unsigned*)0x40000000=0;return 1;}
