#include "ocean.h"
int main(void){__asm__ volatile("outb %%al,%%dx"::"a"(0),"d"(0x80));return 1;}
