# OceanOS native SDK ABI 1

Experimental, trusted, foreground programs only. NOT Linux, Windows, Wine or POSIX.
ELF32 ET_EXEC, machine i386, OSABI standalone 255, ABI version 1. Static linking;
code/rodata at 0x40000000 (4 KiB), data/BSS/heap at 0x40002000 (4 KiB), stack
at 0x40004000 (4 KiB). Guard holes separate mappings. One process at a time.

Entry receives an empty stack, NOT argc/argv/envp. sdk/start.c calls main and exits.
Do not use standard C library functions unless you supply an implementation.
Use sdk/build.js or node tools/build.js. GCC/as/ld with 32-bit freestanding output
are required. Every .c in sdk/apps becomes one standalone app, with the shared
start.c. This SDK does not provide Unix program compatibility.

## int 0x80 convention
EAX number/result; EBX, ECX, EDX arguments. Nonnegative result or negative error.
0 exit(status)
1 stdout(user_pointer, byte_count)
2 open(user_path_pointer, OH_* flags)
3 read(native_fd, user_destination, count)
4 write(native_fd, user_source, count)
5 close(native_fd)
6 seek(native_fd, signed_offset, whence 0/1/2)
7 pid()
8 size(native_fd)
9 brk(new_address), with 0 querying the current break
Unknown: -38. Returned descriptors are opaque generation-tagged integers, not
standard input/output/error. Stdout is syscall 1, not descriptor 1.

Path strings at most 255 bytes plus NUL; paths resolve relative to launching
Terminal directory or root for leading slash. No argv, quoting, environment,
symlinks, pipes, shared file descriptions or unlink-while-open.
Transfers <=4096 bytes and entirely in one approved user region. Read destinations
must be writable data or stack, not code. Unknown/invalid pointers return -14.
Output capture stores at most 1023 bytes; Terminal displays a shorter bounded
portion and reports truncation. Output is not a live terminal stream.
Native open flags: READ=1 WRITE=2 CREATE=4 TRUNC=8 APPEND=16 EXCL=32.
Errors use the negative errno-like values documented in HOST-SERVICES-STATUS.md;
they do not set errno or reproduce a POSIX ABI.

brk is bounded by the data-page remainder following all loaded data/BSS segments.
It clears grown/shrunk bytes. All data pages are already mapped; brk is an
allocation contract, not hardware-granular memory protection. alloc_o is a
16-byte-aligned bump allocator without individual free or realloc.

Limits and known safety issues are in NATIVE-UPGRADE-GUIDE.md. In particular,
there is no timer preemption: never run arbitrary downloaded or spinning code.
