#ifndef OCEAN_SDK_H
#define OCEAN_SDK_H
#define O_READ 1u
#define O_WRITE 2u
#define O_CREATE 4u
#define O_TRUNC 8u
#define O_APPEND 16u
#define O_EXCL 32u
static inline int ocall(unsigned n,unsigned a,unsigned b,unsigned c){int r;__asm__ volatile("int $0x80":"=a"(r):"a"(n),"b"(a),"c"(b),"d"(c):"memory","cc");return r;}
static inline unsigned olen(const char*s){unsigned n=0;while(s[n])n++;return n;}
static inline int puts_o(const char*s){return ocall(1,(unsigned)s,olen(s),0);}
static inline int open_o(const char*p,unsigned flags){return ocall(2,(unsigned)p,flags,0);}
static inline int read_o(int f,void*b,unsigned n){return ocall(3,(unsigned)f,(unsigned)b,n);}
static inline int write_o(int f,const void*b,unsigned n){return ocall(4,(unsigned)f,(unsigned)b,n);}
static inline int close_o(int f){return ocall(5,(unsigned)f,0,0);}
static inline int seek_o(int f,int off,unsigned whence){return ocall(6,(unsigned)f,(unsigned)off,whence);}
static inline int pid_o(void){return ocall(7,0,0,0);}
static inline int size_o(int f){return ocall(8,(unsigned)f,0,0);}
static inline void *alloc_o(unsigned n){int old=ocall(9,0,0,0);if(old<0||n>4096)return (void*)0;unsigned next=((unsigned)old+n+15)&~15u;int r=ocall(9,next,0,0);return r<0?(void*)0:(void*)(unsigned)old;}
__attribute__((noreturn)) static inline void exit_o(int code){ocall(0,(unsigned)code,0,0);for(;;)__asm__ volatile("ud2");}
#endif
