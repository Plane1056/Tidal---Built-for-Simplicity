#include "ocean.h"
extern int main(void);
__attribute__((section(".text.start"),noreturn)) void _start(void){exit_o(main());}
