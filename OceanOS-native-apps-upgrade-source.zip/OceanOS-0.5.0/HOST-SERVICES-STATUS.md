# OceanOS 0.5.0 — Native host services, increment 1

Source base: the user-attached motion-fullhd-preview-2 source. Existing desktop,
personalization, motion, Full-HD selection and dirty-bitmap optimization retained.

THIS IS NOT A WINE PORT. NO ISOLATED APPLICATION OR WINDOWS EXECUTABLE RUNS HERE.

## Implemented code
kernel/host_services.h and kernel/host_services.inc are included in runtime.c.

1. Bounded page arena:
- 8 MiB reserved in kernel BSS; 2048 aligned 4096-byte pages.
- Contiguous page runs, logical owner IDs, exhaustion and alignment checks.
- Allocation/free zeroing, wrong-owner/double/interior-free rejection.
- Explicit owner cleanup.
- This is not a physical RAM discovery service, virtual memory manager, mmap,
  page table manager, permissions boundary, allocator for untrusted processes,
  general C malloc/realloc or thread-safe concurrent allocator.

2. Kernel-side OceanFS descriptor adapter:
- 64 global descriptor slots with generation-tagged native integer handles.
- Logical owner checks, independent offsets, read/write, seek, size and close.
- Create/exclusive-create, truncate and append; bounded root/relative paths,
  '.', '..', repeated slash handling; no symlinks.
- Underlying storage/limit errors mapped to documented negative errno-like values.
- Entry deletion is refused while a new-style descriptor references the entry.
- Formatting is refused while these descriptors exist; mounting invalidates them.
- Uses real OceanFS functions, NOT an in-memory imitation of a filesystem.
- Does not change the OceanFS on-disk format.

3. Interactive integration:
- Terminal `hostinfo`: read-only resource counts and explicit missing capabilities.
- Terminal `hostdemo`: allocates a page, creates HostDemo.TXT in the current
  directory, writes, seeks, reads back, closes and frees. It refuses to overwrite
  an existing HostDemo.TXT. Saves follow the existing RAM/disk backend behavior.
  This command intentionally writes a demo file only when invoked.

## Native API, not POSIX
Include kernel/host_services.h. OH_* open flags are project-specific; do not pass
host O_* values. Return values are nonnegative result/native handle or negative
error. They do not set errno. Reserved descriptors 0/1/2 are not implemented.
Owner IDs are supplied by trusted callers; no user process identity is enforced.
Kernel pointers must be valid: only NULL checks exist, NOT safe user-pointer copy.

Current errors include -2 missing, -5 I/O, -9 bad descriptor/owner, -13 access or
allocation-owner mismatch, -14 NULL buffer, -16 busy, -17 exists, -20 not directory,
-21 directory, -22 invalid, -24 table full, -27 too large, -28 no space,
-36 name/path too long, -38 unsupported sparse write.

Known incompatibilities: no unlink-while-open, sparse writes, directory handles,
permissions/users, stat metadata, pipes, dup/shared descriptions, file locking,
async I/O, errno/libc ABI, fsync API, safe multithreaded append, per-process FD
namespaces, memory mapping, executable loader or syscalls. Descriptor generation
counters wrap eventually; they are stale-handle mitigation, not security tokens.
Existing filesystem writes remain synchronous and can still block the UI.

## Test evidence
- Full ISO and freestanding 32-bit kernel build passed.
- Existing 26 compiler tests, 10 disk-tool tests, 1145 runtime assertions,
  588 browser assertions, 58 personalization assertions and 1049 motion/storage
  assertions passed.
- New host-service suite passed 16501 assertions under ASan/UBSan. 16384 of these
  are bytewise zeroing checks. Other cases cover exhaustion, ownership, stale FDs,
  open flags, append, traversal, capacity without accidental creation, delete/
  format refusal, mount invalidation, file remount/readback and demo command.
- Host sector-backed tests do NOT validate hardware ATA behavior or user isolation.
- No emulator/Boxes boot, Windows application, Wine build or hardware test run.

## Remaining requested foundations
Application processes: not implemented.
Isolated virtual memory / mappings / shared memory: not implemented.
Threads and synchronization: not implemented.
POSIX host ABI / C library / dynamic linker: not implemented.
Filesystem host integration: partial native adapter only (above).
Wine graphics/input backend: not implemented; existing native UI retained.
Audio and network stack: not implemented.

## Next executable milestone
Before attempting Wine:
1. Establish boot memory information and reserved-region accounting.
2. Implement/verify IDT exception paths, paging, supervisor-only kernel mappings,
   per-process address spaces, GDT user segments and TSS kernel-stack transitions.
3. Establish a bounded syscall entry with validated copy-in/copy-out and translate
   these native services through it; never expose unchecked kernel pointers.
4. Load one controlled native test executable into a user address space and enter
   ring 3. Verify a deliberate invalid access kills the test process, not desktop.
5. Only then expand scheduling, threads, synchronization, ELF/dynamic linking,
   libc/Unix host interfaces and assess a named Wine source version's dependency
   checklist. Graphical integration and target applications follow that audit.

These are planned stages, not implemented features. The current desktop remains
single-kernel execution and should not run arbitrary downloaded executable bytes.

Build: node tools/build.js
Tests: node tests/run-tests.js
Use a disposable/backup VM disk; existing filesystem power-loss limits remain.
This status supersedes earlier claims only for the implemented native services.
