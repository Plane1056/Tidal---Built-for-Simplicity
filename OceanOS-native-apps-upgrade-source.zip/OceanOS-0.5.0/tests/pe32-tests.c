#include "../kernel/pe32.h"
static uint8_t b[1024];
static void w16(unsigned p,unsigned v){b[p]=v;b[p+1]=v>>8;}
static void w32(unsigned p,unsigned v){w16(p,v);w16(p+2,v>>16);}
int main(void){ocean_pe_info q;
 w16(0,0x5a4d);w32(60,128);w32(128,0x4550);w16(132,0x14c);w16(134,1);w16(148,224);w16(150,2);
 w16(152,0x10b);w32(168,4096);w32(180,0x400000);w32(208,8192);w32(212,512);w32(244,16);
 w32(384,16);w32(388,4096);w32(392,512);w32(396,512);
 if(ocean_pe32_inspect(b,sizeof b,&q)||q.entry_rva!=4096)return 1;
 for(unsigned i=0;i<512;i++)if(ocean_pe32_inspect(b,i,&q)==0)return 2;
 w16(132,0x8664);if(!ocean_pe32_inspect(b,sizeof b,&q))return 3;w16(132,0x14c);
 w32(396,0xfffffff0U);if(!ocean_pe32_inspect(b,sizeof b,&q))return 4;w32(396,512);
 w32(388,8190);if(!ocean_pe32_inspect(b,sizeof b,&q))return 5;w32(388,4096);
 w32(244,17);if(!ocean_pe32_inspect(b,sizeof b,&q))return 6;w32(244,16);
 w32(60,0xfffffff0U);if(!ocean_pe32_inspect(b,sizeof b,&q))return 7;
 return 0;}
