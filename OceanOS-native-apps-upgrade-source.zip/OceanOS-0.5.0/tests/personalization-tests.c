#include <stdio.h>
#include <stdlib.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
#include "../build/desktop.c"
static uint8_t disk[16*1024*1024];static unsigned checks;
int ocean_test_read(uint32_t lba,void*out){if(lba>=32768)return 0;memcpy(out,disk+lba*512,512);return 1;}
int ocean_test_write(uint32_t lba,const void*in){if(lba>=32768)return 0;memcpy(disk+lba*512,in,512);return 1;}
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL %d: %s\n",__LINE__,#x);return 1;}}while(0)
static void click(uint32_t x,uint32_t y){s[0]=x;s[1]=y;handle_click();}
int main(void){host_disk_sectors=0;storage_init();files_init();note_new();ui_init();s[12]=130;s[13]=50;
 CHECK(s[4]==0&&ui_get(0)==0&&ui_color(0)==0x182330);
 for(uint32_t i=0;i<6;i++){CHECK(ui_set(1,i)==0);CHECK(accent()==ui_accents[i]);}
 CHECK(ui_set(1,6)==1&&ui_get(1)==5);CHECK(ui_set(2,4)==1);CHECK(ui_set(3,2)==1);CHECK(ui_set(9,0)==1);
 s[4]=4;ui_settings_click(130+204+120,50+68+120,130,50);CHECK(ui_get(0)==1&&ui_color(0)==0xf7f9fc);
 for(uint32_t i=0;i<4;i++){ui_settings_click(130+204+20+i*116,50+68+220,130,50);CHECK(ui_get(2)==i);}
 for(uint32_t i=0;i<6;i++){ui_settings_click(130+204+20+i*45,50+68+340,130,50);CHECK(ui_get(1)==i);}
 ui_settings_click(130+204+120,50+68+440,130,50);CHECK(ui_get(3)==1&&task_x()==12);
 ui_settings_click(130+204+225,50+68+440,130,50);CHECK(ui_get(4)==0);
 CHECK(ui_save()!=0&&ui_saved==2);ui_defaults();s[4]=0;
 click(40,40);CHECK(s[4]==0&&ui_selection()==1);s[3]=0;ui_desktop_update();ui_test_clock+=200000;click(40,40);CHECK(s[4]==1);
 s[4]=0;ui_test_clock+=1000000;click(40,40);s[3]=1;s[0]=340;s[1]=240;ui_desktop_update();CHECK(ui_icon_x(1)==314&&ui_icon_y(1)==216);s[3]=0;ui_desktop_update();
 click(340,240);CHECK(s[4]==0);s[3]=0;ui_desktop_update();ui_test_clock+=100000;click(340,240);CHECK(s[4]==1);
 s[4]=0;s[20]=1;s[21]=400;s[22]=200;click(415,215);CHECK(s[4]==4&&s[20]==0);
 uint32_t modes[][2]={{1600,900},{1280,800},{800,600}};
 for(uint32_t i=0;i<3;i++){width=modes[i][0];height=modes[i][1];pitch=width*4;ui_set(0,i&1);ui_settings_draw(130,50,1020,620);ui_text(1270,790,(uintptr_t)"Edge test",ui_color(3));}
 width=1280;height=800;pitch=5120;
 for(uint32_t i=0;i<4;i++){CHECK(ui_set(2,i)==0);background();uint32_t col=pixels[100];background();CHECK(pixels[100]==col);if(i==3)CHECK(pixels[0]==0x0c2034&&pixels[width*height-1]==0x0c2034);}
 host_disk_sectors=32768;disk_sectors=32768;disk_state=2;CHECK(storage_format());files_init();
 ui_set(0,1);ui_set(1,3);ui_set(2,2);ui_set(3,1);ui_set(4,0);ui_x[0]=555;ui_y[0]=321;CHECK(ui_save()==0&&ui_saved==1);
 ui_defaults();CHECK(ui_get(0)==0);storage_init();CHECK(disk_state==1);ui_init();CHECK(ui_get(0)==1&&ui_get(1)==3&&ui_get(2)==2&&ui_get(3)==1&&ui_get(4)==0);CHECK(ui_x[0]==555&&ui_y[0]==321);
 uint32_t id=find_child(0,"OceanUI.CFG"),b[20];CHECK(fs_read_at(id,0,b,sizeof b)==sizeof b);b[3]=100;b[19]=ui_checksum(b);CHECK(!IS_ERR(fs_replace(id,b,sizeof b)));ui_init();CHECK(ui_get(1)==0&&ui_get(0)==0);
 b[3]=1;b[7]=999999;b[19]=ui_checksum(b);CHECK(!ui_decode(b));b[7]=10;b[19]^=1;CHECK(!ui_decode(b));
 host_fail_after=0;CHECK(ui_save()!=0&&ui_saved==3);host_fail_after=NONE;
 printf("%u personalization assertions passed.\n",checks);return 0;}
