#include <stdio.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
static FILE*disk;
int ocean_test_read(uint32_t lba,void*out){return fseek(disk,(long)lba*512,SEEK_SET)==0&&fread(out,1,512,disk)==512;}
int ocean_test_write(uint32_t lba,const void*in){(void)lba;(void)in;return 0;}
int main(int argc,char**argv){if(argc!=2)return 1;disk=fopen(argv[1],"rb");if(!disk)return 2;fseek(disk,0,SEEK_END);long size=ftell(disk);host_disk_sectors=(uint32_t)(size/512);storage_init();uint32_t id=find_child(0,"Welcome.TXT");char out[33];uint32_t got=ocean_read(id,0,out,32);out[32]=0;if(disk_state!=1||total_blocks!=262144||id==NONE||got!=32||disk_writes)return 3;printf("Final 1 GiB disk mounts read-only through recovered kernel code; %u free blocks; %s...\n",free_blocks(),out);fclose(disk);return 0;}
