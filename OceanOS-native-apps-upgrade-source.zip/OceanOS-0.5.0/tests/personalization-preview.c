#include <stdio.h>
#include <stdlib.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
#include "../build/desktop.c"
int ocean_test_read(uint32_t a,void*b){(void)a;(void)b;return 0;}
int ocean_test_write(uint32_t a,const void*b){(void)a;(void)b;return 0;}
int main(int argc,char**argv){width=1920;height=1080;pitch=7680;mx=1800;my=1000;storage_init();files_init();note_new();ui_init();s[12]=130;s[13]=50;s[4]=argc>1?(uint32_t)atoi(argv[1]):0;
 if(argc>2)ui_set(0,(uint32_t)atoi(argv[2]));if(argc>3)ui_set(2,(uint32_t)atoi(argv[3]));if(argc>4)ui_set(1,(uint32_t)atoi(argv[4]));if(argc>5)ui_set(3,(uint32_t)atoi(argv[5]));if(argc>6)s[5]=1;
 if(argc>7){s[5]=1;motion_set(1,(uint32_t)atoi(argv[7]));}draw_desktop();FILE*f=fopen("build/personalization-preview.ppm","wb");if(!f)return 1;fprintf(f,"P6\n%u %u\n255\n",width,height);uint8_t row[5760];for(uint32_t y=0;y<height;y++){for(uint32_t x=0;x<width;x++){uint32_t c=test_front[y*width+x];row[x*3]=c>>16;row[x*3+1]=c>>8;row[x*3+2]=c;}if(fwrite(row,3,width,f)!=width)return 2;}fclose(f);return 0;}
