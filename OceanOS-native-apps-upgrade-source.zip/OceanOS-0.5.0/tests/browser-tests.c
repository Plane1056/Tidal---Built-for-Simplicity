
#include <stdio.h>
#include <stdlib.h>
#define OCEANOS_HOST_TEST
#define OCEANOS_BROWSER_TEST
#include "../kernel/runtime.c"
#include "../build/desktop.c"
int ocean_test_read(uint32_t lba,void*out){(void)lba;(void)out;return 0;}
int ocean_test_write(uint32_t lba,const void*in){(void)lba;(void)in;return 0;}
static unsigned checks;
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL %d: %s\n",__LINE__,#x);return 1;}}while(0)
static int has(const char*h,const char*n){while(*h){const char*a=h,*b=n;while(*a&&*a==*b){a++;b++;}if(!*b)return 1;h++;}return 0;}
static void layout(uint32_t w,uint32_t h){browser_test_text[0]=0;browser_layout(250,250,w,h);}
int main(void){
 storage_init();files_init();note_new();browser_init();CHECK(bn(14)==1);CHECK(equal(browser_buf[7],"ocean://welcome"));
 layout(720,1000);CHECK(has(browser_test_text,"Ocean Browser"));CHECK(bn(10)==2);CHECK(bn(11)>0);
 uint32_t a=100;browser_click(bn(a)+1,bn(a+1)+1,238,148,780,492);CHECK(equal(browser_buf[7],"ocean://guide"));CHECK(bn(14)==2);
 browser_back();CHECK(equal(browser_buf[7],"ocean://welcome"));browser_forward();CHECK(equal(browser_buf[7],"ocean://guide"));
 bp(1,(uintptr_t)"ocean://demo");CHECK(browser_navigate(1));layout(720,1000);CHECK(has(browser_test_text,"Entities: & < > \" A."));
 uint32_t wide=bn(17);layout(180,1000);CHECK(bn(17)>wide);
 bv(1,0);layout(720,92);browser_key(259);CHECK(bn(1)==1);browser_key(258);CHECK(bn(1)==0);
 uint32_t dir=entry_make(0,"Web",T_DIR,"");CHECK(!IS_ERR(dir));uint32_t id=entry_make(dir,"index.html",T_FILE,"<h1>Hello Ocean</h1><p><a href='next.html'>Next page</a></p><script>BAD SCRIPT</script><style>BAD CSS</style><!-- BAD COMMENT -->");CHECK(!IS_ERR(id));
 uint32_t next=entry_make(dir,"next.html",T_FILE,"<p>Second document</p>");CHECK(!IS_ERR(next));
 bp(1,(uintptr_t)"file:///Web/index.html");CHECK(browser_navigate(1));layout(720,1000);CHECK(has(browser_test_text,"Hello Ocean"));CHECK(!has(browser_test_text,"BAD"));CHECK(bn(10)==1);
 bcopy(1,9);CHECK(browser_navigate(1));CHECK(equal(browser_buf[7],"file:///Web/next.html"));
 bp(1,(uintptr_t)"../Web/index.html");CHECK(browser_navigate(1));CHECK(equal(browser_buf[7],"file:///Web/index.html"));
 bp(1,(uintptr_t)"file:///missing.html");CHECK(!browser_navigate(1));CHECK(has(browser_doc,"Hello Ocean"));
 bp(1,(uintptr_t)"https://example.com");CHECK(!browser_navigate(1));CHECK(has(browser_buf[5],"Unsupported scheme"));
 bp(1,(uintptr_t)"ocean://welcome");CHECK(browser_navigate(1));browser_key(261);browser_key('o');CHECK(equal(browser_buf[1],"o"));browser_key(8);CHECK(!browser_buf[1][0]);
 for(uint32_t k=0;k<20;k++){bp(1,(uintptr_t)(k%2?"ocean://demo":"ocean://guide"));CHECK(browser_navigate(1));}CHECK(bn(14)==16);CHECK(bn(15)==15);
 browser_back();bp(1,(uintptr_t)"ocean://welcome");CHECK(browser_navigate(1));CHECK(bn(15)+1==bn(14));
 /* Malformed tags and long tokens must terminate with bounded state. */
 const char *bad[]={"<a href=\"unterminated", "<>","< =x>","<!-- unterminated", "<script>if(a<b) evil</script><p>Safe</p>","<p>&#999999999999; &bogus; &#x41;</p>"};
 for(uint32_t k=0;k<6;k++){strcopy(browser_doc,bad[k],sizeof browser_doc);layout(90,1000);CHECK(bn(11)<=500);}
 for(uint32_t i=0;i<65535;i++)browser_doc[i]='X';browser_doc[65535]=0;bv(1,0);layout(720,92);CHECK(bn(17)>800);CHECK(bn(11)<=500);
 uint32_t big=entry_make(0,"big.html",T_FILE,"");CHECK(!IS_ERR(big));CHECK(!IS_ERR(ocean_truncate(big,65536)));bp(1,(uintptr_t)"file:///big.html");CHECK(!browser_navigate(1));
 /* Deterministic malformed-input smoke fuzzing. */
 uint32_t rng=12345;const char alphabet[]="<>/='\" abcdef&;0123!-\n";
 for(uint32_t k=0;k<500;k++){for(uint32_t j=0;j<512;j++){rng=rng*1664525u+1013904223u;browser_doc[j]=alphabet[rng%(sizeof alphabet-1)];}browser_doc[512]=0;bv(1,0);layout(270,92);CHECK(bn(11)<=500);}
 const uint32_t modes[][2]={{1600,900},{1440,900},{1280,800},{1280,720},{1280,1024},{1024,768},{800,600}};
 bp(1,(uintptr_t)"ocean://demo");browser_navigate(1);
 for(uint32_t i=0;i<7;i++){width=modes[i][0];height=modes[i][1];pitch=width*4;wallpaper_ready=display_ready=0;mx=20;my=20;s[12]=210;s[13]=70;s[4]=6;draw_desktop();CHECK(display_ready);CHECK(bn(11)>0);s[17]=1;draw_desktop();CHECK(bn(5)>90);s[17]=0;}
 printf("%u browser assertions passed.\n",checks);return 0;
}
