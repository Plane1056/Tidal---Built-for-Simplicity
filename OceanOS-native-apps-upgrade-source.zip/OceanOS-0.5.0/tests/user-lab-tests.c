#include <stdio.h>
#include <stdlib.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
static uint32_t checks,*refs,pool_used;
static uint8_t *pool,common[512];
#define POOL_SECTORS 65536u
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
// Exact sector semantics with deduplication of zero/repeated payloads, not real ATA.
int ocean_test_read(uint32_t lba,void*out){if(lba>=host_disk_sectors)return 0;uint32_t r=refs[lba];if(!r)memset(out,0,512);else if(r==1)memcpy(out,common,512);else memcpy(out,pool+(r-2)*512,512);return 1;}
int ocean_test_write(uint32_t lba,const void*in){if(lba>=host_disk_sectors)return 0;if(memcmp_eq(in,common,512)){refs[lba]=1;return 1;}const uint8_t*p=in;uint32_t nonzero=0;for(uint32_t i=0;i<512;i++)nonzero|=p[i];if(!nonzero){refs[lba]=0;return 1;}uint32_t r=refs[lba];if(r<2){if(pool_used>=POOL_SECTORS)return 0;r=pool_used+++2;refs[lba]=r;}memcpy(pool+(r-2)*512,in,512);return 1;}
static int fresh(uint32_t mib){free(refs);host_disk_sectors=mib*2048u;refs=calloc(host_disk_sectors,4);if(!refs)return 0;pool_used=0;host_fail_after=NONE;disk_state=2;disk_sectors=host_disk_sectors;return storage_format();}
static int has(const char*h,const char*n){while(*h){const char*a=h,*b=n;while(*a&&*a==*b){a++;b++;}if(!*b)return 1;h++;}return 0;}
static void cmd(const char*p){clen=0;command[0]=0;while(*p)terminal_key((uint8_t)*p++);terminal_key(10);}
static int gfx(uint32_t W,uint32_t H){width=W;height=H;pitch=W*4;display_ready=0;cursor_valid=0;wallpaper_ready=0;mx=400;my=300;phase=mb=0;mouse(8);mouse(10);mouse(5);CHECK(mx==410&&my==295);CHECK(s[0]==mx*1280/W&&s[1]==my*800/H);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x123456+i;cursor();present();mx=W-1;my=H-1;cursor_update();CHECK(test_front[300*W+400]==0x123456+300*W+400);uint32_t ok=1;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=test_front[i])ok=0;CHECK(ok);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x102030;round_rect(20,20,100,80,12,0xffffff);uint32_t aa=0;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=0x102030&&pixels[i]!=0xffffff)aa++;CHECK(aa>0);return 0;}
int main(void){
 CHECK(ul_range(UL_CODE,4096));CHECK(ul_range(UL_STACK,4096));CHECK(ul_range(UL_CODE+4096,0));
 CHECK(!ul_range(0,1)&&!ul_range(0x10000,8));CHECK(!ul_range(UL_CODE+4095,2));CHECK(!ul_range(UL_STACK+4095,2));CHECK(!ul_range(UL_CODE+4096,1));CHECK(!ul_range(UL_CODE+8192,1));CHECK(!ul_range(0xfffffff0,64));CHECK(!ul_range(UL_CODE,0xffffffff));
 ul_map_build();CHECK((ul_directory[0]&0x87)==0x83);CHECK((ul_directory[UL_CODE>>22]&0x87)==7);CHECK((ul_table[0]&7)==5);CHECK((ul_table[4]&7)==7);CHECK(ul_table[1]==0&&ul_table[2]==0&&ul_table[3]==0&&ul_table[5]==0);
 for(uint32_t i=0;i<1024;i++)if(i!=(UL_CODE>>22))CHECK(!(ul_directory[i]&4));
 for(uint32_t i=0;i<1024;i++)if(i!=0&&i!=4)CHECK(ul_table[i]==0);
 memcpy(ul_code,"fixture",7);memcpy(ul_stack,"stack",5);CHECK(ul_copy(UL_CODE,7)==-14);ul_running=1;CHECK(ul_copy(UL_CODE,7)==7&&memcmp_eq(ul_log,"fixture",7));CHECK(ul_copy(UL_STACK,5)==5&&memcmp_eq(ul_log,"stack",5));CHECK(ul_copy(UL_CODE,129)==-14&&ul_copy(0x10000,1)==-14);ul_running=0;
 CHECK(ul_selftest()==-38);cmd("usertest");CHECK(has(answer,"EXPERIMENTAL")&&has(answer,"usertest run"));cmd("usertest run");CHECK(has(answer,"did not pass"));
 printf("%u user-lab structural assertions passed. NO CPU privilege transitions executed.\n",checks);return 0;}
