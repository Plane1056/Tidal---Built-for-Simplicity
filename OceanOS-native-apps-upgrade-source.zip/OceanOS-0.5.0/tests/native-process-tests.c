#include <stdio.h>
#include <stdlib.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
static uint32_t checks,*refs,pool_used;
static uint8_t *pool,common[512];
#define POOL_SECTORS 65536u
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
// Exact sector semantics with deduplication of zero/repeated payloads, not real ATA.
int ocean_test_read(uint32_t lba,void*out){if(lba>=host_disk_sectors)return 0;uint32_t r=refs[lba];if(!r)memset(out,0,512);else if(r==1)memcpy(out,common,512);else memcpy(out,pool+(r-2)*512,512);return 1;}
int ocean_test_write(uint32_t lba,const void*in){if(lba>=host_disk_sectors)return 0;if(memcmp_eq(in,common,512)){refs[lba]=1;return 1;}const uint8_t*p=in;uint32_t nonzero=0;for(uint32_t i=0;i<512;i++)nonzero|=p[i];if(!nonzero){refs[lba]=0;return 1;}uint32_t r=refs[lba];if(r<2){if(pool_used>=POOL_SECTORS)return 0;r=pool_used+++2;refs[lba]=r;}memcpy(pool+(r-2)*512,in,512);return 1;}
static int fresh(uint32_t mib){free(refs);host_disk_sectors=mib*2048u;refs=calloc(host_disk_sectors,4);if(!refs)return 0;pool_used=0;host_fail_after=NONE;disk_state=2;disk_sectors=host_disk_sectors;return storage_format();}
static int has(const char*h,const char*n){while(*h){const char*a=h,*b=n;while(*a&&*a==*b){a++;b++;}if(!*b)return 1;h++;}return 0;}
static void cmd(const char*p){clen=0;command[0]=0;while(*p)terminal_key((uint8_t)*p++);terminal_key(10);}
static int gfx(uint32_t W,uint32_t H){width=W;height=H;pitch=W*4;display_ready=0;cursor_valid=0;wallpaper_ready=0;mx=400;my=300;phase=mb=0;mouse(8);mouse(10);mouse(5);CHECK(mx==410&&my==295);CHECK(s[0]==mx*1280/W&&s[1]==my*800/H);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x123456+i;cursor();present();mx=W-1;my=H-1;cursor_update();CHECK(test_front[300*W+400]==0x123456+300*W+400);uint32_t ok=1;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=test_front[i])ok=0;CHECK(ok);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x102030;round_rect(20,20,100,80,12,0xffffff);uint32_t aa=0;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=0x102030&&pixels[i]!=0xffffff)aa++;CHECK(aa>0);return 0;}
static void patch32(uint8_t*b,uint32_t at,uint32_t value){for(uint32_t i=0;i<4;i++)b[at+i]=(uint8_t)(value>>(i*8));}
int main(void){pool=malloc(POOL_SECTORS*512);CHECK(pool!=0);CHECK(fresh(64));files_init();note_new();
 ne_image image;uint8_t bad[2048];uint32_t hello=0,files=0;for(uint32_t i=0;i<sizeof native_bundle/sizeof native_bundle[0];i++){CHECK(ne_validate(native_bundle[i].bytes,native_bundle[i].size,&image)==0);CHECK(image.entry>=NE_CODE&&image.entry<NE_CODE+4096);if(equal(native_bundle[i].name,"Hello.ELF"))hello=i;if(equal(native_bundle[i].name,"FileDemo.ELF"))files=i;}
 const uint8_t*h=native_bundle[hello].bytes;uint32_t n=native_bundle[hello].size;CHECK(n<sizeof bad);for(uint32_t i=0;i<52;i++)CHECK(ne_validate(h,i,&image)==-8);
 uint32_t mutations[]={0,4,5,6,7,8,16,18,20,40,42};for(uint32_t i=0;i<sizeof mutations/sizeof mutations[0];i++){memcpy(bad,h,n);bad[mutations[i]]^=0x7f;CHECK(ne_validate(bad,n,&image)==-8);}
 memcpy(bad,h,n);patch32(bad,28,0xfffffff0);CHECK(ne_validate(bad,n,&image)==-8);memcpy(bad,h,n);patch32(bad,28,0);CHECK(ne_validate(bad,n,&image)==-8);
 memcpy(bad,h,n);patch32(bad,52+20,8192);CHECK(ne_validate(bad,n,&image)==-8);memcpy(bad,h,n);patch32(bad,52+24,7);CHECK(ne_validate(bad,n,&image)==-8);memcpy(bad,h,n);patch32(bad,52+8,0x10000);CHECK(ne_validate(bad,n,&image)==-8);memcpy(bad,h,n);patch32(bad,24,NE_DATA);CHECK(ne_validate(bad,n,&image)==-8);
 uint32_t rng=123;for(uint32_t i=0;i<512;i++){memcpy(bad,h,n);rng=rng*1664525+1013904223;uint32_t at=rng%n;bad[at]^=(uint8_t)((rng>>24)|1);int r=ne_validate(bad,n,&image);CHECK(r==0||r==-8);}
 memset(ul_code,0xa5,4096);memset(ul_data,0xa5,4096);memset(ul_stack,0xa5,4096);CHECK(np_prepare(native_bundle[files].bytes,native_bundle[files].size,&image)==0);CHECK(ul_data_enabled&&ul_data[4095]==0&&ul_stack[4095]==0);ul_map_build();CHECK((ul_table[2]&7)==7);CHECK(np_user_range(NE_DATA,4096,1)&&!np_user_range(NE_CODE,1,1));
 uint32_t installed,skipped;CHECK(np_install(&installed,&skipped)==0&&installed==sizeof native_bundle/sizeof native_bundle[0]&&skipped==0);CHECK(np_install(&installed,&skipped)==0&&installed==0&&skipped==sizeof native_bundle/sizeof native_bundle[0]);CHECK(oh_fd_available()==64);CHECK(np_file_image(0,"/Apps/Hello.ELF",&image,0)==0&&np_last_image_size==n);
 memset(np_records,0,sizeof np_records);np_active=&np_records[0];np_active->pid=2048;np_active->state=NP_RUNNING;np_active->parent=0;ul_running=1;ul_data_enabled=1;
 memcpy(ul_data,"NativeTest.TXT",15);int fd=np_syscall(2,NE_DATA,OH_READ|OH_WRITE|OH_CREATE|OH_EXCL,0);CHECK(fd>=3);memcpy(ul_data+128,"hello",5);CHECK(np_syscall(4,(uint32_t)fd,NE_DATA+128,5)==5);CHECK(np_syscall(6,(uint32_t)fd,0,0)==0);
 CHECK(np_syscall(3,(uint32_t)fd,NE_CODE,5)==-14);CHECK(np_syscall(3,(uint32_t)fd,NE_DATA+256,5)==5&&memcmp_eq(ul_data+256,"hello",5));CHECK(np_syscall(8,(uint32_t)fd,0,0)==5);CHECK(np_syscall(7,0,0,0)==2048);CHECK(np_syscall(99,0,0,0)==-38);
 CHECK(np_syscall(1,0x10000,8,0)==-14&&np_syscall(4,(uint32_t)fd,NE_DATA,4097)==-22);CHECK(np_syscall(2,0xfffffff0,OH_READ,0)==-14);memset(ul_data+3800,'x',296);CHECK(np_syscall(2,NE_DATA+3800,OH_READ,0)==-36);
 CHECK(np_syscall(5,(uint32_t)fd,0,0)==0&&np_syscall(5,(uint32_t)fd,0,0)==-9);memcpy(ul_code,"message",7);np_output_used=0;CHECK(np_syscall(1,NE_CODE,7,0)==7&&memcmp_eq(np_output,"message",7));memset(ul_data,'x',4096);CHECK(np_syscall(1,NE_DATA,4096,0)==4096&&np_output_truncated);
 CHECK(np_syscall(9,0,0,0)>=(int)NE_DATA);uint32_t old_break=np_break_current;CHECK(np_syscall(9,old_break+64,0,0)==(int)(old_break+64));memset(ul_data+(old_break-NE_DATA),0xa5,64);CHECK(np_syscall(9,old_break,0,0)==(int)old_break);CHECK(ul_data[old_break-NE_DATA]==0);CHECK(np_syscall(9,NE_DATA+4097,0,0)==-12);
 np_calls=1024;CHECK(np_syscall(7,0,0,0)==-11&&np_limit_reached());np_stop=0;np_calls=0;np_stdout_bytes=65536;CHECK(np_syscall(1,NE_CODE,1,0)==-27&&np_limit_reached());np_stop=0;
 np_active=0;ul_running=0;oh_owner_release(2048);CHECK(oh_fd_available()==64);CHECK(np_run(0,"/Apps/Hello.ELF")==-38);CHECK(np_records[(np_record_count-1)%NP_HISTORY].state==NP_FAILED&&np_active==0&&oh_fd_available()==64);
 cmd("appcheck /Apps/Hello.ELF");CHECK(has(answer,"validated")&&has(answer,"Not executed"));cmd("run /Apps/Hello.ELF");CHECK(has(answer,"launch failed"));cmd("procs");CHECK(has(answer,"failed"));cmd("proctest run");CHECK(has(answer,"did NOT pass"));
 storage_init();CHECK(np_file_image(0,"/Apps/Hello.ELF",&image,0)==0);printf("%u native loader/syscall assertions passed. No ring-3 execution performed.\n",checks);free(refs);free(pool);return 0;}
