// Actual renderer on host framebuffer; NOT an emulated boot.
#include <stdio.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
#include "../build/desktop.c"
int ocean_test_read(uint32_t lba,void*out){(void)lba;(void)out;return 0;}
int ocean_test_write(uint32_t lba,const void*in){(void)lba;(void)in;return 0;}
int main(void){width=1600;height=900;pitch=6400;mx=1480;my=820;storage_init();files_init();note_new();s[12]=210;s[13]=70;s[4]=0;ui_init();browser_init();bp(1,(uintptr_t)"ocean://demo");browser_navigate(1);draw_desktop();FILE*f=fopen("build/preview.ppm","wb");if(!f)return 1;fprintf(f,"P6\n%u %u\n255\n",width,height);uint8_t row[1600*3];for(uint32_t y=0;y<height;y++){for(uint32_t x=0;x<width;x++){uint32_t c=test_front[y*width+x];row[x*3]=c>>16;row[x*3+1]=c>>8;row[x*3+2]=c;}if(fwrite(row,3,width,f)!=width)return 2;}fclose(f);return 0;}
