#include <stdio.h>
#include <stdlib.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
static uint32_t checks,*refs,pool_used;
static uint8_t *pool,common[512];
#define POOL_SECTORS 65536u
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
// Exact sector semantics with deduplication of zero/repeated payloads, not real ATA.
int ocean_test_read(uint32_t lba,void*out){if(lba>=host_disk_sectors)return 0;uint32_t r=refs[lba];if(!r)memset(out,0,512);else if(r==1)memcpy(out,common,512);else memcpy(out,pool+(r-2)*512,512);return 1;}
int ocean_test_write(uint32_t lba,const void*in){if(lba>=host_disk_sectors)return 0;if(memcmp_eq(in,common,512)){refs[lba]=1;return 1;}const uint8_t*p=in;uint32_t nonzero=0;for(uint32_t i=0;i<512;i++)nonzero|=p[i];if(!nonzero){refs[lba]=0;return 1;}uint32_t r=refs[lba];if(r<2){if(pool_used>=POOL_SECTORS)return 0;r=pool_used+++2;refs[lba]=r;}memcpy(pool+(r-2)*512,in,512);return 1;}
static int fresh(uint32_t mib){free(refs);host_disk_sectors=mib*2048u;refs=calloc(host_disk_sectors,4);if(!refs)return 0;pool_used=0;host_fail_after=NONE;disk_state=2;disk_sectors=host_disk_sectors;return storage_format();}
static int has(const char*h,const char*n){while(*h){const char*a=h,*b=n;while(*a&&*a==*b){a++;b++;}if(!*b)return 1;h++;}return 0;}
static void cmd(const char*p){clen=0;command[0]=0;while(*p)terminal_key((uint8_t)*p++);terminal_key(10);}
static int gfx(uint32_t W,uint32_t H){width=W;height=H;pitch=W*4;display_ready=0;cursor_valid=0;wallpaper_ready=0;mx=400;my=300;phase=mb=0;mouse(8);mouse(10);mouse(5);CHECK(mx==410&&my==295);CHECK(s[0]==mx*1280/W&&s[1]==my*800/H);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x123456+i;cursor();present();mx=W-1;my=H-1;cursor_update();CHECK(test_front[300*W+400]==0x123456+300*W+400);uint32_t ok=1;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=test_front[i])ok=0;CHECK(ok);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x102030;round_rect(20,20,100,80,12,0xffffff);uint32_t aa=0;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=0x102030&&pixels[i]!=0xffffff)aa++;CHECK(aa>0);return 0;}
int main(void){pool=malloc(POOL_SECTORS*512);CHECK(pool!=0);CHECK(fresh(64));files_init();note_new();ui_init();
 uint32_t id=entry_make(0,"latency.txt",T_FILE,"");CHECK(!IS_ERR(id));uint32_t before=disk_writes;CHECK(!IS_ERR(fs_replace(id,"first",5)));uint32_t first=disk_writes-before;CHECK(first<=40);
 before=disk_writes;CHECK(!IS_ERR(fs_replace(id,"second",6)));uint32_t second=disk_writes-before;CHECK(second<=48);storage_init();uint8_t b[12];CHECK(fs_read_at(id,0,b,6)==6&&memcmp_eq(b,"second",6));
 before=disk_writes;CHECK(bitmap_write()&&disk_writes==before);
 uint32_t last=0;for(uint32_t t=0;t<=1024;t++){uint32_t v=motion_ease(t);CHECK(v>=last&&v<=1024);last=v;}CHECK(motion_ease(0)==0&&motion_ease(512)==512&&motion_ease(1024)==1024);
 CHECK(motion_set(32,0)==1&&motion_to(0,2000,100)==1);motion_set(0,0);CHECK(motion_to(0,1024,160)==0);for(uint32_t i=0;i<10;i++)motion_step(16);CHECK(motion_value(0)==1024);
 motion_to(0,0,160);motion_step(32);uint32_t midway=motion_value(0);CHECK(midway>0&&midway<1024);motion_to(0,1024,160);for(uint32_t i=0;i<10;i++)motion_step(16);CHECK(motion_value(0)==1024);
 motion_to(0,0,160);motion_reduce(1);CHECK(motion_value(0)==0);motion_to(0,1024,160);CHECK(motion_value(0)==1024);motion_reduce(0);
 width=1920;height=1080;pitch=7680;ui_set(0,1);background();ui_settings_draw(130,50,1020,620);ui_text(1279,799,(uintptr_t)"Bounds",ui_color(3));CHECK(pixels[0]!=0);
 CHECK(gfx(1920,1080)==0);printf("%u motion/storage assertions passed; tiny saves wrote %u and %u sectors.\n",checks,first,second);free(refs);free(pool);return 0;}
