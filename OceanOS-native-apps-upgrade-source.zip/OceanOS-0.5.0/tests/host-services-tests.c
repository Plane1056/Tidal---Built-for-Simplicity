#include <stdio.h>
#include <stdlib.h>
#define OCEANOS_HOST_TEST
#include "../kernel/runtime.c"
static uint32_t checks,*refs,pool_used;
static uint8_t *pool,common[512];
#define POOL_SECTORS 65536u
#define CHECK(x) do{checks++;if(!(x)){printf("FAIL line %d: %s\n",__LINE__,#x);return 1;}}while(0)
// Exact sector semantics with deduplication of zero/repeated payloads, not real ATA.
int ocean_test_read(uint32_t lba,void*out){if(lba>=host_disk_sectors)return 0;uint32_t r=refs[lba];if(!r)memset(out,0,512);else if(r==1)memcpy(out,common,512);else memcpy(out,pool+(r-2)*512,512);return 1;}
int ocean_test_write(uint32_t lba,const void*in){if(lba>=host_disk_sectors)return 0;if(memcmp_eq(in,common,512)){refs[lba]=1;return 1;}const uint8_t*p=in;uint32_t nonzero=0;for(uint32_t i=0;i<512;i++)nonzero|=p[i];if(!nonzero){refs[lba]=0;return 1;}uint32_t r=refs[lba];if(r<2){if(pool_used>=POOL_SECTORS)return 0;r=pool_used+++2;refs[lba]=r;}memcpy(pool+(r-2)*512,in,512);return 1;}
static int fresh(uint32_t mib){free(refs);host_disk_sectors=mib*2048u;refs=calloc(host_disk_sectors,4);if(!refs)return 0;pool_used=0;host_fail_after=NONE;disk_state=2;disk_sectors=host_disk_sectors;return storage_format();}
static int has(const char*h,const char*n){while(*h){const char*a=h,*b=n;while(*a&&*a==*b){a++;b++;}if(!*b)return 1;h++;}return 0;}
static void cmd(const char*p){clen=0;command[0]=0;while(*p)terminal_key((uint8_t)*p++);terminal_key(10);}
static int gfx(uint32_t W,uint32_t H){width=W;height=H;pitch=W*4;display_ready=0;cursor_valid=0;wallpaper_ready=0;mx=400;my=300;phase=mb=0;mouse(8);mouse(10);mouse(5);CHECK(mx==410&&my==295);CHECK(s[0]==mx*1280/W&&s[1]==my*800/H);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x123456+i;cursor();present();mx=W-1;my=H-1;cursor_update();CHECK(test_front[300*W+400]==0x123456+300*W+400);uint32_t ok=1;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=test_front[i])ok=0;CHECK(ok);for(uint32_t i=0;i<W*H;i++)pixels[i]=0x102030;round_rect(20,20,100,80,12,0xffffff);uint32_t aa=0;for(uint32_t i=0;i<W*H;i++)if(pixels[i]!=0x102030&&pixels[i]!=0xffffff)aa++;CHECK(aa>0);return 0;}
int main(void){pool=malloc(POOL_SECTORS*512);CHECK(pool!=0);CHECK(fresh(64));files_init();note_new();
 CHECK(oh_pages_available()==2048);CHECK(!oh_pages_alloc(0,1)&&!oh_pages_alloc(1,0)&&!oh_pages_alloc(1,2049));
 uintptr_t a=oh_pages_alloc(10,2),b=oh_pages_alloc(20,1);CHECK(a&&b&&a%4096==0&&b%4096==0&&a!=b);uint8_t*bytes=(uint8_t*)a;
 for(uint32_t i=0;i<8192;i++)CHECK(bytes[i]==0);memset(bytes,0xa5,8192);CHECK(oh_pages_free(20,a)==-13);CHECK(oh_pages_free(10,a+1)==-22&&oh_pages_free(10,a+4096)==-22);
 CHECK(oh_pages_free(10,a)==0&&oh_pages_free(10,a)==-22);a=oh_pages_alloc(10,2);for(uint32_t i=0;i<8192;i++)CHECK(((uint8_t*)a)[i]==0);
 CHECK(oh_owner_release(10)==1&&oh_owner_release(20)==1&&oh_pages_available()==2048);a=oh_pages_alloc(1,2048);CHECK(a&&!oh_pages_alloc(2,1));CHECK(oh_pages_free(1,a)==0);
 int fd=oh_open(10,0,"/service.txt",OH_READ|OH_WRITE|OH_CREATE|OH_EXCL);CHECK(fd>=3);CHECK(oh_open(10,0,"service.txt",OH_READ|OH_CREATE|OH_EXCL)==-17);CHECK(oh_read(11,fd,bytes,1)==-9);
 CHECK(oh_write(10,fd,"alpha",5)==5&&oh_size(10,fd)==5);CHECK(oh_seek(10,fd,0,0)==0);char out[32]={0};CHECK(oh_read(10,fd,out,32)==5&&memcmp_eq(out,"alpha",5));CHECK(oh_read(10,fd,out,1)==0);
 CHECK(oh_seek(10,fd,-2,2)==3&&oh_read(10,fd,out,2)==2&&memcmp_eq(out,"ha",2));CHECK(oh_seek(10,fd,-1,0)==-22);CHECK(oh_seek(10,fd,1,9)==-22);CHECK(oh_write(10,fd,0,1)==-14);
 uint32_t id=find_child(0,"service.txt");CHECK(entry_delete(id)==E_BUSY);CHECK(!storage_format());CHECK(oh_close(10,fd)==0&&oh_close(10,fd)==-9);
 int next=oh_open(10,0,"service.txt",OH_READ);CHECK(next>=3&&next!=fd&&oh_read(10,fd,out,1)==-9);CHECK(oh_write(10,next,"X",1)==-13);CHECK(oh_close(10,next)==0);
 int app=oh_open(10,0,"service.txt",OH_WRITE|OH_APPEND);CHECK(app>=3&&oh_seek(10,app,0,0)==0&&oh_write(10,app,"!",1)==1&&oh_size(10,app)==6);CHECK(oh_close(10,app)==0);
 uint32_t dir=entry_make(0,"ServiceDir",T_DIR,0);CHECK(!IS_ERR(dir));fd=oh_open(10,0,"//ServiceDir/../ServiceDir/./child",OH_READ|OH_WRITE|OH_CREATE);CHECK(fd>=3);CHECK(oh_close(10,fd)==0);
 CHECK(oh_open(10,dir,"../../service.txt",OH_READ)>=3);oh_owner_release(10);
 CHECK(oh_open(10,0,"ServiceDir",OH_READ)==-21&&oh_open(10,0,"service.txt/",OH_READ)==-20);CHECK(oh_open(10,0,"missing/file",OH_READ)==-2);CHECK(oh_open(10,0,"/",OH_READ)==-21);
 CHECK(oh_open(0,0,"service.txt",OH_READ)==-22&&oh_open(10,0,"service.txt",OH_READ|OH_TRUNC)==-22);
 char longname[140];memset(longname,'a',139);longname[139]=0;CHECK(oh_open(10,0,longname,OH_READ)==-36);
 int fds[64];for(uint32_t i=0;i<64;i++){fds[i]=oh_open(10,0,"service.txt",OH_READ);CHECK(fds[i]>=3);}CHECK(oh_fd_available()==0&&oh_open(10,0,"must-not-create",OH_READ|OH_CREATE)==-24&&find_child(0,"must-not-create")==NONE);CHECK(oh_owner_release(10)==64&&oh_fd_available()==64);
 fd=oh_open(10,0,"service.txt",OH_READ|OH_WRITE);CHECK(fd>=3);CHECK(oh_seek(10,fd,100,0)==100&&oh_write(10,fd,"x",1)==-38);storage_init();CHECK(oh_read(10,fd,out,1)==-9);fd=oh_open(10,0,"service.txt",OH_READ);CHECK(fd>=3&&oh_read(10,fd,out,32)==6&&memcmp_eq(out,"alpha!",6));CHECK(oh_close(10,fd)==0);
 fd=oh_open(10,0,"service.txt",OH_WRITE|OH_TRUNC);CHECK(fd>=3&&oh_size(10,fd)==0);CHECK(oh_close(10,fd)==0);CHECK(entry_delete(find_child(0,"service.txt"))==id);
 cmd("hostinfo");CHECK(has(answer,"No process isolation"));cmd("hostdemo");CHECK(has(answer,"PASS:"));CHECK(find_child(cwd,"HostDemo.TXT")!=NONE&&oh_fd_available()==64&&oh_pages_available()==2048);cmd("hostdemo");CHECK(has(answer,"refused"));
 printf("%u host-service assertions passed (includes two 8192-byte zeroing sweeps).\n",checks);free(refs);free(pool);return 0;}
