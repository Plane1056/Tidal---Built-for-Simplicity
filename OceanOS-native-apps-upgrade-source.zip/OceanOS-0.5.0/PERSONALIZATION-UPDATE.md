# OceanOS 0.5.0 — Native personalization preview 1

Scope: UI/customizability. Browser and Windows-compatibility development paused.
Source base: attached OceanOS-0.5.0-compatibility-foundation.zip. The previous
clean-desktop and shell-update archives were not attached in this turn; desktop
interaction changes have been reimplemented here rather than assumed present.

## Reference and implemented visual changes
Reference: reference/OceanOS-Files-Upgrade.html (provided by the user).
The HTML is a browser-hosted prototype. This build translates selected visual
and interaction concepts into the native C/Tidal renderer; it does NOT run its
JavaScript, DOM, CSS, browser storage or embedded frames.

- Exact reference palette values for dark/light surfaces and six accent colors.
- Proportional antialiased DejaVu Sans bitmap UI font; license in assets.
  Editors and terminal retain their existing monospace content renderer.
- Rounded titlebars, window surfaces, cards, buttons and pinned-app Start grid.
- Four native procedural wallpaper approximations: Bloom, Aurora, Dusk, Solid.
  These are approximations, not a pixel-identical CSS rendering.
- Explorer-specific Home/Notes navigation, cleaner file rows and proportional labels.
- Desktop-first boot, six shortcuts, single selection, double-click launch and drag.
- Right-click an unobstructed desktop (no active app) for Personalize, Save desktop
  layout and Reset icon positions. Desktop context menu is not a general file menu.

## Personalization
Open Settings from desktop, taskbar, Start, F4 or desktop right-click.
- Dark / Light mode
- Six accent colors matching the HTML
- Four built-in wallpapers
- Center / Left taskbar alignment
- Desktop icon labels on/off
- Reset (resets theme/layout in memory; Save is required to persist)
- Save preferences (also saves desktop icon positions)

Preferences use a versioned 80-byte OceanUI.CFG file at the OceanFS root with
checksum and range validation. This filename is reserved for UI preferences.
Invalid data is ignored at load and defaults are retained. Save explicitly after
changes: this avoids repeated disk writes during dragging. Save is refused when
there is no mounted writable OceanFS disk; session changes continue working.
Save failure is shown rather than reported as success. This is NOT a journaled
settings store; the underlying filesystem's existing power-loss limits remain.

## Tested
- ISO and freestanding 32-bit kernel build (kernel 405548 bytes).
- Existing 26 compiler tests, 10 disk-tool tests, 1145 runtime assertions,
  588 browser assertions.
- 58 new personalization assertions under ASan/UBSan: palette/mode selection,
  settings hit targets, invalid values, double-click, dragging, context menu,
  three render sizes, wallpaper cache/solid output, preference save + filesystem
  remount + reload using an in-memory sector disk, corrupt config rejection,
  out-of-range layout rejection, no-disk refusal and injected write failure.
- Preview images use the actual renderer in a host framebuffer, not a VM.

No VM boot or physical hardware validation was performed. Host disk tests do not
validate the ATA driver. Double-click hardware timing assumes TSC calibration via
PIT channel 2 and a stable TSC. Calibration failure leaves taskbar/F-key launching
available. Native blur, animation, multiple simultaneous windows, arbitrary image
wallpapers, live resolution switching, editable desktop text, a clock/calendar,
search, and the prototype's extra apps are NOT implemented. No fake network/clock
status is drawn. No Windows executable loading or networking has been added.

Build: node tools/build.js
Test: node tests/run-tests.js
Host previews: compile tests/personalization-preview.c with -Ikernel -no-pie
-fno-builtin; args are app-id light-mode wallpaper-id accent-id left-alignment.

Use disposable VM disks. Do not format an existing disk to install this ISO.
This document supersedes earlier feature-status notes for the UI only.
