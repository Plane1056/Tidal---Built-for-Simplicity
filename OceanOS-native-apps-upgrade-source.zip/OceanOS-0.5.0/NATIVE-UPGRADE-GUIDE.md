# OceanOS — Native application upgrade (experimental)

Built from the user-mode-lab source that the user tested in GNOME Boxes. The UI,
customization, motion, Full-HD mode preference and save-write reduction are kept.
The new file-loaded execution path has NOT been boot-tested in this environment.

## Quick start in Boxes
Back up the disk and save any work first. Attach this ISO as the boot CD; retain
the existing OceanFS disk. Do NOT format your existing disk to install the ISO.
Boot normally, open Terminal, and enter these commands in order:

    usertest run
    installapps
    appcheck /Apps/Hello.ELF
    run /Apps/Hello.ELF
    procs

Stop if the earlier usertest no longer passes. Successful Hello output should
identify a native OceanFS-loaded program and show an exited process with status 0.
Only after Hello returns, try:

    run /Apps/MemoryDemo.ELF
    run /Apps/BadPointer.ELF
    proctest run

The last command installs missing demos, verifies that each installed demo exactly
matches its embedded bytes, then runs controlled launch/fault/relaunch tests. It
refuses modified existing demo files instead of executing or overwriting them.
A faulted demo returning to Terminal is an expected result; a frozen/reset VM is
NOT a passing result. The new path still needs guest validation.

Optional actual file-writing test:

    run /Apps/FileDemo.ELF

This creates UserDemo.TXT in the Terminal's current directory and refuses to
replace an existing file. Delete or rename that demo file yourself before repeating.

## New commands
installapps       Install missing native demos under /Apps; never overwrite.
appcheck PATH     Validate a native ELF without executing it.
run PATH          Foreground execution of a trusted OceanOS SDK application.
procs / ps        Last eight native process records, not a multitasking task list.
proctest run      Explicit controlled launch/fault/relaunch/cleanup regression.
hostinfo          Kernel allocation/descriptor status.

If no writable OceanFS disk is mounted, installation uses the existing RAM-backed
filesystem and is lost after power-off. The installer does not auto-format disks.
Partial install/write failures are reported; a partial new file may remain and is
not silently overwritten on a later run. Existing demo files are preserved.

## Included native apps
Hello: message + process identity.
MemoryDemo: bounded user-data allocation and zeroing checks.
CatWelcome: reads /Welcome.TXT through validated file syscalls.
FileDemo: exclusive create/write/seek/read/close roundtrip.
BadPointer: validates bad-pointer refusal and unknown-syscall error.
Fault: intentionally reads a kernel page (expected page fault).
WriteProtect: intentionally writes its read-only code (expected page fault).
PortIO: intentionally attempts port I/O (expected general protection fault).
LeakFault: opens a file and deliberately faults without closing it.
Budget: intentionally loops on syscalls until the cooperative syscall limit.

## Implemented architecture
- Strict standalone ELF32 little-endian i386 ET_EXEC parser; OceanOS ABI tag
  OSABI 255 / ABI version 1. Linux ELF and Windows PE files are refused.
- Up to eight program headers, bounded file/segment ranges, no overlapping load
  segments, code/data-only destinations, executable entry validation, no dynamic
  loader/interpreter and no writable executable segment declaration.
- Maximum file 64 KiB, one 4 KiB code page, one 4 KiB data/BSS/heap page, one
  4 KiB stack with unmapped separating pages. Data/BSS/stack zeroed per launch.
- Foreground process identity/status/history; exit/fault/resource-limit records.
- User buffer and pathname validation before kernel filesystem operations.
- Syscalls: exit, bounded stdout, open, read, write, close, seek, pid, size, brk.
- OceanFS integration with logical process ownership and descriptor cleanup on
  every returned execution path, including faults and failed launches.
- Cooperative limits: 1024 non-exit syscalls, 64 KiB written, 1 MiB read,
  64 KiB stdout, 32 CREATE requests per process. A syscall that exceeds a budget
  returns to the kernel with limited state / exit status 124.
- brk and SDK alloc_o provide a bounded bump allocation within the already mapped
  data page; this is not a complete malloc/free implementation.
- Kernel transition stack increased to 64 KiB for nested filesystem call depth.

## Critical limitations
No preemption, threads, general scheduler, dynamic linker, POSIX libc, Wine,
networking, audio or native user-window backend was added. Execution is synchronous:
the desktop does not handle input while a native program runs. A program looping
without syscalls can still hang the VM. Cooperative budgets are NOT a watchdog.
Only execute trusted SDK programs; this is not a hardened arbitrary-code sandbox.
User stack/data have no hardware NX protection in the current non-PAE design.
Full process isolation/security is NOT established by validation or host tests.
The temporary paging/TSS/IDT path inherits the previous lab's limitations, including
cached task-register state. Normal boot still does not activate it automatically.

Disk writes remain synchronous and can still block in hardware polling; the
previous save freeze is not certified fixed. The filesystem has no journal or
guaranteed power-loss recovery. Keep disposable/backed-up VM disks.

## What was actually tested here
- ISO build and freestanding compiler/assembler/linker completed.
- Existing 26 compiler, 10 disk-tool tests; 1145 runtime, 588 browser, 58
  personalization, 1049 motion/storage, 16501 host-service and 2067 user-lab
  structural assertions passed.
- 641 new ASan/UBSan native parser/syscall assertions passed: actual SDK ELF
  parsing, malformed/truncated/header/entry/segment rejection, 512 mutation cases,
  BSS/stack clearing, install/no-overwrite, file syscalls, bad destinations,
  strings, heap bounds, resource limits, cleanup, remount and host unsupported path.
- Large assertion counts include previously documented byte/table sweeps.
- NO new VM boot, CPU-transition execution, native ELF execution or real ATA test.
  The earlier ring-3 fixture result was user-reported; it does not validate this
  new loader. Host execution explicitly returns unsupported, never pretends success.

## Build your own native demo
Write sdk/apps/YourApp.c including ocean.h and int main(void). Run:

    node tools/build.js
    node tests/run-tests.js

Build regenerates all SDK programs and the embedded installer bundle. Executables
are in build/native and also on the ISO. Boot the rebuilt ISO and installapps;
existing /Apps files are not upgraded automatically. Replace old demo files only
when you deliberately choose to. SDK code/data/stack must fit the limits above.
The examples use integer-only freestanding C, no standard-library dependencies.
Full SDK ABI details are in sdk/README.md.
