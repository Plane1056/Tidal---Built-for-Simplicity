#!/usr/bin/env node
'use strict';
// Tidal 0.2 compiler: Tidal source -> freestanding C (the intermediate backend).
// New in 0.2: top-level const, for-in ranges, loop, compound assignment, char and
// binary literals, block comments, `let x = ...` (defaults to u32), `extern fn`,
// and compile-time checks for unknown names, shadowing, constant assignment and
// call arity (unknown-function checks need the runtime header, see loadExterns).
const fs = require('fs');

const TYPES = { u64: 'uint64_t', u32: 'uint32_t', u16: 'uint16_t', u8: 'uint8_t' };
const C_RESERVED = new Set(['auto', 'case', 'char', 'default', 'do', 'double', 'enum', 'float', 'goto', 'inline', 'int', 'long',
  'register', 'restrict', 'short', 'signed', 'sizeof', 'static', 'struct', 'switch', 'typedef', 'union', 'unsigned', 'void',
  'volatile', 'NULL']);
const KEYWORDS = new Set(['fn', 'let', 'const', 'extern', 'if', 'else', 'while', 'for', 'in', 'loop', 'return', 'break',
  'continue', 'true', 'false']);
const ASSIGN = new Set(['=', '+=', '-=', '*=', '/=', '%=', '&=', '|=', '^=', '<<=', '>>=']);
const PREC = { '||': 1, '&&': 2, '|': 3, '^': 4, '&': 5, '==': 6, '!=': 6, '<': 7, '>': 7, '<=': 7, '>=': 7, '<<': 8, '>>': 8,
  '+': 9, '-': 9, '*': 10, '/': 10, '%': 10 };
const SYMBOLS = /^(?:<<=|>>=|\.\.|->|==|!=|<=|>=|<<|>>|&&|\|\||[+\-*\/%&|^]=|[{}():;,=+*\/%&|^!~<>-])/;
const CHAR_ESC = { n: 10, r: 13, t: 9, 0: 0, '\\': 92, "'": 39, '"': 34 };

function tokenize(src) {
  const toks = [];
  let p = 0, line = 1;
  while (p < src.length) {
    const s = src.slice(p);
    let m;
    if ((m = /^\s+/.exec(s))) { line += (m[0].match(/\n/g) || []).length; p += m[0].length; continue; }
    if (s.startsWith('//')) { const e = src.indexOf('\n', p); p = e < 0 ? src.length : e; continue; }
    if (s.startsWith('/*')) {
      const e = src.indexOf('*/', p + 2);
      if (e < 0) throw Error('line ' + line + ': unterminated block comment');
      line += (src.slice(p, e).match(/\n/g) || []).length; p = e + 2; continue;
    }
    if ((m = /^"(?:[^"\\\n]|\\.)*"/.exec(s))) { toks.push({ s: m[0], line, kind: 'str' }); p += m[0].length; continue; }
    if ((m = /^'(?:[^'\\\n]|\\[nrt0\\'"])'/.exec(s))) {
      const body = m[0].slice(1, -1);
      const v = body[0] === '\\' ? CHAR_ESC[body[1]] : body.charCodeAt(0);
      toks.push({ s: String(v), line, kind: 'num' }); p += m[0].length; continue;
    }
    if ((m = /^(?:0[xX][0-9a-fA-F]+|0[bB][01]+|\d+)/.exec(s))) {
      let t = m[0];
      if (/^0[bB]/.test(t)) t = BigInt(t).toString();
      toks.push({ s: t, line, kind: 'num' }); p += m[0].length; continue;
    }
    if ((m = /^[A-Za-z_][A-Za-z0-9_]*/.exec(s))) { toks.push({ s: m[0], line, kind: 'id' }); p += m[0].length; continue; }
    if ((m = SYMBOLS.exec(s))) { toks.push({ s: m[0], line, kind: 'sym' }); p += m[0].length; continue; }
    throw Error('line ' + line + ': unexpected character ' + s[0]);
  }
  toks.push({ s: '<end>', line, kind: 'end' });
  return toks;
}

// Reads "uint32_t name(args);" prototypes from the runtime header so Tidal can check calls.
function loadExterns(headerText) {
  const map = new Map();
  const re = /uint32_t\s+([A-Za-z_]\w*)\(([^)]*)\)/g;
  let m;
  while ((m = re.exec(headerText))) {
    const a = m[2].trim();
    map.set(m[1], { argc: a === '' || a === 'void' ? 0 : a.split(',').length });
  }
  return map;
}

function compile(source, options = {}) {
  const tokens = tokenize(source);
  let i = 0, uid = 0, inConst = false;
  const strict = !!options.externs;
  const peek = () => tokens[i].s;
  const peekAt = n => (tokens[i + n] || tokens[tokens.length - 1]).s;
  const fail = m => { throw Error('line ' + tokens[i].line + ': ' + m); };
  const take = () => tokens[i++].s;
  const expect = x => { if (peek() !== x) fail('expected ' + x + ', got ' + peek()); return take(); };
  const isIdent = t => /^[A-Za-z_]\w*$/.test(t);
  const identifier = () => {
    const t = peek();
    if (!isIdent(t) || KEYWORDS.has(t)) fail('identifier expected, got ' + t);
    if (t.startsWith('__') || C_RESERVED.has(t)) fail(t + ' is reserved by the C backend; choose another name');
    return take();
  };
  const type = () => { const t = take(); if (!TYPES[t]) fail('unsupported type ' + t); return TYPES[t]; };

  const consts = new Map(), funcs = new Map(), calls = [], scopes = [];
  const declare = name => {
    if (consts.has(name)) fail(name + ' is a constant');
    if (scopes.some(s => s.has(name))) fail(name + ' is already declared (Tidal forbids shadowing)');
    scopes[scopes.length - 1].add(name);
  };
  const known = name => consts.has(name) || scopes.some(s => s.has(name));

  function atom() {
    const line = tokens[i].line;
    const t = take();
    if (['!', '~', '-', '+'].includes(t)) return '(' + t + atom() + ')';
    if (t === '(') { const e = expr(); expect(')'); return '(' + e + ')'; }
    if (t === 'true') return '1u';
    if (t === 'false') return '0u';
    if (/^"/.test(t)) {
      try { JSON.parse(t); } catch (e) { fail('string must use JSON escapes'); }
      return '((uintptr_t)' + t + ')';
    }
    if (/^(?:0x[\da-fA-F]+|\d+)$/.test(t)) {
      if (BigInt(t) > 0xffffffffffffffffn) fail('integer too large');
      return BigInt(t).toString() + (BigInt(t) <= 0xffffffffn ? 'u' : 'ULL');
    }
    if (!isIdent(t) || KEYWORDS.has(t)) fail('expression expected, got ' + t);
    if (peek() === '(') {
      if (inConst) fail('constants cannot call functions');
      take();
      const a = [];
      if (peek() !== ')') { do { a.push(expr()); if (peek() !== ',') break; take(); } while (true); }
      expect(')');
      calls.push({ name: t, argc: a.length, line });
      return t + '(' + a.join(',') + ')';
    }
    if (!known(t)) throw Error('line ' + line + ': unknown name ' + t);
    return t;
  }
  function expr(min = 1) {
    let a = atom();
    while (PREC[peek()] >= min) { const op = take(), b = expr(PREC[op] + 1); a = '(' + a + ' ' + op + ' ' + b + ')'; }
    return a;
  }
  function block(reuseScope) {
    expect('{');
    if (!reuseScope) scopes.push(new Set());
    let s = '{\n';
    while (peek() !== '}') { if (peek() === '<end>') fail('unterminated block'); s += stmt(); }
    take();
    if (!reuseScope) scopes.pop();
    return s + '}\n';
  }
  function stmt() {
    const t = peek();
    if (t === 'let') {
      take();
      const n = identifier();
      let ty = 'uint32_t';
      if (peek() === ':') { take(); ty = type(); }
      expect('=');
      const e = expr();
      expect(';');
      declare(n);
      return ty + ' ' + n + ' = ' + e + ';\n';
    }
    if (t === 'if' || t === 'while') {
      const k = take(), e = expr();
      let s = k + ' (' + e + ') ' + block();
      if (k === 'if' && peek() === 'else') { take(); s += 'else ' + (peek() === 'if' ? stmt() : block()); }
      return s;
    }
    if (t === 'loop') { take(); return 'for (;;) ' + block(); }
    if (t === 'for') {
      take();
      const v = identifier();
      expect('in');
      const a = expr();
      expect('..');
      const b = expr();
      scopes.push(new Set());
      declare(v);
      const body = block(true);
      scopes.pop();
      const id = uid++;
      return '{ uint32_t __end' + id + ' = ' + b + '; for (uint32_t ' + v + ' = ' + a + '; ' + v + ' < __end' + id + '; ' + v + '++) ' + body + '}\n';
    }
    if (t === 'return') { take(); const e = expr(); expect(';'); return 'return ' + e + ';\n'; }
    if (t === 'break' || t === 'continue') { take(); expect(';'); return t + ';\n'; }
    if (t === '{') return block();
    if (isIdent(t) && !KEYWORDS.has(t) && ASSIGN.has(peekAt(1))) {
      const n = take();
      if (!known(n)) fail('unknown name ' + n);
      if (consts.has(n)) fail('cannot assign to constant ' + n);
      const op = take(), e = expr();
      expect(';');
      return n + ' ' + op + ' ' + e + ';\n';
    }
    const a = expr();
    expect(';');
    return a + ';\n';
  }
  function params() {
    const names = [], decl = [];
    expect('(');
    if (peek() !== ')') {
      do { const n = identifier(); expect(':'); decl.push(type() + ' ' + n); names.push(n); if (peek() !== ',') break; take(); } while (true);
    }
    expect(')');
    return { names, decl };
  }

  const defines = [], declarations = [], definitions = [];
  while (peek() !== '<end>') {
    if (peek() === 'const') {
      take();
      const name = identifier();
      if (consts.has(name) || funcs.has(name)) fail('duplicate name ' + name);
      expect(':');
      const ty = type();
      expect('=');
      inConst = true;
      const e = expr();
      inConst = false;
      expect(';');
      consts.set(name, ty);
      defines.push('#define ' + name + ' ((' + ty + ')(' + e + '))');
      continue;
    }
    if (peek() === 'extern') {
      take(); expect('fn');
      const name = identifier();
      const p = params();
      expect('->');
      const ret = type();
      expect(';');
      funcs.set(name, { argc: p.names.length });
      declarations.push(ret + ' ' + name + '(' + (p.decl.join(',') || 'void') + ');');
      continue;
    }
    expect('fn');
    const name = identifier();
    if (funcs.has(name) || consts.has(name)) fail('duplicate function ' + name);
    const p = params();
    funcs.set(name, { argc: p.names.length });
    expect('->');
    const ret = type();
    const head = ret + ' ' + name + '(' + (p.decl.join(',') || 'void') + ')';
    scopes.length = 0;
    scopes.push(new Set());
    p.names.forEach(n => { if (scopes[0].has(n)) fail('duplicate parameter ' + n); scopes[0].add(n); });
    declarations.push(head + ';');
    definitions.push(head + block(true));
  }
  for (const c of calls) {
    const f = funcs.get(c.name) || (options.externs && options.externs.get(c.name));
    if (!f) { if (strict) throw Error('line ' + c.line + ': unknown function ' + c.name); continue; }
    if (f.argc !== c.argc) throw Error('line ' + c.line + ': ' + c.name + ' expects ' + f.argc + ' argument(s), got ' + c.argc);
  }
  return '#include "runtime.h"\n' + defines.join('\n') + '\n' + declarations.join('\n') + '\n' + definitions.join('\n');
}

module.exports = { compile, loadExterns, tokenize };
if (require.main === module) {
  try {
    const args = process.argv.slice(2);
    let header = null;
    const hi = args.indexOf('--runtime');
    if (hi >= 0) { header = args[hi + 1]; args.splice(hi, 2); }
    const options = header ? { externs: loadExterns(fs.readFileSync(header, 'utf8')) } : {};
    fs.writeFileSync(args[1], compile(fs.readFileSync(args[0], 'utf8'), options));
  } catch (e) { console.error('Tidal: ' + e.message); process.exit(1); }
}
