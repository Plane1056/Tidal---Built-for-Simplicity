.section .text
.code16
.global _start
_start:
 cld
 cli
 xorw %ax,%ax
 movw %ax,%ds
 movw %ax,%es
 movw %ax,%ss
 movw $0x7c00,%sp
 sti
 movb %dl,drive
 movw $mode_list,mode_ptr
try_resolution:
 movw mode_ptr,%si
 lodsw
 testw %ax,%ax
 jz no_video
 movw %ax,target_w
 lodsw
 movw %ax,target_h
 movw %si,mode_ptr
 movw $0x100,%cx
mode_loop:
 pushw %cx
 movw $0x9000,%di
 movw $0x4f01,%ax
 int $0x10
 popw %cx
 cmpw $0x004f,%ax
 jne next_mode
 movw 0x9000,%ax
 andw $0x91,%ax
 cmpw $0x91,%ax
 jne next_mode
 movw target_w,%ax
 cmpw %ax,0x9012
 jne next_mode
 movw target_h,%ax
 cmpw %ax,0x9014
 jne next_mode
 cmpb $32,0x9019
 jne next_mode
 cmpb $6,0x901b
 jne next_mode
 cmpb $16,0x9020
 jne next_mode
 cmpb $8,0x9022
 jne next_mode
 cmpb $0,0x9024
 jne next_mode
 movl 0x9028,%eax
 testl %eax,%eax
 jz next_mode
 movl %eax,0x9300
 movzwl 0x9010,%eax
 movl %eax,0x9304
 movzwl target_w,%eax
 movl %eax,0x9308
 movzwl target_h,%eax
 movl %eax,0x930c
 movw %cx,%bx
 orw $0x4000,%bx
 movw $0x4f02,%ax
 int $0x10
 cmpw $0x004f,%ax
 je video_ready
next_mode:
 incw %cx
 cmpw $0x200,%cx
 jb mode_loop
 jmp try_resolution
no_video:
 movw $video_error,%si
 jmp error
video_ready:
 movw $KERNEL_CHUNKS,%bp
load_loop:
 pushw %bp
 movw $dap,%si
 movb drive,%dl
 movb $0x42,%ah
 int $0x13
 popw %bp
 jc disk_error
 addw $0x800,dap_segment
 addl $16,dap_lba
 decw %bp
 jnz load_loop
 cli
 inb $0x92,%al
 orb $2,%al
 andb $0xfe,%al
 outb %al,$0x92
 lgdt gdt_pointer
 movl %cr0,%eax
 orl $1,%eax
 movl %eax,%cr0
 ljmpl $8,$protected
error:
 movw $3,%ax
 int $0x10
print:
 lodsb
 testb %al,%al
 jz hang
 movb $0x0e,%ah
 movw $7,%bx
 int $0x10
 jmp print
hang:
 cli
 hlt
 jmp hang
disk_error:
 movw $disk_message,%si
 jmp error
.align 8
gdt:
 .quad 0
 .quad 0x00cf9a000000ffff
 .quad 0x00cf92000000ffff
gdt_pointer:
 .word 23
 .long gdt
.align 4
dap:
 .byte 16,0
 .word 16
 .word 0
dap_segment: .word 0x1000
dap_lba: .long 26,0
mode_ptr: .word mode_list
mode_list: .word 1920,1080,1600,900,1440,900,1280,800,1280,720,1280,1024,1024,768,800,600,0,0
target_w: .word 1600
target_h: .word 900
drive: .byte 0
video_error: .asciz "OceanOS: VESA 32-bit linear video mode required. Use Bochs VGA."
disk_message: .asciz "OceanOS: BIOS CD read failed."
.code32
protected:
 movw $0x10,%ax
 movw %ax,%ds
 movw %ax,%es
 movw %ax,%ss
 movw %ax,%fs
 movw %ax,%gs
 movl $0x90000,%esp
 movl $0x10000,%eax
 jmp *%eax
