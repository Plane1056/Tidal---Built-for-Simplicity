 .section .text
.code32
.global ul_enter
ul_enter:
 pushfl
 cli
 pushal
 movl %esp,ul_resume_sp
 movl 40(%esp),%eax
 movl 44(%esp),%edx
 movw $0x23,%cx
 movw %cx,%ds
 movw %cx,%es
 movw %cx,%fs
 movw %cx,%gs
 pushl $0x23
 pushl %edx
 pushl $2
 pushl $0x1b
 pushl %eax
 iret
.global ul_isr_default
ul_isr_default:
 pushl $0
 pushl $255
 jmp ul_common
.global ul_syscall_entry
ul_syscall_entry:
 pushl $0
 pushl $128
 jmp ul_common
ul_exception_0:
 pushl $0
 pushl $0
 jmp ul_common
ul_exception_1:
 pushl $0
 pushl $1
 jmp ul_common
ul_exception_2:
 pushl $0
 pushl $2
 jmp ul_common
ul_exception_3:
 pushl $0
 pushl $3
 jmp ul_common
ul_exception_4:
 pushl $0
 pushl $4
 jmp ul_common
ul_exception_5:
 pushl $0
 pushl $5
 jmp ul_common
ul_exception_6:
 pushl $0
 pushl $6
 jmp ul_common
ul_exception_7:
 pushl $0
 pushl $7
 jmp ul_common
ul_exception_8:
 pushl $8
 jmp ul_common
ul_exception_9:
 pushl $0
 pushl $9
 jmp ul_common
ul_exception_10:
 pushl $10
 jmp ul_common
ul_exception_11:
 pushl $11
 jmp ul_common
ul_exception_12:
 pushl $12
 jmp ul_common
ul_exception_13:
 pushl $13
 jmp ul_common
ul_exception_14:
 pushl $14
 jmp ul_common
ul_exception_15:
 pushl $0
 pushl $15
 jmp ul_common
ul_exception_16:
 pushl $0
 pushl $16
 jmp ul_common
ul_exception_17:
 pushl $17
 jmp ul_common
ul_exception_18:
 pushl $0
 pushl $18
 jmp ul_common
ul_exception_19:
 pushl $0
 pushl $19
 jmp ul_common
ul_exception_20:
 pushl $0
 pushl $20
 jmp ul_common
ul_exception_21:
 pushl $21
 jmp ul_common
ul_exception_22:
 pushl $0
 pushl $22
 jmp ul_common
ul_exception_23:
 pushl $0
 pushl $23
 jmp ul_common
ul_exception_24:
 pushl $0
 pushl $24
 jmp ul_common
ul_exception_25:
 pushl $0
 pushl $25
 jmp ul_common
ul_exception_26:
 pushl $0
 pushl $26
 jmp ul_common
ul_exception_27:
 pushl $0
 pushl $27
 jmp ul_common
ul_exception_28:
 pushl $0
 pushl $28
 jmp ul_common
ul_exception_29:
 pushl $29
 jmp ul_common
ul_exception_30:
 pushl $30
 jmp ul_common
ul_exception_31:
 pushl $0
 pushl $31
 jmp ul_common
ul_common:
 pushal
 push %ds
 push %es
 push %fs
 push %gs
 cld
 movw $0x10,%ax
 movw %ax,%ds
 movw %ax,%es
 movw %ax,%fs
 movw %ax,%gs
 pushl %esp
 call ul_trap
 addl $4,%esp
 testl %eax,%eax
 jz ul_continue
 cmpl $1,%eax
 jne ul_kernel_fault
 movl ul_resume_sp,%esp
 popal
 popfl
 ret
ul_continue:
 pop %gs
 pop %fs
 pop %es
 pop %ds
 popal
 addl $8,%esp
 iret
ul_kernel_fault:
 cli
 hlt
 jmp ul_kernel_fault
.section .bss
.align 4
ul_resume_sp: .long 0
.section .rodata
.align 4
.global ul_exception_table
ul_exception_table:
 .long ul_exception_0
 .long ul_exception_1
 .long ul_exception_2
 .long ul_exception_3
 .long ul_exception_4
 .long ul_exception_5
 .long ul_exception_6
 .long ul_exception_7
 .long ul_exception_8
 .long ul_exception_9
 .long ul_exception_10
 .long ul_exception_11
 .long ul_exception_12
 .long ul_exception_13
 .long ul_exception_14
 .long ul_exception_15
 .long ul_exception_16
 .long ul_exception_17
 .long ul_exception_18
 .long ul_exception_19
 .long ul_exception_20
 .long ul_exception_21
 .long ul_exception_22
 .long ul_exception_23
 .long ul_exception_24
 .long ul_exception_25
 .long ul_exception_26
 .long ul_exception_27
 .long ul_exception_28
 .long ul_exception_29
 .long ul_exception_30
 .long ul_exception_31

.global ul_good_start,ul_good_end
ul_good_start:
 movl $1,%eax
 movl $(0x40000000+ul_good_message-ul_good_start),%ebx
 movl $(ul_good_message_end-ul_good_message),%ecx
 int $0x80
 cmpl $(ul_good_message_end-ul_good_message),%eax
 jne ul_good_fail
 xorl %ebx,%ebx
 jmp ul_good_exit
ul_good_fail:
 movl $1,%ebx
ul_good_exit:
 xorl %eax,%eax
 int $0x80
 ud2
ul_good_message: .ascii "Hello from controlled ring 3"
ul_good_message_end:
ul_good_end:
.global ul_badptr_start,ul_badptr_end
ul_badptr_start:
 movl $1,%eax
 movl $0x10000,%ebx
 movl $8,%ecx
 int $0x80
 xorl %ebx,%ebx
 cmpl $-14,%eax
 je ul_badptr_exit
 movl $1,%ebx
ul_badptr_exit:
 xorl %eax,%eax
 int $0x80
 ud2
ul_badptr_end:
.global ul_fault_start,ul_fault_end
ul_fault_start:
 movl $0x10000,%eax
 movl (%eax),%eax
 ud2
ul_fault_end:
.global ul_io_start,ul_io_end
ul_io_start:
 movw $0x80,%dx
 xorl %eax,%eax
 outb %al,%dx
 ud2
ul_io_end:
.section .note.GNU-stack,"",@progbits
