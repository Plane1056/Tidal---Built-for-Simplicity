# OceanOS 0.5.0 — Opt-in user-mode architecture lab

Base: attached OceanOS-host-services-1-source.zip. All prior UI/motion/Full-HD and
host-service code retained. This is an experimental architecture increment, NOT
an operational process manager or Wine integration.

## What code was added
- boot/user_mode.S: controlled ring-3 fixtures, IRET entry, exception/syscall stubs,
  kernel-return continuation. New assembly is compiled and linked into the ISO.
- kernel/user_lab.inc / .h: fixed paging structures, GDT/TSS/IDT setup, bounded
  copy-from-fixture buffers, two tiny syscall operations (exit and copy-to-log),
  fixture sequencing and exception inspection.
- Terminal: usertest (warning/help) and usertest run (explicit execution).
- Host tests for page-table structure, buffer bounds and copy logic.

## WARNING: NOT VM-VALIDATED
No QEMU executable is installed in the build environment. The CPU transition,
exception-return and privileged-register setup code has NOT run on a VM or real
CPU. Host structural tests cannot verify those operations. Do not infer working
crash isolation from the successful host suite. The experiment may halt or reset
the VM. Save work and use a backed-up/disposable Boxes disk before trying it.
Normal startup does not install this lab's paging/GDT/IDT or enter user mode.

## Intended explicit experiment
Open Terminal and type usertest to read the warning. Only usertest run enters
the experimental path. It attempts four embedded native fixtures:
1. CPL3 code copies a bounded message through int 0x80, then exits.
2. A syscall with a kernel-address argument must return -14, then exits.
3. A direct user read from a supervisor page must raise page fault 14 with the
   expected present/user bits; the handler attempts return to the kernel caller.
4. Direct user port I/O must raise general protection fault 13.
The terminal reports success only if all four actual guest paths return with
expected conditions. It never treats a host simulation as successful execution.

The fixtures are not Windows executables, not loaded from disk, and not ordinary
applications. No untrusted external executable is accepted.

## Exact scope and limits
- 32-bit non-PAE paging; requires CPUID/PSE-capable target consistent with the
  existing x86-64-CPU VM recommendation. Rejects already-enabled paging or PAE.
- Fixed user code page at 0x40000000 (read-only) and stack at 0x40004000 (writable),
  absent intervening guard pages. The rest of this 4 MiB region is absent.
- Other 4 MiB identity mappings are supervisor-only; this is not a general RAM
  discovery or mapping service. User backing is reserved kernel BSS memory.
- GDT has kernel/user segments and a TSS; TSS I/O-map base is beyond its limit.
- A dedicated kernel transition stack and exception IDT exist only for the lab.
- Interrupts remain disabled while fixtures run. There is no preemption, timeout,
  scheduler or recovery from a spinning user program. A kernel-side exception
  intentionally halts, not claims successful recovery.
- No NX protection; this is not a hardened sandbox.
- Returning attempts restore CR0/CR3/CR4, GDTR and IDTR. The x86 task register's
  cached TSS state remains installed; no claim of arbitrary-host-state restoration
  is made. This lab is tailored to the current boot baseline, not a reusable
  context-switching library.
- No process objects, ELF loader, threads, POSIX ABI, user file syscalls, dynamic
  linker, Wine build, audio or network stack was added.
- The existing host file/memory APIs remain trusted kernel APIs. They are NOT
  exposed through these two lab syscalls.

## Actual verification
- Full 32-bit freestanding compile, assembly and ISO link completed.
- Inspected generated transition disassembly and fixture symbol bounds: 67, 35,
  9 and 9 bytes, all within the fixed code page.
- Existing suites passed: 26 compiler / 10 disk-tool tests; 1145 runtime,
  588 browser, 58 personalization, 1049 motion/storage and 16501 host-service
  assertions. Large counts include previously documented per-byte/table sweeps.
- New 2067 ASan/UBSan structural assertions passed. Most are directory/table
  permission sweeps. The tests assert that host ul_selftest returns unsupported,
  not pretend success. NO privilege transitions were exercised.
- No Boxes boot, hardware ATA test or CPU-fault-recovery validation.

## Next gate
The required next evidence is an actual VM run of usertest run. If it halts or
reboots, debug the transition with an emulator/debugger before adding loading or
more syscalls. Only a verified fault-return path should underpin a general
process loader, per-process resources, scheduling and a future libc/Wine port.
Do not continue layering unverified isolation code and call it application support.

Build: node tools/build.js
Tests: node tests/run-tests.js
This document supersedes prior status only for this opt-in unverified lab.
