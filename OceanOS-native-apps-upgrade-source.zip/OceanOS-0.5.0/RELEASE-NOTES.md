# 0.5.0 Current

Adds Tidal local HTML browser. See README.md for supported features, controls, testing and limitations.
