const fs=require('fs');
function makeIso(boot,kernel,files){
 const S=2048;let cursor=26;const chunks=Math.ceil(kernel.length/(16*S));const entries=[{name:'KERNEL.BIN;1',sector:26,data:kernel}];cursor+=chunks*16;
 for(const [name,data0] of Object.entries(files)){const data=Buffer.isBuffer(data0)?data0:Buffer.from(data0);entries.push({name:name+';1',sector:cursor,data});cursor+=Math.ceil(data.length/S);}
 const image=Buffer.alloc(cursor*S);const both16=(b,o,v)=>{b.writeUInt16LE(v,o);b.writeUInt16BE(v,o+2);};const both32=(b,o,v)=>{b.writeUInt32LE(v,o);b.writeUInt32BE(v,o+4);};
 function rec(name,lba,len,dir=false){const id=Buffer.isBuffer(name)?name:Buffer.from(name);const b=Buffer.alloc(33+id.length+(id.length%2===0?1:0));b[0]=b.length;both32(b,2,lba);both32(b,10,len);Buffer.from([126,1,1,0,0,0,0]).copy(b,18);b[25]=dir?2:0;both16(b,28,1);b[32]=id.length;id.copy(b,33);return b;}
 function descriptor(type,sector){const b=image.subarray(sector*S,(sector+1)*S);b[0]=type;b.write('CD001',1);b[6]=1;return b;}
 const p=descriptor(1,16);p.fill(32,8,72);p.write('OCEANOS',8);p.write('OCEANOS_0_4_0',40);both32(p,80,cursor);both16(p,120,1);both16(p,124,1);both16(p,128,S);both32(p,132,10);p.writeUInt32LE(19,140);p.writeUInt32BE(20,148);rec(Buffer.from([0]),22,S,true).copy(p,156);p[881]=1;
 for(const off of [813,830,847,864]){p.write('2026010100000000',off);p[off+16]=0;}
 const bd=descriptor(0,17);bd.write('EL TORITO SPECIFICATION',7);bd.writeUInt32LE(21,71);descriptor(255,18);
 const le=image.subarray(19*S,20*S);le[0]=1;le.writeUInt32LE(22,2);le.writeUInt16LE(1,6);
 const be=image.subarray(20*S,21*S);be[0]=1;be.writeUInt32BE(22,2);be.writeUInt16BE(1,6);
 const cat=image.subarray(21*S,22*S);cat[0]=1;cat[1]=0;cat.write('OceanOS BIOS',4);cat[30]=0x55;cat[31]=0xaa;let sum=0;for(let i=0;i<32;i+=2)sum+=cat.readUInt16LE(i);cat.writeUInt16LE((-sum)&65535,28);cat[32]=0x88;cat.writeUInt16LE(0x7c0,34);cat.writeUInt16LE(4,38);cat.writeUInt32LE(24,40);
 const records=[rec(Buffer.from([0]),22,S,true),rec(Buffer.from([1]),22,S,true),rec('BOOT.IMG;1',24,boot.length),...entries.map(e=>rec(e.name,e.sector,e.data.length))];const dir=Buffer.concat(records);if(dir.length>S)throw Error('Root directory too large');dir.copy(image,22*S);if(boot.length>2048)throw Error('Initial BIOS load window exceeded');boot.copy(image,24*S);for(const e of entries)e.data.copy(image,e.sector*S);return image;
}
module.exports={makeIso};
