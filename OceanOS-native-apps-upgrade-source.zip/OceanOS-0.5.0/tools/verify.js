const fs=require('fs'),assert=require('assert'),crypto=require('crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const iso=fs.readFileSync('build/OceanOS-0.5.0.iso'),boot=fs.readFileSync('build/boot.img'),kernel=fs.readFileSync('build/kernel.bin'),S=2048;
assert.equal(iso.toString('ascii',32769,32774),'CD001');assert.equal(iso.readUInt32LE(32848)*S,iso.length);
let sum=0;for(let i=0;i<32;i+=2)sum+=iso.readUInt16LE(21*S+i);assert.equal(sum&65535,0);assert.equal(iso[21*S+32],0x88);assert.equal(iso.readUInt32LE(21*S+40),24);
assert(iso.subarray(24*S,24*S+boot.length).equals(boot));assert(iso.subarray(26*S,26*S+kernel.length).equals(kernel));assert(Math.ceil(kernel.length/32768)*32768<=0x70000);
let names=[];for(let p=22*S;p<23*S&&iso[p];p+=iso[p]){let len=iso[p+32];if(len===1&&iso[p+33]<2)continue;let name=iso.toString('ascii',p+33,p+33+len),lba=iso.readUInt32LE(p+2),size=iso.readUInt32LE(p+10);assert(lba*S+size<=iso.length);names.push(name);}
assert(names.some(n=>n.startsWith('BROWSER.TID')));assert(names.some(n=>n.startsWith('BROWSER.INC')));
const report={version:'0.5.0',iso_sha256:sha(iso),kernel_sha256:sha(kernel),iso_bytes:iso.length,kernel_bytes:kernel.length,iso_boot_catalog_checked:true,browser_engine_language:'Tidal',platform_bridge_language:'C',networking:false,vm_boot_tested:false,ATA_hardware_tested:false,root_files:names};fs.writeFileSync('build/verification.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
