#include "../kernel/host_services.h"
/* Trusted kernel caller only; not a userspace program. */
int host_api_example(void){
 uintptr_t p=oh_pages_alloc(42,1);if(!p)return -12;
 int fd=oh_open(42,0,"Example.TXT",OH_READ|OH_WRITE|OH_CREATE|OH_EXCL);
 if(fd<0){oh_pages_free(42,p);return fd;}
 int result=oh_write(42,fd,"test",4);
 if(result==4&&oh_seek(42,fd,0,0)==0)result=oh_read(42,fd,(void*)p,4);
 oh_close(42,fd);oh_pages_free(42,p);return result;
}
