# Current storage documentation

See storage-v3.md for OceanFS 3. The embedded old guide is preserved only as a recovery artifact and does not describe this release.
