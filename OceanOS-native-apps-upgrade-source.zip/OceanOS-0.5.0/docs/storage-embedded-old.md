# Storage 0.2 - IDE disks and OceanFS

## Hardware support
Legacy IDE (ATA PIO, LBA28) on the primary and secondary buses, master and slave. Probed in order 1F0 master, 1F0 slave, 170 master, 170 slave; ATAPI (CD-ROM) and SATA-signature devices are skipped, so the boot CD is never touched. The first plain ATA disk with LBA support wins. Interrupts are masked; transfers are polled one sector at a time. Not supported: AHCI/SATA-only controllers, NVMe, USB storage, 48-bit LBA, DMA. In a VM, attach the disk to an IDE controller.

QEMU example: `qemu-system-i386 -m 128 -cdrom build/OceanOS-0.2.0.iso -hda build/OceanOS-disk.img -boot d`
(`-hda` is primary-master IDE; the CD lands on the secondary bus.) VirtualBox/VMware: IDE controller, not SATA.

## Safety rules
* A disk is read at boot. It is written only if sector 0 carries the OceanFS signature, or after an explicit Format.
* A disk without the signature is left untouched (state "not OceanFS"); the Files app shows Format disk, which needs two clicks, and the terminal needs `format erase`.
* If any disk write fails the session drops to RAM-only and says so; nothing is silently lost without a message.
* No journal. A power cut during a save can lose that one file; table and data are written in a safe order (data first, table second) so the rest stays consistent. Mount validates the table and refuses a corrupt one (RAM-only, disk untouched).
* No disk attached: everything works from RAM and disappears at power-off, like 0.1.1.

## OceanFS 1 layout (512-byte sectors)
| LBA | Contents |
|-----|----------|
| 0 | Superblock: ASCII `OCEANFS1`, u32 version=1 @8, u32 entries=64 @12, u32 slot sectors=4 @16 |
| 1-8 | Entry table: 64 entries of 64 bytes. Entry 0 is the root folder |
| 16-271 | 64 data slots of 2048 bytes; entry N owns slot N |

Entry: `char name[28]` (NUL-terminated), `u32 type` (0 free, 1 file, 2 folder), `u32 parent` (entry index), `u32 size`, 24 reserved bytes. All integers little-endian.

Limits: 63 items (files + folders) total, files up to 2047 bytes of ASCII text, names 1-27 printable ASCII characters without `/` or `\`, no leading/trailing space, unique per folder. Tools: `node tools/mkdisk.js out.img [MiB] [formatted|blank]`.

## Using it
Files: click selects, clicking a selected row (or Enter) opens it; Up/Down arrows move, Backspace goes up, Delete removes. Buttons: Up, Open, New folder (then type its name), Rename, Delete, and Format disk when needed. Notepad saves into the folder currently open in Files, as Note1.TXT, Note2.TXT... or back to the file it opened; rename in Files.
Terminal: `ls cd pwd mkdir touch cat rm mv write disk df format erase` (names are relative to the current folder; `cd` accepts paths, `..` and `/`).
