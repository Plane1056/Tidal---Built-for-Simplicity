# Formats
.Tide source is in use. .coral applications and .refraction images remain reserved; neither loader nor codec exists. OceanFS 1 (see storage.md) stores plain ASCII text files and folders on an IDE disk, with a RAM-only fallback when no disk is attached. Filename extensions do not authorize execution.
