# OceanFS 3 on-disk layout
All integers little-endian; block size 4096 bytes; raw whole-device format, no partition table.

Block 0 superblock: magic OCEANFS3; u32 version 3 @8; block bytes 4096 @12; entries 8193 @16; total blocks @20; bitmap start 1 @24; bitmap blocks 64 @28; table start 65 @32; table blocks 513 @36; data start 578 @40; FNV-1a checksum of bytes 0..43 @44. Supported total blocks 2048..2097152 inclusive (8 MiB..8 GiB).
Blocks 1..64: bitmap (262144 bytes), LSB-first allocation bits.
Blocks 65..577: fixed entry table (8193 records of 256 bytes, padded to 513 blocks).
Blocks 578 onward: dynamically allocated data and extent-index blocks.
Record: UTF-8 name[128], u32 type @128 (0 free/1 file/2 dir), parent @132, size bytes @136, index @140, flags @144, reserved[108]. Root ID 0, name /, directory, parent/size/index zero.
Extent page: EX2P @0, u32 count @4, next @8, reserved @12; up to 510 pairs (u32 start,count) from offset 16. Directory size/index zero. File limit 1073741824 bytes; up to 262144 data blocks and 515 index pages for worst fragmentation. Files can contain zero bytes; sizes are not string lengths.
Metadata is 578 blocks (~2.26 MiB) before file contents. Seed documents/index pages use further blocks. Replacement is whole-file copy-on-write, not an atomic journal transaction. Failed sector writes disable subsequent volume changes; leaks/partial metadata are possible after failure/power loss. No torn-sector protection/fsck/repair tool.
OceanFS 1/2 are incompatible and not auto-formatted. Use explicit migration into a NEW destination. Back up old media and test on disposable images.
