# Horizon graphics
Logical 1280x800 layout; software rasterization at firmware-selected resolution. Boot mode priority: 1600x900, 1440x900, 1280x800, 1280x720, 1280x1024, 1024x768, 800x600 (all 32-bit BGR linear direct color). Four native grayscale atlas pairs: small 6x15/8x18/9x21/10x24; large 13x30/15x36/18x42/20x48. These correspond to width categories under 1000, 1000..1199, 1200..1439, 1440+. Not arbitrary scalable fonts, subpixel rendering or a GPU driver. Nonmatching aspect ratios stretch geometry through independent logical X/Y scaling.
Cursor is composited into RAM; pointer-only motion updates old/new rectangles. No hardware page flip or guaranteed tear-free presentation. Full window changes still repaint in software. Seven host framebuffer configurations were tested; BIOS selection itself was not executed.
Host preview command after build:
    gcc -O1 -fno-builtin -fno-pie -no-pie -Ikernel tests/render-preview.c -o build/render-preview
    ./build/render-preview
Output is build/preview.ppm, not a VM screenshot. Non-PIE host harness keeps Tidal u32 string addresses representable.
