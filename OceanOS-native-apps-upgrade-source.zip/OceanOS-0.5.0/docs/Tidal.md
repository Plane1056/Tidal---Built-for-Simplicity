# Tidal 0.2 subset

Compiler: compiler/tidalc.js (JavaScript) emits freestanding C; GCC does the native type checking. Run `node compiler/tidalc.js in.Tide out.c --runtime kernel/runtime.h`; with `--runtime` the compiler also knows every runtime function and checks names and argument counts.

## Syntax
    const NAME:u32 = 0x10 + 2;                 // top-level constant (becomes a #define), constant expressions only
    extern fn name(a:u32)->u32;                 // declare a runtime function
    fn name(a:u32, b:u8)->u32 { ... }
    let x:u32 = expr;   let y = expr;           // type defaults to u32
    x = e;  x += e;  -= *= /= %= &= |= ^= <<= >>=
    if c { } else if d { } else { }   while c { }   loop { }      // loop = forever, use break
    for i in 0..n { }                           // i runs 0..n-1; bound evaluated once; i is a new u32
    break;  continue;  return e;
    // line comment   /* block comment */
Literals: decimal, 0xHEX, 0b101, 'a' and '\n' (char = number), true/false = 1/0, "JSON-escaped strings" = constant address. Types u8 u16 u32 u64 (C unsigned). Precedence: `||  &&  |  ^  &  == !=  < > <= >=  << >>  + -  * / %`.

## Compile-time checks added in 0.2
Unknown variable names, redeclaration and shadowing of locals, assignment to a const, reserved C words as names, duplicate functions, wrong argument counts, constants that call functions, unterminated comments. Unknown functions are rejected when a runtime header is supplied. Still unchecked: integer types across calls (GCC decides), missing `return` on some paths (GCC warns), division by zero, overflow.

## Still missing
No arrays, structs, pointers, imports, signed types or generics. State lives in the runtime's `state(i)` slots. Not memory safe; not a finished language standard. u64 arithmetic may need compiler runtime support on 32-bit targets (the desktop avoids it).

Recovery note for 0.4: numeric literals are normalized before C emission, and identifiers beginning __ are reserved for generated backend temporaries. Desktop uses the same recovered compiler. No complete new language standard is implied.
